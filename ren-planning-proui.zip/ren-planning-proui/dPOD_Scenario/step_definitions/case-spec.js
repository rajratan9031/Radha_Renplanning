var currentPage = 'casePage';
var oldStatus = '';
var newStatus='';
module.exports = function() {

  this.When(/^I click on Cases microapp$/, function (callback) {
          casePage.clickCasesMicroAppLink().then(function () {
              console.log("Cases tab is displayed");
              callback();
          });

  });

  this.Then(/^I can verify the Case Status of latest case is Open$/, function (callback) {
        casePage.validateCaseStatus().then(function (value) {
            TestHelper.assertEqual(value,'Open', callback);
            callback();
        });

  });

  this.When(/^I click on Create Case icon$/, function (callback) {
          casePage.clickCreateCaseIcon().then(function () {
              callback();
          });

  });

  this.Then(/^I enter the case title (.*)$/, function (caseTitle,callback) {
          casePage.inputCaseTitle(caseTitle).then(function () {
              callback();
          });

  });

  this.When(/^I click on Asset Selection link$/, function (callback) {
          casePage.clickAssetSelectionLink().then(function () {
              console.log("Asset Selection Link is displayed");
              callback();
          });

  });


  this.When(/^I navigate across the asset hierarchy to the turbine$/, function (callback) {
          casePage.navigateToTurbineUnderAssetHierarchy().then(function () {
              console.log("Turbine is selected");
              callback();

          })

  });

  this.Then(/^I click on ok button to select turbine$/, function (callback) {
          casePage.clickAssetSelectionOkButton().then(function () {
              callback();
          });

  });

  this.Then(/^I click on create case button$/, function (callback) {
          casePage.clickCreateCaseButton().then(function () {
              callback();
          });

  });

  this.When(/^I click the latest case from the inbox$/, function (callback) {
        casePage.clickLatestCaseFromInbox().then(function () {
            console.log("Click on latest case");
            callback();
        });

  });

  this.Then(/^I verify the turbine name present in Case details$/, function (callback) {
        casePage.verifyTurbineNameCaseDetails().then(function (value) {
            TestHelper.assertEqual(value,'Colorado Highlands 13', callback);
            callback();
        });

  });

  this.Then(/^I verify the turbine name present in Cases$/, function (callback) {
        casePage.verifyTurbineNameCaseDetails().then(function (value) {
            TestHelper.assertEqual(value,'Colorado Highlands 51', callback);
            callback();
        });

  });

  this.Then(/^I can verify the case title is (.*)$/, function (caseTitle,callback) {
        casePage.verifyCaseTitle().then(function (value) {
            TestHelper.assertEqual(value,caseTitle, callback);
            callback();
        });

  });

    this.When(/^I can validate the grid container$/, function (callback) {
       casePage.verifyGridContainer().then(function(){
          callback();
       });
    });

    this.Then(/^I enter the asset Id (.*)$/, function (assetId,callback) {
        casePage.assetId(assetId).then(function(){
            callback();
        });
    });

    this.Given(/^I can select case status as (.*)$/, function (status,callback) {
        casePage.changeStatus(status).then(function () {
            callback();
        });
    });

    this.Given(/^I can select urgency as (.*)$/, function (action,callback) {
        casePage.changeUrgency(action).then(function () {
            callback();
        });
    });

    this.Given(/^I can select urgency to (.*)$/, function (actions,callback) {
        casePage.changeUrgency1(actions).then(function () {
            callback();
        });
    });


    this.Then(/^I click on the Symptoms,Clear it and update with (.*)$/, function (arg1,callback) {
        casePage.enterSymptoms(arg1).then(function () {
            callback();
        });
    });

    this.Then(/^I can click on delete case button$/, function (callback) {
        casePage.deleteCasebtn().then(function () {
            callback();
        });
    });


    this.Then(/^I click on the Diagnosis and enter (.*)$/, function (arg1,callback) {
        casePage.enterDiagnosis(arg1).then(function () {
               callback();
        });
    });

     this.Then(/^I can validate delete conformation message$/, function (callback) {
        casePage.deleteCaseText().then(function () {
            callback();
        });
    });

    this.Then(/^I click on the Recommendation and enter (.*)$/, function (arg1,callback) {
        casePage.enterRecommendation(arg1).then(function () {
            callback();
        });
    });

    this.Then(/^I can click on delete case conformation button$/, function (callback) {
        casePage.deleteConfButton().then(function () {
            callback();
        });
    });

    this.Given(/^I can change case name (.*)$/, function (arg1,callback) {
        casePage.caseNameUpdate(arg1).then(function () {
            callback();
        });
    });

    this.Then(/^I can verify the Case status (.*) from UI$/, function (arg1,callback) {
        casePage.caseStatusValidate(arg1).then(function () {
            callback();
        });
    });

    this.Given(/^I can click on option sign$/, function (callback) {
        casePage.optionSign().then(function () {
            callback();
        });
    });

    this.Given(/^I can delete the case$/, function (callback) {
        casePage.deleteCase().then(function () {
            callback();
         });
    });

    this.Then(/^I can click on the Plan of the day App$/, function(callback) {
        taskMgmtPage.planofthedayMangTab().then(function() {
                 callback();
                });
         });

    this.Then(/^I can wait for the Task page$/, function(callback) {
        casePage.isTaskMangmntTabVisibile().then(function() {
                 callback();
                });
    });

    this.Then(/^I can click on the Task page link$/, function(callback) {
        casePage.taskpageTab().then(function() {
                 callback();
                });
    });

    this.Then(/^I can search the Task (.*)$/, function (caseTitle,callback) {
        casePage.searchTask(caseTitle).then(function(){
            callback();
        });
    });
    this.Then(/^I can verify the Task title is (.*)$/, function (caseTitle,callback) {
        casePage.verifyTaskTitle().then(function (value) {
            TestHelper.assertEqual(value,caseTitle, callback);
            callback();
        });

    });
    this.Then(/^I can select first case$/, function (callback) {
        casePage.selectCase().then(function () {
            callback();
        });
    });

    this.Then(/^User should able to select (.*) as site group only one site$/, function (site,callback) {
        casePage.selectSite1(site).then(function() {
            callback();
        });
    });

     this.Then(/^I can validate Information case details in dpod$/, function (callback) {
        casePage.InformationalTaskValidation().then(function () {
            callback();
        });
    });

    this.Then(/^I can validate Enterprise level case details in dpod$/, function (callback) {
        casePage.InformationalTaskValidation().then(function () {
            callback();
        });
    });
    this.Then(/^I verify the Enterprise name present in Case details$/, function (callback) {
        casePage.verifyTurbineNameCaseDetails().then(function (value) {
            TestHelper.assertEqual(value,'COHI', callback);
            callback();
        });

  });

  this.Then(/^I can validate task title is (.*) in dpod$/, function (noRecord,callback) {
        casePage.InfoTaskValidation().then(function (value) {
            TestHelper.assertEqual(value,noRecord, callback);
            callback();
        });

    });

    this.Then(/^I am able to validate action stage is recommended$/, function (callback) {
        casePage.recommendedSelected().then(function () {
            callback();
        });
    });

    this.Then(/^I can validate Immediate timeframe$/, function(callback) {
        casePage.actionTimeframe().then(function (completed) {
			assert.equal(completed, 'Before Continued Operation');
                         callback();
		});
	});

    this.Then(/^I can validate action purpose$/, function(callback) {
        casePage.actionPurpose().then(function (completed) {
			assert.equal(completed, 'Resolve');
                         callback();
		});
	});

    this.Then(/^I can validate Next Opportunity timeframe$/, function(callback) {
        casePage.actionTimeframe().then(function (completed) {
			assert.equal(completed, 'Next Available Opportunity');
                         callback();
		});
	});

    this.Then(/^I can validate Next Tower Climb timeframe$/, function(callback) {
        casePage.actionTimeframe().then(function (completed) {
			assert.equal(completed, 'Next Scheduled Outage');
                         callback();
		});
	});

    this.Given(/^I can refresh page$/, function () {
        browser.sleep(8000);
       return browser.driver.navigate().refresh();
    });

    this.Then(/^I can search the turbine (.*)$/, function (caseTitle,callback) {
        casePage.turbineSearch(caseTitle).then(function(){
            callback();
        });
    });

    this.Then(/^I can complete APM cases task in dpod$/, function (callback) {
        taskMgmtPage.completedTaskValidation().then(function() {
            callback();
        });
    });

    this.Then(/^I can verify action is planned$/, function (callback) {
        console.log('inside the action planned');
        casePage.plannedSelected().then(function () {
            callback();
        });
    });

    this.Then(/^I can take the turbine number$/, function (callback) {
        casePage.taskSearch().then(function (value) {
            //TestHelper.assertEqual(value,caseTitle, callback);
            console.log(value);
            callback();
        });

    });

    this.Then(/^I can validate Case status as Awaiting$/, function(callback) {
        casePage.validateCaseStatus().then(function (completed) {
			assert.equal(completed, 'Awaiting');
                         callback();
		});
	});

    this.Then(/^I can validate Case status as Open$/, function(callback) {
        casePage.validateCaseStatus().then(function (completed) {
			assert.equal(completed, 'Open');
                         callback();
		});
	});

    this.Then(/^I am able to validate action stage is Completed$/, function (callback) {
        casePage.completedSelected().then(function () {
            callback();
        });
    });

    this.Then(/^I can select closure code and close the case$/, function (callback) {
        casePage.selectClosureCodeandCloseCase().then(function () {
            callback();
        });
    });

  this.Then(/^I can validate Immediate timeframe for new Action$/, function(callback) {
      casePage.actionTimeframeNewAction().then(function (completed) {
        assert.equal(completed, 'Before Continued Operation');
                       callback();
     });
  });



  this.Then(/^I can validate action purpose for new Action$/, function(callback) {
      casePage.actionPurposeNewAction().then(function (completed) {
    assert.equal(completed, 'Resolve');
                       callback();
  });
});

  this.Then(/^I can validate action title$/, function(callback) {
      casePage.actionTitle().then(function (completed) {
          assert.equal(completed, 'Field Action');
          callback();
      });
  });

  this.Then(/^I can validate action title for new Action$/, function(callback) {
      casePage.actionTitleNewAction().then(function (completed) {
          assert.equal(completed, 'Field Action');
          callback();
      });
  });



 this.Then(/^I can validate action comments updated$/, function(callback) {
      casePage.actionComments().then(function (completed) {
          assert.equal(completed, 'Closed by APM Case');
          callback();
      });
  });

  this.Then(/^I can complete APM cases task in dpod with 1000 char$/, function (callback) {
        taskMgmtPage.completedTaskValidationWith1000Char().then(function() {
            callback();
        });
    });

    this.Then(/^I can validate Resolution notes in Cases action section$/, function (callback) {
        casePage.verifyCaseResolutionNotes().then(function () {
            callback();
        });
    });

    this.Then(/^I can validate 1000 char Resolution notes in Cases action section$/, function (callback) {
        casePage.verifyCase1000CharResolutionNotes().then(function () {
            callback();
        });
    });

    this.Then(/^I am able to validate APM case delete button in Task page$/, function (callback) {
        casePage.deleteBtnDisableTaskpage().then(function () {
            callback();
        });
    });

    this.Then(/^I can validate APM case task Duedate$/, function(callback) {
      casePage.taskDueDate().then(function (completed) {
          console.log("APM case task duedate is : "+completed);
          callback();
      });
  });

  this.Then(/^I can verify the Task Description$/, function (callback) {
            casePage.verifyTaskDescription().then(function (value) {
                TestHelper.assertEqual(value,"SYMPTOMS: This is Updated Symptoms | DIAGNOSIS: This is Diagnosis message | RECOMMENDATION: This is Recommendation message |", callback);
                callback();
            });

        });

    this.Then(/^I can verify the default Task Description$/, function (callback) {
            casePage.verifyTaskDescription().then(function (value) {
                TestHelper.assertEqual(value,"SYMPTOMS: N/A | DIAGNOSIS: N/A | RECOMMENDATION: N/A |", callback);
                callback();
            });

        });

        this.Then(/^I can validate APM case task Priority on DPOD task page$/, function(callback) {
      casePage.taskPriority().then(function (completed) {
          console.log("APM case task priority is : "+completed);
          callback();
      });
    });

    this.Then(/^I check the presence of Case Title$/, function(callback) {
      casePage.editCase().then(function (completed) {
          console.log("APM case Name is: "+completed);
          callback();
     });
   });

    this.Then(/^I click on cases header$/, function(callback) {
          casePage.clickCasesName().then(function () {
            console.log("Case Name clicked");
          callback();
      });
    });

    this.Then(/^I modify the case title as (.*)$/, function(newName,callback) {
          casePage.updateCaseName(newName).then(function () {
         console.log('Case Name is updated');
          callback();
      });
    });
    this.Then(/^I am able to validate action stage is planned$/, function (callback) {
        casePage.plannedSelected().then(function () {
            callback();
        });
    });

   
    this.Then(/^I am able to click on accept button of action$/, function (callback) {
        casePage.acceptActionButtonClicked().then(function () {
        callback();
        });
    });
    this.Then(/^I am able to click on accept button after accept action$/, function (callback) {
        casePage.acceptButtonClicked().then(function () {
        callback();
        });
    });
    this.Then(/^I verify the turbine name of Case details (.*)$/, function (turbineName,callback) {
        casePage.verifyTurbineNameCaseDetails().then(function (value) {
            TestHelper.assertEqual(value,turbineName, callback);
            callback();
        });
    });
    this.Then(/^I can get task status before action created$/, function (callback) {
        casePage.taskCurrentStatus().then(function (value) {
           oldStatus=value;
            console.log('Old Status '+oldStatus);
            callback();
        });
    });
    this.Then(/^I can get task status after action created$/, function (callback) {
        casePage.taskCurrentStatus().then(function (value) {
            newStatus=value;
            console.log('New Status '+newStatus);
            callback();
        });
    });
    this.Then(/^I can validate task status before and after action created$/, function (callback) {
        console.log('Status before and after task creation in DPOD is '+ oldStatus +' and '+newStatus);
        TestHelper.assertEqual(oldStatus,newStatus, callback);
       callback();
    });
    this.Then(/^I am able to click on create new case action button$/, function (callback) {
        casePage.createActionButtonClicked().then(function () {
        callback();
        });
    });
    this.Then(/^I enter the input action title (.*)$/, function (actionTitle,callback) {
        casePage.createActionTitle(actionTitle).then(function () {
            callback();
        });
    });
    this.Then(/^I am able to successfully create new case action$/, function (callback) {
        casePage.createActionCloseButtonClicked().then(function () {
        callback();
        });
    });
    this.Then(/^I am able to verify new case action created$/, function (callback) {
        casePage.latestActionCreated().then(function (value) {
        TestHelper.assertEqual('TestCaseAction',value, callback);
        callback();
        });
    });
    this.Then(/^I can verify the Task priority is (.*)$/, function (priority,callback) {
        casePage.verifyTaskPriority().then(function (value) {
            TestHelper.assertEqual(value,priority, callback);
            callback();
        });

    });
    this.Then(/^I am deleting the action (.*) from case (.*)$/, function (actionTitle,caseTitle, callback) {
        casePage.latestActionDelete().then(function () {
        callback();
        });
    });
    this.Then(/^I have deleted the action (.*) from case (.*)$/, function (actionTitle,caseTitle, callback) {
        casePage.actionDeleteYesButton().then(function () {
        callback();
        });
   });

   this.Then(/^I can select Action timeframe dropdown$/, function (callback) {
       casePage.changeTimeframe().then(function () {
         console.log("Selected Action Timeframe dropdown");
       callback();
       });
  });

  this.Then(/^I can select Action timeframe dropdown value$/, function (callback) {
      casePage.selectTimeframe().then(function () {
        console.log("Selected Action Timeframe dropdown value");
      callback();
      });
 });



};
