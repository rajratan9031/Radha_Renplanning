var currentPage = 'taskMgmtPage';
module.exports = function() {

      this.Given(/^I login to (.*)$/, function (env, callback) {
		env = browser.params.login.url;
		taskMgmtPage.getLogin(env).then(function (completed) {
			browser.ignoreSynchronization = true;
			assert.isTrue(completed, 'Not login page');
			callback();
		});
	});
	this.When(/^I authenticate with valid (.*) and (.*)$/, function (userName, password, callback) {
		userName = browser.params.login.username;
		password = browser.params.login.password;
		taskMgmtPage.setName(userName).then(function () {
			taskMgmtPage.setPassword(password).then(function () {
				taskMgmtPage.clickLogin().then(function () {
					callback();
				});
			});
		});
	});
	this.Then(/^User should able to click on Plan Management Tab$/, function(callback) {
        taskMgmtPage.planModuleTab().then(function () {

                         callback();
		});
	});
	this.Then(/^Verify User is able to see Plan Management Tab$/, function(callback) {
        taskMgmtPage.WaitForPlanModuleTab().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to click on Plan Management Tab$/, function(callback) {
        taskMgmtPage.planModuleTab().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on Plan Management Tab$/, function(callback) {
        taskMgmtPage.planModuleTab().then(function () {

                         callback();
		});
	});
	this.Then(/^I should able to View Task Management Tab$/, function(callback) {
        taskMgmtPage.isTaskMangmntTabVisibile().then(function () {
                         callback();
		});
	});

	this.Then(/^I should able to click on Task Management Tab$/, function(callback) {
        taskMgmtPage.taskMangmntTab().then(function () {
                         callback();
		});
	});
	 this.Then(/^I should see Task type available$/, function(callback) {
        taskMgmtPage.waitForturbineTaskStatusLink().then(function (completed) {
			assert.isTrue(completed, 'not a dPOD home page');
		console.log("User navigate into Task page");
                         callback();
		});
	});
	 this.When(/^I click on the Task type link$/, function(callback) {
        taskMgmtPage.turbineTaskStatusLink().then(function () {
                         callback();
		});
	});
	 this.Then(/^I should see task plan type info$/, function(callback) {
        taskMgmtPage.waitFortaskPlanTabInfo().then(function (completed) {
			assert.isTrue(completed, 'not a task plan tab');
                         callback();
		});
	});
	this.Then(/^I should able to click on Plan Management Module$/, function(callback) {
        taskMgmtPage.planModuleTab().then(function () {
                         callback();
		});
	});
	this.When(/^I click on Execution tab$/, function(callback) {
        taskMgmtPage.taskExecutionTab().then(function () {
                         callback();
		});
	});
	this.Then(/^I should see complete field$/, function(callback) {
        taskMgmtPage.compCompleteDate().then(function () {
                         callback();
		});
	});

      // Create Execution Management code
    this.Then(/^I should see Create button available$/, function(callback) {
        taskMgmtPage.waitForcreateButton().then(function () {
                         callback();
		});
	});
	 this.Then(/^I click on the Create button$/, function(callback) {
        taskMgmtPage.createButton().then(function () {
                         callback();
		});
	});
	 this.Then(/^I should see the Add task page$/, function(callback) {
        taskMgmtPage.waitFortitleField().then(function (completed) {
			assert.isTrue(completed, 'xxxxxxxxxxx');
                         callback();
		});
	});
	this.Then(/^I should enter the Title in Title field$/, function(callback) {
        taskMgmtPage.taskTitleField().then(function () {
                         callback();
		});
	});
     this.Then(/^I should enter text in Description field$/, function(callback) {
        taskMgmtPage.descriptionField().then(function () {
                         callback();
		});
	});
	this.Then(/^I should select the category type$/, function(callback) {
        taskMgmtPage.categoryDropdown1().then(function () {
                         callback();
		});
	});
  this.Then(/^I should select the group type$/, function(callback) {
        taskMgmtPage.groupDropdown().then(function () {
                         callback();
		});
	});
	this.Then(/^I should click on turbine select icon$/, function(callback) {
        taskMgmtPage.turbinesIcon().then(function () {
                         callback();
		});
	});
	this.Then(/^I should select turbine1$/, function(callback) {
        taskMgmtPage.turbines114().then(function () {

                         callback();
		});
	});
	this.Then(/^I should select turbine2$/, function(callback) {
        taskMgmtPage.turbines141().then(function () {

                         callback();
		});
	});
	this.Then(/^I should click on turbine Save button$/, function(callback) {
        taskMgmtPage.turbinesSelectionSaveBtn().then(function () {

                         callback();
		});
	});
	this.Then(/^I should select the Priority type$/, function(callback) {
        taskMgmtPage.priorityDropdown().then(function () {

                         callback();
		});
	});
	this.Then(/^I should select the Estimated Techs for the task$/, function(callback) {
        taskMgmtPage.estimatedTechsDropdown().then(function () {

                         callback();
		});
	});
	this.When(/^I should click on Eligibility date button for the task$/, function(callback) {
        taskMgmtPage.eligibilityDateBtn().then(function () {

                         callback();
		});
	});
	this.Then(/^I should select the Eligibility date for the task$/, function(callback) {
        taskMgmtPage.eligibilityDateSelection().then(function () {

                         callback();
		});
	});
	this.When(/^I should click on Due date button for the task$/, function(callback) {
        taskMgmtPage.dueDateBtn().then(function () {

                         callback();
		});
	});
	this.Then(/^I should select the Due date for the task$/, function(callback) {
        taskMgmtPage.dueDateSelection().then(function () {

                         callback();
		});
	});
	this.When(/^I should select the Recurrence type for the task$/, function(callback) {
        taskMgmtPage.recurrenceDropdown().then(function () {
			                         callback();
		   });
	});
	this.Then(/^I should click on End after radio button$/, function(callback) {
        taskMgmtPage.recurrenceEndAfterBtn().then(function () {
			                         callback();
		   });
	});
	this.Then(/^I should enter the End after occurrences$/, function(callback) {
        taskMgmtPage.recurrenceEndAfterOcc().then(function () {
			                         callback();
		   });
	});
	this.Then(/^I should enter the Parts needed text for the task$/, function(callback) {
        taskMgmtPage.partsNeededTxtField().then(function () {

                         callback();
		});
	});
	this.Then(/^I should enter the Tech Notes for the task$/, function(callback) {
        taskMgmtPage.techNotesTxtField().then(function () {

                         callback();
		});
	});
	this.Then(/^I should enter the POD or EOD Notes for the task$/, function(callback) {
        taskMgmtPage.pODEODNotesTxtField().then(function () {

                         callback();
		});
	});
	this.Then(/^I should click on Add button for creating the task$/, function(callback) {
        taskMgmtPage.clickAddBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I should click on task created success button$/, function(callback) {
        taskMgmtPage.successOkBtn().then(function () {
                         callback();
		});
	});
	this.When(/^I should able to enter text in search field$/, function(callback) {
        taskMgmtPage.activeSearchBtn().then(function () {
                         callback();
		});
	});

	this.When(/^I can able to search APM Cases$/, function(callback) {
        taskMgmtPage.activeSearchBtnAPMCases().then(function () {
                         callback();
		});
	});

	this.Then(/^I should able to view the newly created turbine1$/, function(callback) {
        taskMgmtPage.createdTaskTurbine1().then(function (completed) {
			console.log("Here is the Turbine name: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to view the newly created task status1$/, function(callback) {
        taskMgmtPage.createdTaskVerfication1().then(function (completed) {
			console.log("Here is the task status: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to view the newly created turbine2$/, function(callback) {
        taskMgmtPage.createdTaskTurbine2().then(function (completed) {
			console.log("Here is the Turbine name: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to view the newly created task status2$/, function(callback) {
        taskMgmtPage.createdTaskVerfication2().then(function (completed) {
			console.log("Here is the task status: "+ completed);
                         callback();
		});
	});
	this.When(/^I should able to select the first task$/, function(callback) {
        taskMgmtPage.turbineTaskStatusLink1().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to click on Edit button$/, function(callback) {
        taskMgmtPage.editTaskBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to click on Execution Section$/, function(callback) {
        taskMgmtPage.editExecutionTab().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to select the Completed task checkbox$/, function(callback) {
        taskMgmtPage.editTaskStatusCompletedChkbox().then(function () {
                         callback();
		});
	});
	this.Then(/^I should enter Actual duration$/, function(callback) {
        taskMgmtPage.actualDuration().then(function () {
                         callback();
		});
	});
	this.Then(/^I should select the Complete date$/, function(callback) {
        taskMgmtPage.editCompletedDateSelect().then(function () {
                         callback();
		});
	});
	this.Then(/^I should view the resolution notes section$/, function(callback) {
        taskMgmtPage.waitForeditResolutionField().then(function () {
                         callback();
		});
	});
	this.Then(/^I should enter the resolution notes$/, function(callback) {
        taskMgmtPage.editResolutionField().then(function () {
                         callback();
		});
	});
	this.Then(/^I should click on Save button$/, function(callback) {
        taskMgmtPage.editSaveBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to select second task$/, function(callback) {
        taskMgmtPage.turbineTaskStatusLink2().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to click on execution tab$/, function(callback) {
        taskMgmtPage.turbineTaskStatus2().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to complete second task$/, function(callback) {
        taskMgmtPage.editTaskStatus2().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to refresh the application$/, function(callback) {
        taskMgmtPage.applicationRefresh().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to view a completed task turbine1$/, function(callback) {
        taskMgmtPage.completedTaskTurbine1().then(function (completed) {
			console.log("Here is the Turbine name: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to view a completed task status1$/, function(callback) {
        taskMgmtPage.completedTaskVerification().then(function (completed) {
			console.log("Here is the task status: "+ completed);
			assert.equal(completed, 'completed');
                         callback();
		});
	});
	this.Then(/^I should able to view a completed task turbine2$/, function(callback) {
        taskMgmtPage.completedTaskTurbine3().then(function (completed) {
			console.log("Here is the Turbine name: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to view a completed task status2$/, function(callback) {
        taskMgmtPage.completedTaskVerification1().then(function (completed) {
			console.log("Here is the task status: "+ completed);
			assert.equal(completed, 'completed');
                         callback();
		});
	});
	this.Given(/^I should able to edit a completed task page$/, function(callback) {
        taskMgmtPage.editTaskpage().then(function () {
                         callback();
		});
	});
	this.When(/^I should able to edit a description field text$/, function(callback) {
        taskMgmtPage.editingDescriptionField().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to save edited information$/, function(callback) {
        taskMgmtPage.editSaveBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to verify edited description field text$/, function(callback) {
        taskMgmtPage.verifyEditedDescField().then(function (completed) {
			console.log("Here is the Description field text: "+ completed);
			assert.equal(completed, 'dPOD Testing');
                         callback();
		});
	});
	this.Then(/^I should able to validate completed Plan task$$/, function(callback) {
	   taskMgmtPage.testPlanCompleted().then(function(test){
		if (test == 'rgba(0, 0, 0, 0)') {
			browser.driver.sleep(6000);
			console.log('Test Planed Task is in completed status: ' + test);
			callback();
		  } else
		  {
	    console.log('else');
        taskMgmtPage.testPlanNotCompOperation().then(function () {
                        callback();
		    });
	     }
	});
     });
	this.Given(/^I should able to click on Add New or Existing task button$/, function(callback) {
        taskMgmtPage.addNewORexistingTaskBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to select the Exixting task radio button$/, function(callback) {
        taskMgmtPage.addExistingTaskRadioBtn().then(function () {
                         callback();
		});
	});
	this.When(/^I should able to click on Existing task dropdown$/, function(callback) {
        taskMgmtPage.existingTaskSelectDrpdwn().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to select Existing task$/, function(callback) {
        taskMgmtPage.selectAsset().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to select Existing task$/, function(callback) {
        taskMgmtPage.selectAsset1().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to click on Add button$/, function(callback) {
        taskMgmtPage.addButton().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to click on Save Conformation button$/, function(callback) {
        taskMgmtPage.saveConformationNoBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to click on Plus New task button$/, function(callback) {
        taskMgmtPage.addNewORexistingTaskBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to click on New task Add button$/, function(callback) {
        taskMgmtPage.addButton().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to create a new task$/, function(callback) {
        taskMgmtPage.taskCompletion().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to Save the added task$/, function(callback) {
        taskMgmtPage.workplanSaveBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to verify added task Title$/, function(callback) {
        taskMgmtPage.newlyAddedTask().then(function (completed) {
			console.log("Here is the Added task Title Name: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to click on Test planed task link$/, function(callback) {
        taskMgmtPage.testPlanedTaskLnk().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user able to create new crew by drag and drop at new crew option$/, function(callback) {
	TestHelperPO.isElementPresent(element(by.xpath('(//*[@ng-model="unassignedCrews"])[1]"]'))).then(function () {
                var src = element(by.xpath('(//*[@ng-model="unassignedCrews"])[1]'));
                var drop = element(by.css('.float--left.u-pr0.createNewCrewDrop.ng-pristine.ng-untouched.ng-valid.ui-droppable'));
		browser.actions().dragAndDrop(src,drop).mouseUp().perform();
                            callback();
			     });
               });

	       this.Then(/^User should able to click on right arrow in workplan$/, function(callback) {
        taskMgmtPage.workplanSideArrow().then(function () {
                        callback();
 		});
 	});
	this.Then(/^I can validate the Pending and completed task titles$/, function (callback) {
        taskMgmtPage.completedTaskValidation().then(function() {
            callback();
        });
    });
 	this.Then(/^User should able to click on add Task Icon$/, function(callback) {
         taskMgmtPage.workplanAddTurbineIcon().then(function () {
                          callback();
 		});
 	});
 	this.Then(/^User should able to click on add Task Radio button$/, function(callback) {
         taskMgmtPage.addExistingTaskRadioBtn4().then(function () {
                          callback();
 		});
 	});
 	this.Then(/^User should able to Successfully add a new Task in Work plan$/, function(callback) {
         taskMgmtPage.addExistingTask3().then(function () {
                         callback();
 		});
 	});
	this.Then(/^I should able to disable the multiple image task link$/, function(callback) {
        taskMgmtPage.MultipleCancelImage().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to enable the multiple image task link$/, function(callback) {
        taskMgmtPage.MultipleRefreshImage().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to edit and save the technician details$/, function(callback) {
        taskMgmtPage.editTechDetails().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to change the status to Mark as working and On call status$/, function(callback) {
        taskMgmtPage.markAsWorkingAndOnCallStatus().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to change the status to Mark as not working and not On call status$/, function(callback) {
        taskMgmtPage.markAsWorkingAndOnCallStatus().then(function () {
                         callback();
		});
	});
	this.When(/^I should able to Verify Turbine status widget name$/, function(callback) {
        taskMgmtPage.turbineStatusWidget().then(function (completed) {
		console.log("Here is the Description: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to see Faulted Turbine status$/, function(callback) {
        taskMgmtPage.faultedDetails().then(function (completed) {
		console.log("Here is the Faulted turbine status: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to see Stopped Turbine status$/, function(callback) {
        taskMgmtPage.stoppedDetails().then(function (completed) {
		console.log("Here is the Stopped turbine status: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to see Impacted Turbine status$/, function(callback) {
        taskMgmtPage.impactedDetails().then(function (completed) {
		console.log("Here is the Impacted turbine status: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to see Netcom Turbine status$/, function(callback) {
        taskMgmtPage.netcomDetails().then(function (completed) {
		console.log("Here is the Netcom turbine status: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to see Diagnostics Turbine status$/, function(callback) {
        taskMgmtPage.diagnosticsDetails().then(function (completed) {
		console.log("Here is the Diagnostics turbine status: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to see Faulted Turbine details$/, function(callback) {
        taskMgmtPage.faultedTurbines().then(function (completed) {
		console.log("Here is the Faulted turbine details: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to see Stopped Turbine details$/, function(callback) {
        taskMgmtPage.stoppedTurbines().then(function (completed) {
		console.log("Here is the Stopped turbine details: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to see Impacted Turbine details$/, function(callback) {
        taskMgmtPage.impactedTurbines().then(function (completed) {
		console.log("Here is the Impacted turbine details: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to see Netcom Turbine details$/, function(callback) {
        taskMgmtPage.netcomTurbines().then(function (completed) {
		console.log("Here is the Netcom turbine details: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to see Diagnostics Turbine details$/, function(callback) {
        taskMgmtPage.diagnosticsTurbines().then(function (completed) {
		console.log("Here is the Diagnostics turbine details: "+ completed);
                         callback();
		});
	});
	this.Given(/^I should able to click on Admin tab link$/, function(callback) {
        taskMgmtPage.adminTabInfo().then(function () {
                         callback();
		});
	});
	this.When(/^I should able to click on Personal info Add button$/, function(callback) {
        taskMgmtPage.adminAddButton().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to enter all the personal information of Contractor$/, function(callback) {
        taskMgmtPage.personalInformation().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to select site group info$/, function(callback) {
        taskMgmtPage.assginSiteCheckbox().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to validate success message$/, function(callback) {
        taskMgmtPage.personalInfoValidation().then(function (completed) {
		console.log("Here is the Contractor Personal info status: "+ completed);
                         callback();
		});
	});
	this.Then(/^I should able to click on Personal info save button$/, function(callback) {
        taskMgmtPage.personalInfoUpdateBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to validate SSO id$/, function(callback) {
        taskMgmtPage.personalInfoSSOValidation().then(function (completed) {
		console.log("Here is the SSO id: "+ completed);
                         callback();
		});
	});
	//To fectch Post plan details
	this.When(/^User should able to view the Plan module tab$/, function(callback) {
        taskMgmtPage.waitForcreateButton().then(function () {
                         callback();
		});
	});
	this.Then(/^User should navigates into Plan module$/, function(callback) {
        taskMgmtPage.planModule().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to view currentplan date$/, function(callback) {
        taskMgmtPage.workPlanDate().then(function (completed) {
	console.log("Here is the Current plan Date: "+ completed);
                         callback();
		});
	});

  this.Then(/^User click on the date to open the calendar$/, function(callback) {
        taskMgmtPage.clickWorkPlanDate().then(function () {
            callback();
        });
  });

  this.Then(/^User selects any date from the calendar$/, function(callback) {
        taskMgmtPage.selectDateFromCalendar().then(function () {
            callback();
        });
  });

  this.Then(/^User is able to select current date from calendar$/, function(callback) {
        taskMgmtPage.selectCurrentDateFromCalendar().then(function () {
            callback();
        });
  });

  this.Given(/^User is able to view currentplan date in work plan section$/, function(callback) {
        taskMgmtPage.fetchWorkPlanCurrentDate().then(function () {
            callback();
		});
	});

  this.Then(/^Verify currentplan date in work plan section$/, function(callback) {
        taskMgmtPage.verifyWorkPlanCurrentDate().then(function () {
            callback();
    });
  });

	this.Then(/^Verify user is able to navigates into post plan section$/, function(callback) {
        taskMgmtPage.pastPlanDateChaneIcon().then(function () {
                         callback();
		});
	});

	this.Then(/^Verify user is able to navigates into current plan section$/, function(callback) {
        taskMgmtPage.currentPlanDateIcon().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to view Post plan details$/, function(callback) {
        taskMgmtPage.workPlanDate().then(function (completed) {
	console.log("Here is the post plan Date: "+ completed);
                         callback();
		});
	});
		//Automation scripts for Q3-Sprint1

	this.Then(/^I should click on Task Management Tab$/, function(callback) {
        taskMgmtPage.taskMangmntTab().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify User user is able to click on Task Management Tab$/, function(callback) {
        taskMgmtPage.taskMangmntTab().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to see Create button available$/, function(callback) {
        taskMgmtPage.waitForcreateButton().then(function () {
                         callback();
		});
	});
	this.Then(/^I should click on the Create button$/, function(callback) {
        taskMgmtPage.createButton().then(function () {
                         callback();
		});
	});
	 this.Then(/^I should able to navigates into Add task page$/, function(callback) {
        taskMgmtPage.waitFortitleField().then(function (completed) {
			assert.isTrue(completed, 'xxxxxxxxxxx');
                         callback();
		});
	});
	this.Then(/^I should able to enter the Title in Title field$/, function(callback) {
        taskMgmtPage.titleField().then(function () {
                         callback();
		});
	});

     this.Then(/^I should able to enter text in Description field$/, function(callback) {
        taskMgmtPage.descriptionField().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to select the category type$/, function(callback) {
        taskMgmtPage.categoryDropdown2().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to click on turbine select icon$/, function(callback) {
        taskMgmtPage.turbinesIcon().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to select turbine1$/, function(callback) {
        taskMgmtPage.turbines114().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to click on turbine Save button$/, function(callback) {
        taskMgmtPage.turbinesSelectionSaveBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to select the Priority type$/, function(callback) {
        taskMgmtPage.priorityDropdown().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to select the Estimated Techs for the task$/, function(callback) {
        taskMgmtPage.estimatedTechsDropdown().then(function () {
                         callback();
		});
	});
	this.Then(/^I should click on Add button for creating New task$/, function(callback) {
        taskMgmtPage.clickAddBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able view the Error message$/, function(callback) {
        taskMgmtPage.clickErrorBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I should validate the Due date error message$/, function(callback) {
        taskMgmtPage.dueDateErrorMessage().then(function (completed) {
			console.log("Here is the Due date Error Message : "+ completed);
                         callback();
		});
	});
	// All Assigned Contractors available in the Crew ribbon should be appeared in the Current plan
	this.Given(/^I should validate first technician available in crew should appear in workplan$/, function(callback) {
        taskMgmtPage.crewThetaCrew1().then(function (crew) {
	taskMgmtPage.workPlanThetaCrew1().then(function (workplan) {
	  assert.equal(crew, workplan);
	  console.log("Here is the first technician details in Crew section : "+ crew);
	  console.log("Here is the first technician details in Workplan : "+ workplan);
                         callback();
	           });
	     });

	});
	this.When(/^I should validate second technician available in crew should appear in workplan$/, function(callback) {
        taskMgmtPage.crewThetaCrew2().then(function (crew) {
	taskMgmtPage.workPlanThetaCrew2().then(function (workplan) {
	  assert.equal(workplan, crew);
	  console.log("Here is the first technician details in Crew section : "+ crew);
	  console.log("Here is the second technician details in Workplan : "+ workplan);
                         callback();
	           });
	     });
	});
	this.Then(/^I should validate third technician available in crew should appear in workplan$/, function(callback) {
        taskMgmtPage.crewThetaCrew3().then(function (thetaCrew3) {
	taskMgmtPage.workPlanThetaCrew3().then(function (planthetaCrew3) {
	  assert.equal(planthetaCrew3, thetaCrew3);
	  console.log("Here is the Third technician details in Crew section : "+ thetaCrew3);
	  console.log("Here is the Third technician details in workplan : "+ planthetaCrew3);
                         callback();
	           });
	     });
	});
	this.Then(/^I should validate fourth technician available in crew should appear in workplan$/, function(callback) {
        taskMgmtPage.crewThetaCrew4().then(function (thetaCrew4) {
	taskMgmtPage.workPlanThetaCrew4().then(function (planthetaCrew4) {
	  assert.equal(planthetaCrew4, thetaCrew4);
	  console.log("Here is the fourth technician details in Crew section : "+ thetaCrew4);
	  console.log("Here is the fourth technician details in workplan : "+ planthetaCrew4);
                         callback();
	           });
	     });
	});
	// All Crews available in the Crew ribbon should appear in the Current plan
	this.Given(/^I should validate first Crew available in crew ribbon should appear in workplan$/, function(callback) {
        taskMgmtPage.crewNameInCrewsection().then(function (crew) {
	taskMgmtPage.crewNameInWPsection().then(function (workplan) {
	  //assert.equal(crew, workplan);
	  console.log("Here is the first Crew details in Crew section : "+ crew);
	  console.log("Here is the first Crew details in Workplan : "+ workplan);
                         callback();
	           });
	     });

	});
	this.Then(/^I should validate second Crew available in crew ribbon should appear in workplan$/, function(callback) {
        taskMgmtPage.crewNameInCrewsection1().then(function (crew) {
	taskMgmtPage.crewNameInWPsection1().then(function (workplan) {
	  //assert.equal(crew, workplan);
	  console.log("Here is the Second Crew details in Crew section : "+ crew);
	  console.log("Here is the Second Crew details in Workplan : "+ workplan);
                         callback();
	           });
	     });

	});
	// Crew Management - Remove All Users from Crew

	this.Given(/^Verify user is able to see removing technicians from a crew$/, function(callback) {
        taskMgmtPage.crewSection3().then(function (completed) {
	console.log("Here is the technician details in the Crew : "+ completed);
                         callback();
		});
	});
	this.When(/^Verify user is able to Click on technicians from a crew$/, function(callback) {
        taskMgmtPage.crewSection().then(function () {
                         callback();
	           });
	     });

	this.Then(/^Verify user is able to Click on Remove all techs from the crew section$/, function(callback) {
        taskMgmtPage.removeAllTech1().then(function () {
                         callback();
	           });
	     });
    // Task Management - Delete Tasks

	this.Given(/^Verify user is able to click on Task Management Tab$/, function(callback) {
        taskMgmtPage.taskMangmntTab().then(function () {
                         callback();
		});
	});
	this.When(/^Verify user is able to click on Delete Task button$/, function(callback) {
        taskMgmtPage.deleteTaskBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify Delete Task Conformation message$/, function(callback) {
        taskMgmtPage.deleteConformationText().then(function (completed) {
	assert.equal(completed, 'Are you sure you want to delete?');
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on Conformation button$/, function(callback) {
        taskMgmtPage.deleteConformationYesBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to Successfully deleted the task$/, function(callback) {
        taskMgmtPage.deleteConformationOKBtn().then(function () {
                         callback();
		});
	});
	//Task Management - Due date less than Added date
	this.Given(/^User should click on Task Management Tab$/, function(callback) {
        taskMgmtPage.taskMangmntTab().then(function () {
                         callback();
		});
	});
	 this.When(/^Verify user is able to see Create button available$/, function(callback) {
        taskMgmtPage.waitForcreateButton().then(function () {
                         callback();
		});
	});
	this.Then(/^Click on the Create button$/, function(callback) {
        taskMgmtPage.createButton().then(function () {
                         callback();
		});
	});

	 this.Then(/^User should navigates into Add task page$/, function(callback) {
        taskMgmtPage.waitFortitleField().then(function (completed) {
                         callback();
		});
	});

	this.Then(/^Enter the Title Name in Title field$/, function(callback) {
        taskMgmtPage.titleField().then(function () {
                         callback();
		});
	});
     this.Then(/^Enter Description in Description field$/, function(callback) {
        taskMgmtPage.descriptionField().then(function () {
                         callback();
		});
	});
	this.Then(/^Select the category type$/, function(callback) {
        taskMgmtPage.categoryDropdown().then(function () {
                         callback();
		});
	});
	this.Then(/^Click on turbine select icon$/, function(callback) {
        taskMgmtPage.turbinesIcon().then(function () {
                         callback();
		});
	});
	this.Then(/^Select the turbine1$/, function(callback) {
        taskMgmtPage.turbines114().then(function () {
                         callback();
		});
	});
	this.Then(/^Click on turbine Save button$/, function(callback) {
        taskMgmtPage.turbinesSelectionSaveBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Select the Priority type$/, function(callback) {
        taskMgmtPage.priorityDropdown().then(function () {
                         callback();
		});
	});
	this.Then(/^Select the Estimated Techs for the task$/, function(callback) {
        taskMgmtPage.estimatedTechsDropdown().then(function () {
                         callback();
		});
	});
	this.Then(/^Select the Due date previous to Added on date$/, function(callback) {
        taskMgmtPage.dueDateSelecting().then(function () {
                         callback();
		});
	});
	this.Then(/^Click on Add button for creating New task$/, function(callback) {
        taskMgmtPage.clickAddBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verifying the Error message conformation Text$/, function(callback) {
        taskMgmtPage.errorConformationText().then(function (completed) {
		console.log("Here is the Due date Error Message : "+ completed);
                         callback();
		});
	});
	this.Then(/^Click on Error message conformation OK button$/, function(callback) {
        taskMgmtPage.statusOKbtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verifying the Due date error message$/, function(callback) {
        taskMgmtPage.dueDateErrorMessage().then(function (completed) {
			console.log("Here is the Due date Error Message : "+ completed);
                         callback();
		});
	});
	// Sorting against the turbine
	this.When(/^Validating Turbine Display Name in turbine section, After sorting$/, function(callback) {
        taskMgmtPage.turbineModelInSearch().then(function (turbine) {
	taskMgmtPage.turbineModelInPane().then(function (TName) {
	  //assert.equal(turbine, TName);
	  console.log("Here is the Turbine Display Name : "+ turbine);
                         callback();
	           });
	     });
	});
	this.Then(/^Verify user is able to sort with Turbine name$/, function(callback) {
        taskMgmtPage.turbineNameSort().then(function () {
                         callback();
		});
	});
	this.Then(/^Validating Turbine Number in turbine section, After sorting$/, function(callback) {
        taskMgmtPage.turbineNameInSearch().then(function (turbine) {
	taskMgmtPage.turbineNameInPane().then(function (TName) {
	  //assert.equal(turbine, TName);
	  console.log("Here is the Turbine Name : "+ turbine);
                         callback();
	           });
	     });
	});
	this.Then(/^Verify user is able to sort with Last visit date$/, function(callback) {
        taskMgmtPage.lastVisitSort().then(function () {
                         callback();
		});
	});
	this.Then(/^Validating Last Visit Date in turbine section, After sorting$/, function(callback) {
        taskMgmtPage.lastVisitInSearch().then(function (turbine) {
	taskMgmtPage.lastVisitInPane().then(function (TName) {
	  //assert.equal(turbine, TName);
	  console.log("Here is the Last Visit Date : "+ turbine);
                         callback();
	           });
	     });
	});
	this.When(/^Verify user is able to sort with Next Maintenance task date$/, function(callback) {
        taskMgmtPage.nextTaskSort().then(function () {
                         callback();
		});
	});
    this.Then(/^Validating Next Task Maintenance Date in turbine section, After sorting$/, function(callback) {
        taskMgmtPage.nextTaskInSearch().then(function (turbine) {
	taskMgmtPage.nextTaskInPane().then(function (TName) {
	  //assert.equal(turbine, TName);
	  console.log("Here is the Next Task Maintenance Date : "+ turbine);
                         callback();
	           });
	     });
	});
   //Validation for the Task Estimated Duration Field
   this.Given(/^Verify user is navigate into Task Management Tab$/, function(callback) {
        taskMgmtPage.taskMangmntTab().then(function () {
                         callback();
		});
	});
	 this.When(/^Verify user is able to Validate Create button$/, function(callback) {
        taskMgmtPage.waitForcreateButton().then(function () {
                         callback();
		});
	});
	this.Then(/^Click on Create button$/, function(callback) {
        taskMgmtPage.createButton().then(function () {
                         callback();
		});
	});
	 this.Then(/^User should be in Add task page$/, function(callback) {
        taskMgmtPage.waitFortitleField().then(function (completed) {
			assert.isTrue(completed, 'xxxxxxxxxxx');
                         callback();
		});
	});
	this.Then(/^Verify user is able to enter the text in Title field$/, function(callback) {
        taskMgmtPage.titleField1().then(function () {
                         callback();
		});
	});
     this.Then(/^Verify user is able to enter text in Description field$/, function(callback) {
        taskMgmtPage.descriptionField().then(function () {
                         callback();
		});
	});
	this.Then(/^Selecting the category type$/, function(callback) {
        taskMgmtPage.categoryDropdown().then(function () {
                         callback();
		});
	});
	this.Then(/^Click on turbine menu icon$/, function(callback) {
        taskMgmtPage.turbinesIcon().then(function () {
                         callback();
		});
	});
	this.Then(/^Selecting the turbine1$/, function(callback) {
        taskMgmtPage.turbines43().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to Click on Turbine Save button$/, function(callback) {
        taskMgmtPage.turbinesSelectionSaveBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to Select the Priority type$/, function(callback) {
        taskMgmtPage.priorityDropdown().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to select the Estimated Techs for the task$/, function(callback) {
        taskMgmtPage.estimatedTechsDropdown().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to select the Due date for the task$/, function(callback) {
        taskMgmtPage.dueDateSelection().then(function () {
                         callback();
		});
	});
	this.When(/^Verify user is able to select the Recurrence type for the task$/, function(callback) {
        taskMgmtPage.recurrenceDropdown().then(function () {
			                         callback();
		   });
	});
	this.Then(/^Verify user is able to click on End after radio button$/, function(callback) {
        taskMgmtPage.recurrenceEndAfterBtn().then(function () {
			                         callback();
		   });
	});
	this.Then(/^Verify user is able to enter the End after occurrences$/, function(callback) {
        taskMgmtPage.recurrenceEndAfterOcc().then(function () {
			                         callback();
		   });
	});
	this.Then(/^Verify user is able to enter the Parts needed text for the task$/, function(callback) {
        taskMgmtPage.partsNeededTxtField().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to enter the Tech Notes for the task$/, function(callback) {
        taskMgmtPage.techNotesTxtField().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to enter the POD or EOD Notes for the task$/, function(callback) {
        taskMgmtPage.pODEODNotesTxtField().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on Add button for creating the task$/, function(callback) {
        taskMgmtPage.clickAddBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on task created success button$/, function(callback) {
        taskMgmtPage.successOkBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on Assigned contractor$/, function(callback) {
        taskMgmtPage.contractorNameClik().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on Edit contractor link$/, function(callback) {
        taskMgmtPage.editTechDetailsLink().then(function () {
                         callback();
		});
	});
	this.Then(/^User should ble to edit and save the technician details$/, function(callback) {
        taskMgmtPage.editTechDetails1().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify SSO field is editable in Edit Contractor details$/, function(callback) {
	TestHelperPO.isElementPresent(element(by.xpath('//*[@id="title"]'))).then(function () {
		expect(element(by.xpath('//*[@id="title"]')).isEnabled()).to.eventually.equal(false);
		//expect(sliderWidgetPage.getImageAndAttribute(0,'data-url')).to.eventually.equal('expectedValue').and.notify(done);
                            callback();
			     });

               });

	this.Then(/^Search with Site level Task in search field$/, function(callback) {
        taskMgmtPage.searchExistingTask().then(function () {
                         callback();
		});
	});

	this.Then(/^I click on the first task for first turbine in plan section$/, function(callback) {
			taskMgmtPage.clickOnFirstTask().then(function () {
			callback();
	 });
  });

	this.Then(/^I update the task title$/, function(callback) {
			taskMgmtPage.updatetaskTitle().then(function () {
			callback();
	  });
  });

	this.Then(/^I click on save button$/, function(callback) {
			taskMgmtPage.clickSaveButton().then(function () {
			callback();
	});
});


this.Then(/^I click on ok button for the success message$/, function(callback) {
			taskMgmtPage.clickOKButton().then(function () {
											 callback();
	});
});

this.Then(/^I verify if the task name is updated$/, function(callback) {
        taskMgmtPage.verifyTaskName().then(function (value) {
        TestHelper.assertEqual(value,'Updated Task Title', callback);
        callback();
    });
  });
  this.Then(/^I can click on Complete Task check box$/, function(callback) {
        taskMgmtPage.taskCompleteChkbox().then(function () {
                         callback();
		});
	});

	this.Then(/^Click on Plan page conformation message Cancel button$/, function(callback) {
	taskMgmtPage.planPageConfMsgCancelBtn().then(function() {
		callback();
	});
});

this.Then(/^Click on Plan page conformation message No button$/, function(callback) {
	taskMgmtPage.planPageConfMsgNoBtn().then(function() {
		callback();
	});
});
this.Then(/^Click on Task page conformation message Cancel button$/, function(callback) {
	taskMgmtPage.taskPageUnsavedCancelBtn().then(function() {
		callback();
	});
});
this.Then(/^Click on Report page conformation message Cancel button$/, function(callback) {
	taskMgmtPage.reportPageConfMsgCancelBtn().then(function() {
		callback();
	});
});
this.Then(/^Click on Report page conformation message No button$/, function(callback) {
	taskMgmtPage.reportPageConfMsgNoBtn().then(function() {
		callback();
	});
});
this.Then(/^Click on Report page conformation message Yes button$/, function(callback) {
	taskMgmtPage.reportPageConfMsgYesBtn().then(function() {
		callback();
	});
});
this.Then(/^User should able to select another site group$/, function(callback) {
	taskMgmtPage.siteGroupOtherSelect().then(function() {
		callback();
	});
});

/** for APM Case */
	this.Then(/^Click on APM Case task to display detail$/, function(callback) {
                taskMgmtPage.getAPMCaseDetail().then(function () {
                        console.log("Click on APM Case task to display detail");
                        callback();
                });
	});
	this.Then(/^Check if APM Case button is available on task details$/, function(callback) {
                taskMgmtPage.APMCaseBtnOnPlan().then(function () {
                        console.log("Case button is available on task details");
                        callback();
                });
	});
	this.Then(/^Verify user is able to Click on APM case Label$/, function(callback) {
		taskMgmtPage.validateAPMCaseURL(callback);
	});
	
	this.Then(/^Click on APM Case button$/, function(callback) {
                taskMgmtPage.ClickOnAPMCaseBtn().then(function () {
                        console.log("Closed popup error window");
                        callback();
                });
	});
	this.Then(/^Click on Execution tab$/, function(callback) {
                taskMgmtPage.ClickOnExeTab().then(function () {
                        console.log("Click on exe tab");
                        callback();
                });
	});
	this.Then(/^Check if APM Case button is available on execution tab$/, function(callback) {
                taskMgmtPage.APMCaseBtnOnExe().then(function () {
                        console.log("Click on exe tab");
                        callback();
                });
	});
	this.Then(/^Click on Edit icon$/, function(callback) {
                taskMgmtPage.ClickOnEditTaskIcon().then(function () {
                        console.log("Closed popup error window");
                        callback();
                });
	});
	this.Then(/^Check APM Case button on edit page execution tab$/, function(callback) {
                taskMgmtPage.APMCaseBtnOnEditExe().then(function () {
                        console.log("Click on exe tab");
                        callback();
                });
	});
	this.Then(/^Click on Plan tab in edit page$/, function(callback) {
                taskMgmtPage.ClickOnPlanTabInEdit().then(function () {
                        console.log("Click on plan tab");
                        callback();
                });
	});
	this.Then(/^Check if APM Case button is available on plan tab$/, function(callback) {
                taskMgmtPage.APMCaseBtnOnEditPlan().then(function () {
                        console.log("Click on plan tab");
                        callback();
                });
	});
	/** APM Case end */

	/**
	 * 
	 * Multi task delete
	 */
	this.Then(/^I should able to click on Task Page in left menu$/, function(callback) {
		taskMgmtPage.taskMangmntTabClick().then(function () {
			callback();
		});
	});

	this.Then(/^I should able to search APM Cases tasks$/, function(callback) {
		taskMgmtPage.searchAPMCasesTasks().then(function () {
			//assert.isTrue(completed, 'Unable to click on Crew Name');
			console.log("Search APM Case(s) type tasks");
			callback();
		});
	});

	this.When(/^I should able to find APM Cases tasks in search result$/, function(callback) {
		taskMgmtPage.isFoundAPMCasesTasks().then(function () {
			console.log("Check if APM Case(s) task found");
			callback();
		});
	});
	this.Given(/^Check if Delete button is disabled$/, function(callback) {
                taskMgmtPage.checkDeleteButtonDisabled().then(function () {
                        console.log("Check if done button disabled");
                        callback();
                });
        });
	this.Then(/^I should be able to select all tasks$/, function(callback) {
		taskMgmtPage.selectAllTasks().then(function () {
			console.log("select all tasks");
			callback();
		});
	});
	this.When(/^I should be able to check if Delete button is enabled$/, function(callback) {
                taskMgmtPage.checkDeleteButtonEnabled().then(function () {
                        console.log("Check if done button enabled");
                        callback();
                });
	});
	this.Given(/^Click on delete button at bottom$/, function(callback) {
                taskMgmtPage.clickOnDelete().then(function () {
                        console.log("Click on delete button at bottom");
                        callback();
                });
	});
	this.Then(/^Close APM Case error popup window$/, function(callback) {
                taskMgmtPage.closeAPMErrorPopup().then(function () {
                        console.log("Closed popup error window for APM Case");
                        callback();
                });
	});
	
	this.When(/^Click on task submenu to check if delete button is disabled$/, function(callback) {
                taskMgmtPage.checkDeleteButtonDisableForSingleTask().then(function () {
                        console.log("Check if delete button disabled for single task");
                        callback();
                });
	});

	this.When(/^Check if delete button is disabled on task detail page$/, function(callback) {
                taskMgmtPage.checkDeleteButtonDisableOnTaskDetail().then(function () {
                        console.log("Check if delete button is disabled on task detail page");
                        callback();
                });
	});
	this.When(/^Check if delete button is disabled on task edit page$/, function(callback) {
                taskMgmtPage.checkDeleteButtonDisableOnTaskEdit().then(function () {
                        console.log("Check if delete button is disabled on task edit page");
                        callback();
                });
	});
	this.When(/^Go back to task detail page$/, function(callback) {
                taskMgmtPage.goToTaskDetailPage().then(function () {
                        console.log("Go back to task detail page");
                        callback();
                });
	});
	this.When(/^I should be able to select single APM task$/, function(callback) {
                taskMgmtPage.selectSingleAPMTask().then(function () {
                        console.log("Go back to task detail page");
                        callback();
                });
	});
	this.Then(/^I should able to clear APM Cases tasks from search$/, function(callback) {
		taskMgmtPage.displayAllTasks().then(function () {
			console.log("I should able to clear APM Cases tasks from search");
			callback();
		});
	});
	this.Then(/^I should able to search non APM Case tasks$/, function(callback) {
		taskMgmtPage.displayNonAPMTasks().then(function () {
			console.log("I should able to search non APM Case tasks");
			callback();
		});
	});
	this.Then(/^I should be able to select first two tasks$/, function(callback) {
		taskMgmtPage.selectFirstTwoTasks().then(function () {
			console.log("I should be able to select first two tasks");
			callback();
		});
	});
	this.Then(/^Check warning message with note$/, function(callback) {
		taskMgmtPage.checkNoteWarningMsg().then(function () {
			console.log("Check warning message with note");
			callback();
		});
	});
	this.Then(/^Click on delete button in popup window$/, function(callback) {
		taskMgmtPage.multiDeleteFinalCall().then(function () {
			console.log("Click on delete button in popup window");
			callback();
		});
	});
	this.Then(/^I should be able to get delete success message$/, function(callback) {
		taskMgmtPage.taskDeleteSuccessMessge(callback);
	});
	
	/** Multi delete task ends */

	this.Then(/^I can select the Completed Task in Task page$/, function(callback) {
		taskMgmtPage.completedTaskSelect().then(function () {			
			callback();
		});
	});

	this.Then(/^I can change the Completed Task to Pending status$/, function(callback) {
		taskMgmtPage.completedToPendingTask().then(function () {			
			callback();
		});
	});

	this.Then(/^I can be able to Click on APM Case label in Turbine widget$/, function(callback) {
		taskMgmtPage.aPMCaseLabelTurbineWidget(callback);
	});

	this.Then(/^I can be able to Click on APM Case label in Task page plan tab$/, function(callback) {
		taskMgmtPage.aPMCaseLabelTasksPlanTab(callback);
	});

	this.Then(/^I can be able to Click on APM Case label in Task page Execution tab$/, function(callback) {
		taskMgmtPage.aPMCaseLabelTasksPlanTab(callback);
	});
	this.Then(/^I can be able to Click on APM Case label in Edit Task page$/, function(callback) {
		taskMgmtPage.aPMCaseLabelEditTasks(callback);
	});
	this.Then(/^I can be able to Click on APM Case label in Edit Execution Task page$/, function(callback) {
		taskMgmtPage.aPMCaseLabelEditTasksExecutionTab(callback);
	});

	/** Report column changes -start */
	this.Then(/^Click on Turbines Operating in Reduced Status Show hide column$/, function(callback) {
		taskMgmtPage.showHideColumnInTurbineOperating().then(function () {
			callback();
		});
	});
	this.Then(/^Check Planned on and Due on available$/, function(callback) {
		taskMgmtPage.checkPlannedOnDueOnAvailable().then(function () {
			callback();
		});
	});
	this.Then(/^Select Planned on and Due on date$/, function(callback) {
		taskMgmtPage.selectPlannedOnDueOnInTurbine();
		callback();
	});

	this.Then(/^Click on Planned Maintenance Show hide column$/, function(callback) {
		taskMgmtPage.showHideColumnInPlannedMaintenance().then(function () {
			callback();
		});
	});
	this.Then(/^Check Planned on and Due on available in Planned Maintenance$/, function(callback) {
		taskMgmtPage.checkPlannedOnDueOnAvailableInPlannedMaintenance().then(function () {
			callback();
		});
	});
	this.Then(/^Select Planned on and Due on date in Turbines Operating$/, function(callback) {
		taskMgmtPage.selectPlannedOnDueOnInPlannedMaintenance().then(function () {
			callback();
		});
	});
	this.Then(/^Verify user is able to click on Plan of the day Tab$/, function(callback) {
		taskMgmtPage.reportPODayTab().then(function () {
			callback();
		});
	});
	this.Then(/^Verify user is able to click on End of the Day tab$/, function(callback) {
		taskMgmtPage.reportEODayTab().then(function () {
			callback();
		});
	});
	this.Then(/^Verify user is able to click on End of the Day tab for save$/, function(callback) {
		taskMgmtPage.reportEODayTabSave().then(function () {
			callback();
		});
	});
	this.Then(/^Verify user is able to click on Technician report tab$/, function(callback) {
		taskMgmtPage.reportTechnicainTab().then(function () {
			callback();
		});
	});
	this.Then(/^Verify user is able to click on Technician report tab for save$/, function(callback) {
		taskMgmtPage.reportTechnicainTabSave().then(function () {
			callback();
		});
	});
	this.Then(/^Click on Planned Maintenance Show hide column in Technician$/, function(callback) {
		taskMgmtPage.showHideColumnInTechncian().then(function () {
			callback();
		});
	});
	this.Then(/^Check Planned on and Due on available in Technician$/, function(callback) {
		taskMgmtPage.checkPlannedOnDueOnAvailableInechncian().then(function () {
			callback();
		});
	});
	this.Then(/^Select Planned on and Due on date in Technician$/, function(callback) {
		taskMgmtPage.selectPlannedOnDueOnInTechnician().then(function () {
			callback();
		});
	});
	
	/** Report column changes -end */

	this.Then(/^I can able to click on Turbine asset type checkbox$/, function(callback) {
		taskMgmtPage.assetTypeTurbine().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select on APM Case Task type checkbox$/, function(callback) {
		taskMgmtPage.taskTypeAPMChkbox().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select on Maintenance Task type checkbox$/, function(callback) {
		taskMgmtPage.taskTypeMaintenance().then(function () {
			callback();
		});
	});
 


};
