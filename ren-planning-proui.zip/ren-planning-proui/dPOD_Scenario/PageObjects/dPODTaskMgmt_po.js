(function() {
    'use strict';

    var currentPage = 'taskMgmtPage';
    var workPlanCurrentDate;
    var storeCountTurbinesOnline;
    var storeWeatherWidgetSiteName;
    var text;

    var TaskMgmtPage = function() {

        return {
            get: function () {
                return browser.driver.get(browser.params.login.baseUrl);
                browser.waitForAngular();
            },
            setName: function (username) {
                return cem.findElement(currentPage,'username').sendKeys(username);
            },
            setPassword: function (password) {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'password').sendKeys(password);
            },
            clickLogin: function () {
                return cem.findElement(currentPage,'password').sendKeys(protractor.Key.ENTER);
            },
            getLogin: function (url) {
                browser.driver.get(browser.params.login.baseUrl)
                return browser.driver.isElementPresent(by.xpath(browser.params.login.btn));
            },

			waitForturbineTaskStatusLink: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(11000);
			 return TestHelper.isElementPresent(currentPage,'turbineTaskStatusLink');
            },

            turbineTaskStatusLink: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'turbineTaskStatusLink').click();
            },

           waitFortaskPlanTabInfo: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(15000);
				 return TestHelper.isElementPresent(currentPage,'taskPlanTabInfo');
            },

			taskExecutionTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'taskExecutionTab').click();
            },
            compCompleteDate: function() {
				 browser.waitForAngular();
                 var date = cem.findElement(currentPage,'date').getText();
                 return date;

            },
           taskTypetext1: function() {
				 browser.waitForAngular();
                 var taskType = cem.findElement(currentPage,'taskType1').getText();
                 return taskType;

            },

			taskExecutionTabComplDate: function() {
				 browser.waitForAngular();
                 var exeComplDate = cem.findElement(currentPage,'exeTabCompleteDateField').getText();
                 return exeComplDate;
            },
			taskMainCompleteDate: function() {
				 browser.waitForAngular();
                 var exeComplDate1 = cem.findElement(currentPage,'completeDateField').getText();
                 return exeComplDate1;
            },

            //Create Execution code
            waitForcreateButton: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(12000);
			 return TestHelper.isElementPresent(currentPage,'createButton');
            },


             isTaskMangmntTabVisibile: function () {
             browser.waitForAngular();
             browser.driver.sleep(12000);
			 return TestHelper.isElementPresent(currentPage,'taskMangmntTab');
            },

            taskMangmntTab: function () {
                browser.driver.sleep(12000);
                return cem.findElement(currentPage,'taskMangmntTab').click();
                 },

            createButton: function () {
                browser.waitForAngular();
                browser.driver.sleep(30000);
                return cem.findElement(currentPage,'createButton').click();
            },

           waitFortitleField: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(10000);
				 return TestHelper.isElementPresent(currentPage,'titleField');
            },

			titleField: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'titleField').sendKeys('Automation_Testing');
            },
	    taskTitleField: function () {
                browser.driver.sleep(5000);
                text = "Automation " +  Math.random() + "_Testing";
                return cem.findElement(currentPage, 'titleField').sendKeys(text + protractor.Key.TAB);
            },
            siteLeveltitleField: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteLeveltitleField').sendKeys('Site_Task_Creation');
            },
			titleField1: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'titleField').sendKeys('Delete_Task');
            },
			descriptionField: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'descriptionField').sendKeys('Automation Testing');
            },

			categoryDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
               return cem.findElement(currentPage,'categorySelect').click();
            },
            groupDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'groupDropdown').click();
            },

            turbinesIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'turbinesIcon').click();
            },
            turbineSearch: function (Value) {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'turbineSearch').sendKeys(Value);

            },
            turbineSelectAll: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage,'turbineSelectAll').click();
            },
            turbines114: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'turbines114').click();
            },
            turbines43: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'turbines43').click();
            },
            turbines141: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'turbines141').click();
            },
            turbinesSelectionSaveBtn: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage,'turbinesSelectionSaveBtn').click();
            },
            priorityDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'priorityDropdown').click();
            },
            sitePriorityDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'sitePriorityDropdown').click();
            },
            estimatedTechsDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'estimatedTechsDropdown').click();
            },
            siteEstimatedTechsDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'siteEstimatedTechsDropdown').click();
            },
            dueDateBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'dueDateBtn').click();
            },
            dueDateSelection: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'dueDateSelection').click();
            },
            eligibilityDateBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'eligibilityDateBtn').click();
            },
            eligibilityDateSelection: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'eligibilityDateSelection').click();
            },
            recurrenceDropdown: function () {
               browser.waitForAngular();
               browser.driver.sleep(5000);
                return cem.findElement(currentPage,'recurrenceDropdown').click();
            },
            recurrenceEndAfterBtn: function () {
                browser.waitForAngular();
                 return cem.findElement(currentPage,'recurrenceEndAfterBtn').click();
            },
             recurrenceEndAfterOcc: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage,'recurrenceEndAfterTxt').sendKeys('2');
            },


           partsNeededTxtField: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage,'partsNeededTxtField').sendKeys('Automation Testing');
            },
            techNotesTxtField: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage,'techNotesTxtField').sendKeys('Automation Testing');
            },
            pODEODNotesTxtField: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage,'pODEODNotesTxtField').sendKeys('Automation Testing');
            },
            clickOnChoosefile: function () {
                browser.waitForAngular();
                 cem.findElement(currentPage,'clickOnChoosefile').click();
                 return cem.findElement(currentPage,'clickOnChoosefile').sendKeys("C://Users//Public//Pictures//Sample Pictures//Desert");
            },
            clickOpen: function () {
                return cem.findElement(currentPage,'password').sendKeys(protractor.Key.ENTER);
            },
             clickAddBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'clickAddBtn').click();
            },
            clickErrorBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'clickErrorBtn').click();
            },
            successOkBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'successOkBtn').click();
            },
             activeSearchBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return cem.findElement(currentPage,'activeSearchBtn').sendKeys('Automation_Testing');
            },

            activeSearchBtnAPMCases: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return cem.findElement(currentPage,'activeSearchBtn').sendKeys('APM Case');
            },

            otherTaskSearch: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return cem.findElement(currentPage,'activeSearchBtn').sendKeys('Other');
            },

            activeSearchBtn1: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage,'activeSearchBtn').sendKeys('Delete_Task');
            },
             createdTaskVerfication1: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'createdTaskVerfication1').getText();
            },
             createdTaskVerfication2: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'createdTaskVerfication2').getText();
            },
            createdTaskTurbine1: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage,'createdTaskTurbine1').getText();
            },
            createdTaskSite: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage,'createdTaskSite').getText();
            },
            createdTaskTurbine2: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'createdTaskTurbine2').getText();
            },
            completedTaskTurbine1: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'completedTaskTurbine1').getText();
            },
            completedTaskTurbine3: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'completedTaskTurbine3').getText();
            },
            completedTaskVerification: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage,'completedTaskVerification').getText();
            },
            completedTaskVerification1: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'completedTaskVerification1').getText();
            },
            turbineTaskStatusLink1: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'turbineTaskStatusLink1').click();
            },
            planModuleTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return cem.findElement(currentPage,'planModuleTab').click();
            },
            WaitForPlanModuleTab: function() {
				 browser.waitForAngular();
			 return TestHelper.isElementPresent(currentPage,'planModuleTab');
            },
            editTaskBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'editTaskBtn').click();
            },
            editExecutionTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage,'editExecutionTab').click();
            },
            editTaskStatusCompletedChkbox: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'editTaskStatusCompletedChkbox').click();
            },
            editCompletedDatePic: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'editCompletedDatePic').click();
            },
            editCompletedDateSelect: function () {
                browser.waitForAngular();
                //cem.findElement(currentPage,'editCompletedMonthSelect').click();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'editCompletedDateSelect').click();
            },

           waitForeditResolutionField: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(4000);
			     return TestHelper.isElementPresent(currentPage,'editResolutionField');
                  },
            editResolutionField: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage,'editResolutionField').sendKeys('Resolution notes');
            },
            editSaveBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                cem.findElement(currentPage,'editSaveBtn').click();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage,'successOkBtn').click();
            },
            turbineTaskStatusLink2: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                cem.findElement(currentPage,'activeSearchBtn').sendKeys('Automation_Testing');
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'turbineTaskStatusLink1').click();
            },
            turbineTaskStatus2: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                cem.findElement(currentPage,'editTaskBtn').click();
                browser.driver.sleep(5000);
               return cem.findElement(currentPage,'editExecutionTab').click();
            },
            editTaskStatus2: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'editTaskStatusCompletedChkbox').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'actualDuration').sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'actualDuration').sendKeys(protractor.Key.DELETE);
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'actualDuration').sendKeys('08');;
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'editResolutionField').sendKeys('Resolution notes');
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'editSaveBtn').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'successOkBtn').click();
                 },
            applicationRefresh: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                cem.findElement(currentPage,'dashboardTab').click();
                browser.driver.sleep(10000);
                cem.findElement(currentPage,'taskTab').click();
                browser.driver.sleep(10000);
               return cem.findElement(currentPage,'activeSearchBtn').sendKeys('Automation_Testing');
            },
            completedTaskVerfication2: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
               return cem.findElement(currentPage,'createdTaskAssertion2').getText();
            },
            planModule: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
               return cem.findElement(currentPage,'dashboardTab').click();
            },
            completedTaskTurbine2: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
               return cem.findElement(currentPage,'completedTaskTurbine2').getText();
            },
            categoryDropdown1: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
               return cem.findElement(currentPage,'categoryDropdown1').click();
            },
            categoryDropdown2: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
               return cem.findElement(currentPage,'categoryDropdown2').click();
            },
            editTaskpage: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                cem.findElement(currentPage,'turbineTaskStatusLink1').click();
                browser.driver.sleep(7000);
               return cem.findElement(currentPage,'editTaskBtn').click();
            },
            editingDescriptionField: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                cem.findElement(currentPage,'descriptionField').clear();
                browser.driver.sleep(8000);
               return cem.findElement(currentPage,'descriptionField').sendKeys('dPOD Testing');
            },
            verifyEditedDescField: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                cem.findElement(currentPage,'turbineTaskStatusLink1').click();
                browser.driver.sleep(6000);
               return cem.findElement(currentPage,'descriptionText').getText();
            },
            dueDateErrorMessage: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
               return cem.findElement(currentPage,'dueDateErrorMessage').getText();
            },
           dueDateSelecting: function () {
                browser.waitForAngular();
                cem.findElement(currentPage,'dueDateCalendar').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'dueDateCalenderIcon').click();
                browser.driver.sleep(5000);
               return cem.findElement(currentPage,'dueDateSelect').click();
            },

            crewThetaCrew1: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
               return cem.findElement(currentPage,'crewThetaCrew1').getText();
            },
            crewThetaCrew2: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
               return cem.findElement(currentPage,'crewThetaCrew2').getText();
            },
            crewThetaCrew3: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
               return cem.findElement(currentPage,'crewThetaCrew3').getText();
            },
            crewThetaCrew4: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
               return cem.findElement(currentPage,'crewThetaCrew4').getText();
            },
            workPlanThetaCrew1: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
               return cem.findElement(currentPage,'workPlanThetaCrew1').getText();
            },
            workPlanThetaCrew2: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
               return cem.findElement(currentPage,'workPlanThetaCrew2').getText();
            },
            workPlanThetaCrew3: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
               return cem.findElement(currentPage,'workPlanThetaCrew3').getText();
            },
            workPlanThetaCrew4: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
               return cem.findElement(currentPage,'workPlanThetaCrew4').getText();
            },
             crewSection3: function () {
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'crewSection3').getText();
                 },
                crewSection: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'crewSection3').click();
                 },
                removeAllTech: function () {
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'removeAllTech').click();
                 },
                removeAllTech1: function () {
                browser.driver.sleep(6000);
                cem.findElement(currentPage,'removeAllTech').click();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'removeAllTechNoBtn').click();
                 },

                deleteTaskBtn: function () {
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'deleteTaskBtn').click();
                 },

                 deleteConformation: function () {
                 browser.driver.sleep(6000);
                 cem.findElement(currentPage,'deleteTaskBtn').click();
                 browser.driver.sleep(5000);
                return cem.findElement(currentPage,'deleteConformationYesBtn').click();
                 },

              deleteConformationYesBtn: function () {
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'deleteConformationYesBtn').click();
                 },

                deleteConformationText: function () {
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'deleteConformationText').getText();
                 },
                deleteConformationOKBtn: function () {
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'deleteConformationOKBtn').click();
                 },
                 errorConformationText: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'errorConformationText').getText();
                 },
                statusOKbtn: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'statusOKbtn').click();
                 },

                 turbineTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(15000);
                return cem.findElement(currentPage,'turbineTab').click();
                 },

                 deleteHashTag: function () {
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'deleteHashTag').click();
                 },
                 waitForclickOnHashTag: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(12000);
			     return TestHelper.isElementPresent(currentPage,'clickOnHashTag');
                  },
                  waitFortaskCompleteIcon: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(4000);
			     return TestHelper.isElementPresent(currentPage,'waitFortaskCompleteIcon');
                  },

                 clickOnHashTag: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'clickOnHashTag').click();
                 },
                createHashTag: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'hashTagTextField').sendKeys('Test_UAT');
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'textClick').click();
                 },

               turbineLandingSearch: function () {
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'turbineLandingSearch').sendKeys('101');
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'selectFirstTurbine').click();
                 },

                selectFirstTurbine: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'selectFirstTurbine').click();
                 },

              turbineNameInSearch: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'turbineNameInSearch').getText();
                 },

              turbineModelInSearch: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'turbineModelInSearch').getText();
                 },
            lastVisitInSearch: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'lastVisitInSearch').getText();
                 },
             nextTaskInSearch: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'nextTaskInSearch').getText();
                 },
             turbineNameInPane: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'turbineNameInPane').getText();
                 },
             turbineModelInPane: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'turbineModelInPane').getText();
                 },
            lastVisitInPane: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'lastVisitInPane').getText();
                 },
            nextTaskInPane: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'nextTaskInPane').getText();
                 },

              turbineDisplayNameSort: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'sortMenuTab').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'turbineDisplayNameSort').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'sortMenuTab').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'selectFirstTurbine').click();
                 },
              turbineNameSort: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'sortMenuTab').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'turbineNameSort').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'sortMenuTab').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'selectFirstTurbine').click();
                 },
              turbineModelSort: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'sortMenuTab').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'turbineModelSort').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'sortMenuTab').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'selectFirstTurbine').click();
                 },
             lastVisitSort: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'sortMenuTab').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'lastVisitSort').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'sortMenuTab').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'selectFirstTurbine').click();
                 },
             nextTaskSort: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'sortMenuTab').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'nextTaskSort').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'sortMenuTab').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'selectFirstTurbine').click();
                 },
                 waitForturbineTab: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(9000);
			     return TestHelper.isElementPresent(currentPage,'turbineTab');
                  },
                waitForturbineNames: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(8000);
			     return TestHelper.isElementPresent(currentPage,'turbineHomePage');
                  },
                turbineLanding: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'turbineHomePage').click()
                },

             fromDateRangeSearch: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                cem.findElement(currentPage,'turbineFromDate').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'turbineFromDateIcon').click();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'turbineFromDateSelect').click();
                 },
                toDateRangeSearch: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'turbineToDate').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'turbineToDateToday').click();
                 },
                dateRangeSearchFld: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'turbineHistorySearch').sendKeys('Testing1');
                 },
                planSaveBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage,'planSaveBtn').click();
                 },
                planRunBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage,'planRunBtn').click();
                 },
                reportsTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return cem.findElement(currentPage,'reportsTab').click();
                 },
                 waitForreportsTab: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(15000);
				 return TestHelper.isElementPresent(currentPage,'reportsTab');
            },
                reportsPerformanceBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage,'reportsPerformanceBtn').click();
                 },
                reportsSiteContractsBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'reportsSiteContractsBtn').click();
                 },
                turbineInReducedTask: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'turbineInReducedTask').click();
                 },
                reportsSaveBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(17000);
                return cem.findElement(currentPage,'reportsSaveBtn').click();
                 },
                reportsPreviewBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'reportsPreviewBtn').click();
                 },
                reportsPrintToEmailBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'reportsPrintToEmailBtn').click();
                 },
                reportsInPlnnedMntTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'reportsInPlnnedMntTab').getText();
                 },
                turbineInPlnnedMnt: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'turbineInPlnnedMnt').getText();
                 },
               taskInPlnnedMnt: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'taskInPlnnedMnt').getText();
                 },
                reportWeatherDetails: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(2000);
			     return cem.findElement(currentPage,'reportWeatherDetails').getText();
                  },
                reportWeatherDate: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(2000);
			     return cem.findElement(currentPage,'reportWeatherDate').getText();
                  },

                reportWeatherSky: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(2000);
			     return cem.findElement(currentPage,'reportWeatherSky').getText();
                  },
                reportWeatherWind: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(2000);
			     return cem.findElement(currentPage,'reportWeatherWind').getText();
                  },
                reportWeatherWindDirection: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(2000);
			     return cem.findElement(currentPage,'reportWeatherWindDirection').getText();
                  },
                reportEODTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return cem.findElement(currentPage,'reportEODTab').click();
                 },
            isreportTORSAddTowerVisibile: function () {
             browser.waitForAngular();
             browser.driver.sleep(8000);
			 return TestHelper.isElementPresent(currentPage,'reportTORSAddTower');
            },
                reportTORSAddTower: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage,'reportTORSAddTower').click();
                 },
                reportAddTaskDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'reportAddTaskDropdown').click();
                browser.driver.sleep(5000);
                //cem.findElement(currentPage,'reportAddTaskSearch').sendKeys('10');
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'reportAddTaskSelect').click();
                 browser.driver.sleep(3000);
                 return cem.findElement(currentPage,'reportAddTaskBtn').click();
                },
                isreportPMAddTowerVisibile: function () {
               browser.waitForAngular();
               browser.driver.sleep(8000);
	          return TestHelper.isElementPresent(currentPage,'reportPMAddTower');
               },
             reportPMAddTower: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'reportPMAddTower').click();
                 },
                reportPMAddTaskDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'reportPMAddTaskDropdown').click();
                browser.driver.sleep(2000);
                //cem.findElement(currentPage,'reportPMAddTaskSearch').sendKeys('11');
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'reportPMAddTaskSelect').click();
                 browser.driver.sleep(2000);
                 return cem.findElement(currentPage,'reportPMAddTaskBtn').click();
                },
              waitForreportArchiveBtn: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(12000);
				 return TestHelper.isElementPresent(currentPage,'reportEODArchivebtn');
            },
                 reportArchiveBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(20000);
                return cem.findElement(currentPage,'reportEODArchivebtn').click();
                 },
                reportEODArchivePDFReport: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'reportEODArchivePDFReport').getText();
                 },
                 addExistingTaskRadioBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'addExistingTaskRadioBtn').click();
            },
            addNewORexistingTaskBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage,'addNewORexistingTaskBtn').click();
            },
            saveConformationNoBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'saveConformationNoBtn').click();
            },

            checkWorkDuration: function () {
                browser.waitForAngular();
                return TestHelper.isElementPresent(currentPage,'workDurationSection');
            },

            displayWorkDuration: function () {
              browser.waitForAngular();
              browser.driver.sleep(12000);
              return cem.findElement(currentPage,'workDuration').getAttribute('value');
            },

            clickCrewName: function () {
              browser.waitForAngular();
              browser.driver.sleep(4000);
              return TestHelper.elementToBeClickable(currentPage,'crewNameInCrewsection');
            },


            updateCrewName: function () {
                      browser.waitForAngular();
                      browser.driver.sleep(4000);
                      cem.findElement(currentPage,'crewNameEdit').clear();
                      var newCrewName= TestHelper.getRandomString();
                      return cem.findElement(currentPage,'crewNameEdit').sendKeys(newCrewName);
            },

            clickCrewsHeader: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'crewsHeader').click();
            },
            //
            // waitForRecipientButton: function() {
            //     browser.waitForAngular();
            //     browser.driver.sleep(5000);
            //     return TestHelper.isElementPresent(currentPage,'recipientButton');
            // },

            clickRecipientButton: function() {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage,'recipientButton').click();
            },

            addRecipientEmailId: function() {
                browser.waitForAngular();
                return cem.findElement(currentPage,'recipientEmailId').sendKeys('testmail@ge.com');
            },

            clickBackButton: function() {
                browser.waitForAngular();
                return cem.findElement(currentPage,'recipientBackButton').click();
            },

            waitForRecipientButton: function() {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return TestHelper.isElementPresent(currentPage,'recipientButton');
            },

            checkRecipientEmailId: function() {
                browser.waitForAngular();
                return TestHelper.isElementPresent(currentPage,'recipientEmailAdded');
            },

            clickPreviewButton: function() {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage,'previewButton').click();
            },


            checkPrintToEmailButton: function() {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return TestHelper.isElementPresent(currentPage,'printToEmailButton');
            },

            clickCancelButton: function() {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage,'cancelButton').click();
            },

            clickOnFirstTask: function () {
               browser.waitForAngular();
               return cem.findElement(currentPage,'clickOnFirstTask').click();
           },

           updatetaskTitle: function () {
                     browser.waitForAngular();
                     browser.driver.sleep(4000);
                     cem.findElement(currentPage,'titleField').clear();
                     return cem.findElement(currentPage,'titleField').sendKeys('Updated Task Title');
           },

           clickSaveButton: function () {
              browser.waitForAngular();
              browser.driver.sleep(8000);
              return cem.findElement(currentPage,'clickOnSaveButton').click();
          },


          clickOKButton: function () {
              browser.waitForAngular();
              browser.driver.sleep(5000);
              return cem.findElement(currentPage,'clickOKButton').click();
          },

          verifyTaskName: function () {
             return TestHelper.isElementPresent(currentPage,'clickOnFirstTask').then(function(){
             var element = cem.findElement(currentPage,'clickOnFirstTask')
             return element.getText();
             });
          },


            existingTaskSelectDrpdwn: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'existingTaskSelectDrpdwn').click();
            },
            selectAsset: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'selectAsset').click();
            },
            selectAsset1: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'addTaskSelectBtn').click();
            },
             workplanSaveBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'workplanSaveBtn').click();
            },
             addButton: function () {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage,'addButton').click();
            },
            newlyAddedTask: function () {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage,'newlyAddedTask').getText();
            },
            dragAndDropText: function () {
                browser.waitForAngular();
                TestHelperPO.isElementPresent(cem.findElement(currentPage,'field')).then(function () {
                var src = cem.findElement(currentPage,'field');
                var drop = cem.findElement(currentPage,'src');
                return browser.actions().dragAndDrop(src,drop).mouseUp().perform();
                //browser.pause();
                   });
               // })
            },
            taskCompletion: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'titleField').sendKeys('Automation_Testing');
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'descriptionField').sendKeys('Automation Testing');
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'categorySelect').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'turbinesIcon').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'turbines114').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'turbinesSelectionSaveBtn').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'priorityDropdown').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'dueDateCalendar').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'dueDateSelection').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'recurrenceDropdown').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'recurrenceEndAfterBtn').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'recurrenceEndAfterTxt').sendKeys('2');
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'partsNeededTxtField').sendKeys('Automation Testing');
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'techNotesTxtField').sendKeys('Automation Testing');
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'clickAddBtn').click();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'taskSuccessOkBtn').click();
            },
            testPlanedTaskLnk: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'testPlanedTaskLnk').click();
            },
            actualDuration: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'actualDuration').sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'actualDuration').sendKeys(protractor.Key.DELETE);
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'actualDuration').sendKeys('06');
            },
              workplanSideArrow: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage,'workplanSideArrow').click();
            },
            workplanAddTurbineIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'workplanAddTurbineIcon').click();
            },
            addExistingTaskRadioBtn4: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'addExistingTaskRadioBtn4').click();
            },
            addExistingTask3: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'addExistingTaskDropdwn').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'addExistingTaskSelection').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'addExistingTaskAddbtn3').click();
                 },
            editTaskStatus: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'editExecutionTab1').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'editTaskStatusCompletedChkbox1').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'editCompletedDatePic1').click();
                cem.findElement(currentPage,'editCompletedMonthSelect1').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'editCompletedDateSelect1').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'editResolutionField1').clear();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'editResolutionField1').sendKeys('Resolution notes');
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'editSaveBtn1').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'successOkBtn1').click();
                 },
                testPlanNotCompleted: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'testPlanNotCompleted').getCssValue('background-color');
            },
            testPlanCompleted: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage,'testPlanCompleted').getCssValue('background-color');
            },
            testPlanNotCompOperation: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'testPlanNotCompleted').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'actualDurationHour').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'actualDurationMinute').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'resolutionNotes1').clear();
                cem.findElement(currentPage,'resolutionNotes1').sendKeys('Resolution notes');
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'doneBtn1').click();
                 },
                unknownNotCompOperation: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'unknownNotCompleted').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'actualDurationHour2').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'actualDurationMinute2').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'resolutionNotes2').sendKeys('Resolution notes');
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'doneBtn2').click();
                 },
              MultipleCancelImage1: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage,'MultipleCancelImage').getText();
            },
            MultipleCancelImage: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage,'MultipleCancelImage').click();
            },
            MultipleRefreshImage: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'MultipleRefreshImage').click();
            },
            contractorNameClik: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'contractorNameClik').click();
            },
              editTechDetailsLink: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'editTechDetailsLink').click();
              },
               initialsFld: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'initialsFld').clear();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'initialsFld').sendKeys('UAT12');
              },
               editTechSaveBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'editTechSaveBtn').click();
               },
               editTechDetails1: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'initialsFld').clear();
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'initialsFld').sendKeys('UAT12');
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'FirstNameFld').clear();
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'FirstNameFld').sendKeys('Contractor');
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'lastNameFld').clear();
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'lastNameFld').sendKeys('323');
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'editTechSaveBtn').click();
                 },
                enabled: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement((currentPage,'ssoFld'));
               },
            initialVerification: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'contractorNameTooltip').getText();
            },
            toolTipVerification: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'contractorNameVerif').click();
            },
            markAsWorkingAndOnCallStatus: function () {
                cem.findElement(currentPage,'contractorName').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'markAsNotWorking').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'markAsOnCall').click();
                 },
            saveButton: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'saveButton').click();
                 },
            turbineStatusWidget: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'turbineStatusText').getText();
                 },
            faultedDetails: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'faultedName').getText();
                 },
            stoppedDetails: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'stoppedName').getText();
                 },
            impactedDetails: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'impactedName').getText();
                 },
            netcomDetails: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'netcomName').getText();
                 },
            diagnosticsDetails: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'diagnosticsName').getText();
                 },

            faultedTurbines: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'faultedTurbines').getText();
                 },
            stoppedTurbines: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'stoppedTurbines').getText();
                 },
            impactedTurbines: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'impactedTurbines').getText();
                 },
            netcomTurbines: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'netcomTurbines').getText();
                 },
            diagnosticsTurbines: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'diagnosticsTurbines').getText();
                 },
            adminTabInfo: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'adminTabInfo').click();
                 },
            adminAddButton: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'adminAddButton').click();
                 },
            personalInformation: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage,'personalInfoSSOField').sendKeys('502728626');
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'personalInfoRoleDropdown').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'personalInfoFirstField').sendKeys('dPOD');
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'personalInfoLastField').sendKeys('Testing');
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'personalInfoInitialsField').sendKeys('Test');
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'personalInfoEmailField').sendKeys('testing@ge.com');
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'personalInfoCountryCode').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'personalInfoCountryCodeSelection').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'personalInfoPhoneNumber').sendKeys('8885432000');
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'personalInfoNextButton').click();
                 },
            assginSiteCheckbox: function () {
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'assginSiteCheckbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'adminAddButton').click();
                 },
            personalInfoValidation: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'updatedSuccessMsg').getText();
                 },
            personalInfoUpdateBtn: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'updatedSuccessBtn').click();
                 },
            personalInfoSSOValidation: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'updatedSuccessMsg').getText();
                 },
                workPlanDate: function () {
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'workPlanDate').getText();
                 },

                clickWorkPlanDate: function () {
                    browser.driver.sleep(5000);
                    return cem.findElement(currentPage,'workPlanDate').click();
                },

                selectDateFromCalendar: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(6000);
                    return cem.findElement(currentPage,'selectDateFromCalendar').click();
                },

                selectCurrentDateFromCalendar: function () {
                    browser.driver.sleep(5000);
                    return cem.findElement(currentPage,'selectCurrentDateFromCalendar').click();
                },

                fetchWorkPlanCurrentDate: function () {
                    browser.driver.sleep(5000);
                    //return cem.findElement(currentPage,'workPlanDate').getText();
                    return cem.findElement(currentPage,'workPlanDate').getText().then(function (workPlanDate) {
                        console.log("Current Date: "+ workPlanDate);
                        workPlanCurrentDate = workPlanDate;
                    });

                },

                verifyWorkPlanCurrentDate: function () {
                    browser.driver.sleep(8000);
                    //return cem.findElement(currentPage,'workPlanDate').getText();
                    return cem.findElement(currentPage,'workPlanDate').getText().then(function (workPlanDate) {
                        console.log("Current Date: "+ workPlanDate);
                        return assert.equal(workPlanCurrentDate, workPlanDate);
                    });

                },

                pastPlanDateChaneIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'pastPlanDateChaneIcon').click();
                 },
                currentPlanDateIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'currentPlanDateIcon').click();
                 },

              siteTaskSelect: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'siteTaskSelect').click();
                 },
                siteCategoryDropdown: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'siteCategoryDropdown').click();
                 },
                recipientBtn: function () {
                browser.driver.sleep(10000);
                return cem.findElement(currentPage,'recipientBtn').click();
                 },
                recipientMailidTxtFld: function () {
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'recipientMailidTxtFld').sendKeys('dpod2.0devteam@ge.com');
                 },
                 recipientMailidEnter: function () {
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'recipientMailidEnter').click();
                 },
                recipientDeleteBtn: function () {
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'recipientDeleteBtn').click();
                 },
                recipientBackBtn: function () {
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'recipientBackBtn').click();
                 },
                reportNotes: function () {
                browser.driver.sleep(10000);
                return cem.findElement(currentPage,'reportNotes').clear();
                 },
                reportNotes1: function () {
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'reportNotes').sendKeys("Before you can begin to determine what the composition of a particular paragraph will be, you must first decide on an argument and a working thesis statement for your paper. What is the most important idea that you are trying to convey to your reader? The information in each paragraph must be related to that idea. In other words, your paragraphs should remind your reader that there is a recurrent relationship between your thesis and the information in each paragraph. A working thesis functions like a seed from which your paper, and your ideas, will grow. The whole process is an organic one—a natural progression from a seed to a full-blown paper where there are direct, familial relationships between all of the ideas in the paper. The decision about what to put into your paragraphs begins with the germination of a seed of ideas this germination process is better known as brainstorming. There are many techniques for brainstorming; whichever one you choose, this stage of paragraph development cannot be skipped. Building paragraphs can be like building a skyscraper: there must be a well-planned foundation that supports what you are building. Any cracks, inconsistencies, or other corruptions of the foundation can cause your whole paper to crumble.So, let’s suppose that you have done some brainstorming to develop your thesis. What else should you keep in mind as you begin to create paragraphs.There are many different ways to organize a paragraph. The organization you choose will depend on the controlling idea of the paragraph. Below are a few possibilities for organization, with links to brief examples:Narration: Tell a story. Go chronologically,from start to finish. See an example. Description: Provide specific details about what something looks, smells, tastes, sounds, or feels like. Organize spatially, in order of appearance, or by topic. See an example. Narration: Tell a story. Go chronologically,from start to finish. See an example.Before you can begin to determine what the composition of a particular paragraph will be, you must first decide on an argument and a working thesis statement for your paper. What is the most important idea that you are trying to convey to your reader? The information in each paragraph must be related to that idea. In other words, your paragraphs should remind your reader that there is a recurrent relationship between your thesis and the information in each paragraph. A working thesis functions like a seed from which your paper, and your ideas, will grow. The whole process is an organic one—a natural progression from a seed to a full-blown paper where there are direct, familial relationships between all of the ideas in the paper. The decision about what to put into your paragraphs begins with the germination of a seed of ideas; this germination process is better known as brainstorming. There are many techniques for brainstorming; whichever one you choose, this stage of paragraph development cannot be skipped. Building paragraphs can be like building a skyscraper: there must be a well-planned foundation that supports what you are building. Any cracks, inconsistencies, or other corruptions of the foundation can cause your whole paper to crumble.So, let’s suppose that you have done some brainstorming to develop your thesis. What else should you keep in mind as you begin to create paragraphs The decision about what to put into your paragraphs begins with the germination of a seed of ideas this germination process is better known as brainstorming. There are many techniques for brainstorming whichever one you choose, this stage of paragraph development cannot be skipped. Building paragraphs can be like building a skyscraper: there must be a well-planned foundation that supports what you are building. Any cracks, inconsistencies, or other corruptions of the foundation can cause your whole paper to crumble");
                 },
                 reportNotes2: function () {
                browser.driver.sleep(10000);
                return cem.findElement(currentPage,'reportNotes').sendKeys('dpod2_Testing');
                 },
                 reportNotes3: function () {
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'reportNotes').sendKeys('(*');
                 },
                reportNotesMax: function () {
                browser.driver.sleep(10000);
                return cem.findElement(currentPage,'reportNotes').getText();
                 },
                turbineRemoveWorkplan: function () {
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'turbineRemoveWorkplan').click();
                 },
                addNewORexistingTaskBtn1: function () {
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'addNewORexistingTaskBtn1').click();
                 },
                addExistingTaskRadioBtn1: function () {
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'addExistingTaskRadioBtn1').click();
                 },
                existingTaskDropdwn: function () {
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'existingTaskDropdwn').click();
                 },
                taskAddButton: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'existingTurbineSelection').click();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'taskAddButton').click();
                 },
                existingTurbineSelect: function () {
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'existingTurbineSelect').click();
                 },
                PlanWeatherWidget: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'PlanWeatherWidget').getText();
               },
               PlanWeather: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'PlanWeather').getText();
               },
               PlanWeatherTemp: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'PlanWeatherTemp').getText();
               },
               WeatherWidgetWindSpeed: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'WeatherWidgetWindSpeed').getText();
               },
               waitForPerformanceWidgetPOD: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(10000);
				 return TestHelper.isElementPresent(currentPage,'performanceWidgetPOD');
            },
               performanceWidgetPOD: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'performanceWidgetPOD').getText();
               },
               turbineStatusWidgetPOD: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'turbineStatusWidgetPOD').getText();
               },
               siteContactsWidgetPOD: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteContactsWidgetPOD').getText();
               },
               attachmentsWidgetPOD: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'attachmentsWidgetPOD').getText();
               },
               groupDropdwn: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'groupDropdwn').click();
               },
               waitForsiteGroupDropdwn: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(5000);
			 return TestHelper.isElementPresent(currentPage,'siteGroupDropdwn');
            },
               siteGroupSelect: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                cem.findElement(currentPage,'siteGroupDropdwn').click();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'siteGroupSelect').click();
               },

               siteCrewsHeading: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteCrewsHeading').getText();
                 },
                siteCrew1: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteCrew1').getText();
                 },
                siteCrew2: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteCrew2').getText();
                 },
                siteCrewR1: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteCrewR1').getText();
                 },
                siteCrewR2: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteCrewR2').getText();
                 },
                siteCrew3: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteCrew3').getText();
                 },
                siteCrew4: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteCrew4').getText();
                 },
                 siteCrew5: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteCrew5').getText();
                 },
                 siteCrewR3: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteCrewR3').getText();
                 },
                 siteCrew6: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteCrew6').getText();
                 },
                 siteCrew7: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteCrew6').getText();
                 },
                 siteCrew8: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteCrew6').getText();
                 },
                 siteCrew9: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteCrew6').getText();
                 },
                performanceWidget: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'performanceWidget').getText();
                 },
                mTDPWProduction: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'mTDPWProduction').getText();
                 },
                mTDPWProductionValue: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'mTDPWProductionValue').getText();
                 },
                mTDPWAvailability: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'mTDPWAvailability').getText();
                 },
                mTDPWAvailabilityValue: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'mTDPWAvailabilityValue').getText();
                 },
                performanceYTDButton: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'performanceYTDButton').click();
                 },
                taskFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'taskFilter').click();
                 },
                turbineCheckbox: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'siteFilterCheckbox').click();
                 },
                siteCheckbox: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'turbineFilterCheckbox').click();
                 },
                filterApplyBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'filterApplyBtn').click();
                 },
                turbinePendingCheckbox: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'turbinePendingCheckbox').click();
                 },

                turbineFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'turbineFilter').click();
                 },
                turbineOnlineCheckbox: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'turbineOnlineCheckbox').click();
                 },
                turbineOnlineStatus: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'turbineOnlineStatus').getText();
                 },
                turbineStatusTriangular1: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'turbineStatusTriangular').getText();
                 },
                 turbineStatusTriangular3: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'turbineStatusTriangular').click();
                 },
                turbineStatusTriangular2: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return expect(element(by.css('.errorCount.style-scope.plan-turbine-status-widget')).isSelected()).to.eventually.be.false
                 },
                firstPulsePoint: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'firstPulsePoint').click();
                 },
                crewAssignForPulsePoint: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'crewAssignForPulsePoint').click();
                 },
                turbineStatusTriangular: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'turbineStatusTriangular').isPresent();
                 },
                taskTypeAPMFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'taskTypeETCChkbox').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'taskTypeFaultedChkbox').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'taskTypeImpactedChkbox').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'taskTypeMaintenanceChkbox').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'taskTypeMCEChkbox').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'taskTypeNetcomChkbox').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'taskTypePunchlistChkbox').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'taskTypeRetrofitsChkbox').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'taskTypeStoppedChkbox').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'taskTypeTILChkbox').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'taskTypeUMChkbox').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage,'taskTypeWatchlistChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeOthersTurbineChkbox').click();
                 },
                taskTypeETCFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeAPMChkbox').click();
                return cem.findElement(currentPage,'taskTypeETCChkbox').click();
                 },
                taskTypeFaultedFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeETCChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeFaultedChkbox').click();
                 },
                taskTypeImpactedFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeFaultedChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeImpactedChkbox').click();
                 },

                taskTypeMaintenanceFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeImpactedChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeMaintenanceChkbox').click();
                 },

                taskTypeMCEFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeMaintenanceChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeMCEChkbox').click();
                 },
                taskTypeNetcomFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeMCEChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeNetcomChkbox').click();
                 },
                taskTypePunchlistFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeNetcomChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypePunchlistChkbox').click();
                 },
                taskTypeRetrofitsFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypePunchlistChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeRetrofitsChkbox').click();
                 },
                taskTypeStoppedFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeRetrofitsChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeStoppedChkbox').click();
                 },
                taskTypeTILFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeStoppedChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeTILChkbox').click();
                 },
                taskTypeUMFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeTILChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeUMChkbox').click();
                 },
                taskTypeWatchlistFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeUMChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeWatchlistChkbox').click();
                 },
                taskTypeOtherTurbineFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeWatchlistChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeOthersTurbineChkbox').click();
                 },
                taskTypeSiteBOPFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeSiteEHSChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeSiteOthersChkbox').click();
                 },
                turbineTaskTypeFilterHeader: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'turbineTaskTypeFilterHeader').getText();
                 },
                siteTaskTypeFilterHeader: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'siteTaskTypeFilterHeader').getText();
                 },
                taskTypeSiteEHSFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeSiteEHSChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeSiteBOPChkbox').click();
                 },
                taskTypeSiteOthersFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeSiteEHSChkbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage,'taskTypeSiteOthersChkbox').click();
                 },

                taskFilterPlusePoint: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'taskFilterPlusePoint').getText();
                 },
                siteTasktypeFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'siteTasktypeFilter').getText();
                 },
                taskFilterResetBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'taskFilterResetBtn').click();
                 },
                taskTypeFilterUM: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeDiagnosticsChkbox').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'taskTypeUMChkbox').click();
                 },
                taskTypeFilterMaintenance: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskTypeUMChkbox').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'taskTypeMaintenanceChkbox').click();
                 },
                taskCompleteIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'taskCompleteIcon').click();
                },
                completeTaskInWorkPlan: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskActualDuration').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'taskActualDurationNotes').sendKeys('dPOD_Testing');
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'taskActualDurationDoneBtn').click();
               },

              taskActualDuration: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'taskActualDuration').isPresent();
                 },
                workPlanTaskCompleted: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'workPlanTaskCompleted').isPresent();
                 },
               turbineSortLastvisit: function () {
                browser.waitForAngular();
                browser.driver.sleep(15000);
                cem.findElement(currentPage,'turbineSortDisplayIcon').click();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'turbineSortLatVisit').click();
                 },
                 waitForturbineFirstselection: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(6000);
			     return TestHelper.isElementPresent(currentPage,'turbineFirstselection');
                 },
                turbineFirstselection: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'turbineFirstselection').click();
                 },
                turbineUpdatedDate: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'turbineUpdatedDate').getText();
                 },
                turbineLastVisit: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'turbineLastVisit').getText();
                 },
                turbineTaskTitle: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'turbineTaskTitle').getText();
                 },
                turbineResolutionNotes: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'turbineResolutionNotes').getText();
                 },
                turbineTaskCompletionInPlan: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                cem.findElement(currentPage,'turbineFirstselectionInPlan').click();
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'executionTabSelect').click();
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'executionTabSelectCheckBox').click();
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'executionTabSaveBtn').click();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'executionTabSaveConfBtn').click();
                 },
                noDataforCurrentDate: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'noDataforCurrentDate').getText();
                 },
                 EditReportSavePromptYesBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'EditReportSavePromptYesBtn').click();
                 },
                techReportTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return cem.findElement(currentPage,'techReportTab').click();
                 },
                reportsPODTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return cem.findElement(currentPage,'reportsPODTab').click();
                 },
                manageContactBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return cem.findElement(currentPage,'manageContactBtn').click();
                 },
                manageContactPersonNameFld: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'manageContactPersonNameFld').sendKeys('Radha Manchikalapati');
                //cem.findElement(currentPage,'manageContactPersonNameFld').sendKeys('David Miller');
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'manageContactEmailidFld').click();
                 },
                addContactBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'addContactBtn').click();
                 },
                siteContactNameText: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'siteContactNameText').getText();
                 },
                siteContactDeleteIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'siteContactDeleteIcon').click();
                 },
                siteContactRole: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'siteContactRole').getText();
                 },
                siteContactEmailText: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'siteContactEmailText').getText();
                 },
                siteContactDisableIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'siteContactDisableIcon').click();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'siteContactDisableIcon').click();
                 },
                 siteContactBackBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'siteContactBackBtn').click();
                 },
                siteContactWidgetNameTxt: function () {
                browser.waitForAngular();
                browser.driver.sleep(15000);
                return cem.findElement(currentPage,'siteContactWidgetNameTxt').getText();
                 },
                createNewContractor: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'createNewContractor').click();
                 },
                newContractor: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'newContractor').click();
                 },
                editTechDetails: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'editTechDetails').click();
                 },
                editFirstName: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'editFirstName').getText();
                 },
                editLastName: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'editLastName').getText();
                 },
                deleteTech: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'deleteTech').click();
                 },
                // editTechSaveBtn: function () {
                // browser.waitForAngular();
                // browser.driver.sleep(5000);
                // return cem.findElement(currentPage,'editTechSaveBtn').click();
                //  },
                contractorOnTurbinepage: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'contractorOnTurbinepage').getText();
                 },
                 contractorOnTurbinepage1: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'contractorOnTurbinepage1').getText();
                 },
                crewNameInCrewsection: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'crewNameInCrewsection').getText();
                 },
                crewNameInWPsection: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'crewNameInWPsection').getText();
                 },
                 crewNameInCrewsection1: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'crewNameInCrewsection1').getText();
                 },
                crewNameInWPsection1: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'crewNameInWPsection1').getText();
                 },
                crewNameTooltipInWP: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'crewNameTooltipInWP').getAttribute('tooltip');
                 },
                crewNameTooltipInWP1: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'crewNameTooltipInWP1').getAttribute('tooltip');
                 },
                 crewNameTooltipInCrew: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'crewNameTooltipInCrew').getAttribute('tooltip-message');
                 },

                editCrewNameTooltip: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(5000);
                    return cem.findElement(currentPage,'editCrewNameTooltip').getAttribute('title');
                 },


                 crewNameTooltipInCrew1: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'crewNameTooltipInCrew').getAttribute('tooltip-message');
                 },
                siteLevelTaskInTech: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'siteLevelTaskInTech').getText();
                 },
                siteLevelTaskVerifyInTech: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'siteLevelTaskVerifyInTech').getText();
                 },
                searchExistingTask: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'searchExistingTask').sendKeys('SITE');
                 },
                 openFileSelector:function(){
                 //browser.waitForAngular();
                 //browser.driver.sleep(4000);
				 var fileToUpload = '../TestData/Task-Template.xlsm',
			     absolutePath = path.resolve(__dirname, fileToUpload);
				 element(by.css('input[type="file"]')).sendKeys(absolutePath);
				 browser.sleep(3000);
                 return cem.findElement(currentPage,'uploadExcelBtn').click();
			    },
                actionsBtnTaskpage: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'actionsBtnTaskpage').click();
                 },
                importBtnTaskpage: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'importBtnTaskpage').click();
                 },
                activeSearchBtn2: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'activeSearchBtn').sendKeys('CSV_ProUITask');
                },
                csvTaskTitle: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'csvTaskTitle').getText();
               },
               completedChkBoxTaskFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'pendingChkBoxTaskFilter').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'plannedChkBoxTaskFilter').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'completedChkBoxTaskFilter').click();
                 },
                 openFileSelector1:function(){
                 //browser.driver.sleep(3000);
				 var fileToUpload = '../TestData/Sample-Template.xlsx',
			     absolutePath = path.resolve(__dirname, fileToUpload);
				 browser.sleep(3000);
                 return cem.findElement(currentPage,'fileUploadBtn').sendKeys(absolutePath);
			     },
                 waitForAttachmentDownloadOptn: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(6000);
				 return TestHelper.isElementPresent(currentPage,'attachmentDownloadOptn');
                 },
                attachmentDownloadOptn: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'attachmentDownloadOptn').click();
                 },
                fileDeleteBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'fileDeleteBtn').click();
                 },
                 fileDownloadArchive: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'fileDownloadArchive').click();
                 },
                rptArchiveBack: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'rptArchiveBack').click();
                 },
                 siteNameInWWReports: function() {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'siteNameInWWReports').getText();
                },
                selectOptionInTaskpage: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'selectOptionInTaskpage').click();
                 },
                selectCancelInTaskpage: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'selectCancelInTaskpage').click();
                 },
                selectFirstTurbineTaskpage: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'selectFirstTurbineTaskpage').click();
                 },
                selectSecondTurbineTaskpage: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'selectSecondTurbineTaskpage').click();
                 },
                exportAllBtnTaskpage: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'exportAllBtnTaskpage').click();
                 },
                exportBtnTaskpage: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'exportBtnTaskpage').click();
                 },
                podShowHideOption1: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'podShowHideOption1').click();
                 },
                ispodTaskTitleVisibile: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
			    return TestHelper.isElementPresent(currentPage,'podTaskTitle');
                },
                podTaskTitle: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'podTaskTitle').click();
                 },
                podTaskTitle1: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return expect(element(by.css('#list > li:nth-child(2) > input')).isSelected()).to.eventually.be.false
                 },
                assetNotificationCount: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'assetNotificationCount').click();
                 },
                triangularTask: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'triangularTask').getText();
                 },
                triangularTaskPlusIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'triangularTaskPlusIcon').isPresent();
                },
                triangularTaskCancelIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'triangularTaskCancelIcon').click();
                },
                triangularselectCrewSection: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'triangularselectCrewSection').click();
                },
		plnPageConfMsgYesBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'plnPageConfMsgYesBtn').click();
            },
            
		turbineTaskCompletionInPlan1: function() {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                cem.findElement(currentPage, 'turbineFirstselectionInPlan1').click();
                browser.driver.sleep(5000);
                cem.findElement(currentPage, 'executionTabSelect').click();
                browser.driver.sleep(5000);
                cem.findElement(currentPage, 'executionTabSelectCheckBox').click();
                browser.driver.sleep(5000);
                cem.findElement(currentPage, 'executionTabSaveBtn').click();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'executionTabSaveConfBtn').click();
            },
               taskCompleteIcon1: function() {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'taskCompleteIcon1').click();
            },
            verifyRecurrenceOrder: function() {
	         browser.driver.sleep(6000);
	         var allOptions = cem.findElement(currentPage, 'recurrenceDropDown').$$('option').map(function(option) {
		     return option.getText();
	          });
	         return allOptions;
            },
           turbineSearchCases: function() {
	browser.waitForAngular();
	browser.driver.sleep(6000);
	return cem.findElement(currentPage, 'turbineSearchCases').getText();
        },
        turbineSearchAllCaps: function() {
	browser.driver.sleep(4000);
	cem.findElement(currentPage, 'turbinePageSearchField').sendKeys('SOUTH HURLBURT');
	browser.driver.sleep(4000);
	return cem.findElement(currentPage, 'turbineNameInSearch').getText();
        },
       turbineSearchAllSmall: function() {
       browser.driver.sleep(3000);
       cem.findElement(currentPage, 'turbinePageSearchField').clear()
       browser.driver.sleep(3000);
       cem.findElement(currentPage, 'turbinePageSearchField').sendKeys('south hurlburt');
       browser.driver.sleep(3000);
       return cem.findElement(currentPage, 'turbineSearchCases').getText();
       },
        turbineSearchCamelCase: function() {
	browser.driver.sleep(4000);
        cem.findElement(currentPage, 'turbinePageSearchField').clear()
        browser.driver.sleep(3000);
	cem.findElement(currentPage, 'turbinePageSearchField').sendKeys('South Hurlburt');
        browser.driver.sleep(3000);
        return cem.findElement(currentPage, 'turbineSearchCases').getText();
        },
        turbineSearchMixedCase: function() {
	browser.driver.sleep(4000);
        cem.findElement(currentPage, 'turbinePageSearchField').clear()
        browser.driver.sleep(3000);
	cem.findElement(currentPage, 'turbinePageSearchField').sendKeys('sOuth hURlbUrt');
        browser.driver.sleep(3000);
        return cem.findElement(currentPage, 'turbineSearchCases').getText();
    },

            reportNotes5: function() {
                browser.driver.sleep(6000);
                return cem.findElement(currentPage, 'reportNotes').sendKeys('Testing open parenthesis... ( *');
            },
            reportNotes6: function() {
                browser.driver.sleep(6000);
                return cem.findElement(currentPage, 'reportNotes').sendKeys('Testing closing parenthesis... ) *');
            },
            reportNotes4: function() {
                browser.driver.sleep(6000);
                return cem.findElement(currentPage, 'reportNotes').sendKeys('Testing all special characters... ( @ # $ % ^ & * ( ) ! ~ > < ? / } { ] [ - = + *');
            },
            reportWeatherDetailsSiteName: function() {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'reportWeatherDetails').getText();
            },
            reportNotesText: function() {
            browser.driver.sleep(7000);
            return cem.findElement(currentPage, 'reportNotes').getText()
             },
        waitForReportNotes: function() {
		browser.waitForAngular();
        browser.driver.sleep(10000);
		return TestHelper.isElementPresent(currentPage,'reportNotes');
        },

//DE81332
     printPreviewBtn: function() {
     browser.waitForAngular();
     browser.driver.sleep(15000);
     return cem.findElement(currentPage, 'printPreviewBtn').click();
    },
    printEmailBtn: function() {
     browser.waitForAngular();
     browser.driver.sleep(15000);
     return cem.findElement(currentPage, 'printEmailBtn').click();
    },
    archiveReportBackBtn: function() {
     browser.waitForAngular();
     browser.driver.sleep(5000);
     return cem.findElement(currentPage, 'archiveReportBackBtn').click();
    },
    personnelMangTab: function () {
    browser.waitForAngular();
    browser.driver.sleep(12000);
    return cem.findElement(currentPage,'personnelMangTab').click();
    },
    assetsMangTab: function () {
    browser.waitForAngular();
    browser.driver.sleep(12000);
    return cem.findElement(currentPage,'assetsMangTab').click();
    },
    waitForPODMangTab: function () {
    browser.waitForAngular();
    browser.driver.sleep(12000);
    return TestHelper.isElementPresent(currentPage,'planofthedayMangTab');
    },
    planofthedayMangTab: function () {
    browser.waitForAngular();
    browser.driver.sleep(12000);
    return cem.findElement(currentPage,'planofthedayMangTab').click();
   },
    inCompletetask: function () {
    browser.waitForAngular();
    browser.driver.sleep(4000);
    cem.findElement(currentPage,'taskCompleteIcon').click();
    browser.driver.sleep(4000);
    cem.findElement(currentPage,'taskActualDuration').click();
    browser.driver.sleep(4000);
    return cem.findElement(currentPage,'taskActualDurationNotes').sendKeys('dPOD_Testing');
    },
    taskPageUnsavedNoBtn: function () {
    browser.waitForAngular();
    browser.driver.sleep(6000);
    return cem.findElement(currentPage,'taskPageUnsavedNoBtn').click();
   },
   taskPageUnsavedYesBtn: function () {
    browser.waitForAngular();
    browser.driver.sleep(6000);
    return cem.findElement(currentPage,'taskPageUnsavedYesBtn').click();
   },
   turbineStatusWidgetInReports: function () {
   browser.driver.sleep(6000);
   return cem.findElement(currentPage,'turbineStatusWidgetInReports').click();
   },
    otherTurbineCategory: function () {
   browser.waitForAngular();
   browser.driver.sleep(6000);
   return cem.findElement(currentPage,'otherTurbineCategory').click();
  },
  othersSiteCategoryType: function () {
   browser.waitForAngular();
   browser.driver.sleep(6000);
   return cem.findElement(currentPage,'othersSiteCategoryType').click();
   },
    othersTaskTypeSearch: function () {
    browser.waitForAngular();
    browser.driver.sleep(12000);
    return cem.findElement(currentPage,'activeSearchBtn').sendKeys('Others');
   },
    taskTypeInLeftNavigation: function() {
    browser.waitForAngular();
    browser.driver.sleep(6000);
    return cem.findElement(currentPage, 'taskTypeInLeftNavigation').getText();
   },

 validateAPMCases:function (callback) {
                var noRecord = "No result found";
                var task = "APM Case(s)";
                browser.sleep(5000);
              cem.findElement(currentPage,'taskFilterPlusePoint').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'taskFilterPlusePoint').getText().then(function (textValue) {
                            assert.equal(task, textValue);
                            console.log("APM case(s) is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },

    validateETCTaskFilter:function (callback) {
                var noRecord = "No result found";
                var task = "ETC";
                browser.sleep(5000);
              cem.findElement(currentPage,'taskFilterPlusePoint').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'taskFilterPlusePoint').getText().then(function (textValue) {
                            console.log(textValue);
                            assert.equal(task, textValue);
                            console.log("ETC is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateFaultedTaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "Faulted";
                browser.sleep(5000);
              cem.findElement(currentPage,'taskFilterPlusePoint').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'taskFilterPlusePoint').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("Faulted is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateImpactedTaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "Impacted";
                browser.sleep(5000);
              cem.findElement(currentPage,'taskFilterPlusePoint').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'taskFilterPlusePoint').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("Impacted is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateMaintenanceTaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "Maintenance";
                browser.sleep(5000);
              cem.findElement(currentPage,'taskFilterPlusePoint').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'taskFilterPlusePoint').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("Maintenance is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateMCETaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "MCE";
                browser.sleep(5000);
              cem.findElement(currentPage,'taskFilterPlusePoint').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'taskFilterPlusePoint').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("MCE is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateNetcomTaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "Netcom";
                browser.sleep(5000);
              cem.findElement(currentPage,'taskFilterPlusePoint').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'taskFilterPlusePoint').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("Netcom is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validatePunchlistTaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "Punch List";
                browser.sleep(5000);
              cem.findElement(currentPage,'taskFilterPlusePoint').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'taskFilterPlusePoint').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("Punch List is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateRetrofitsTaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "Retrofits";
                browser.sleep(5000);
              cem.findElement(currentPage,'taskFilterPlusePoint').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'taskFilterPlusePoint').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("Retrofits is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateStoppedTaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "Stopped";
                browser.sleep(5000);
              cem.findElement(currentPage,'taskFilterPlusePoint').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'taskFilterPlusePoint').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("Stopped is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateTILTaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "TIL";
                browser.sleep(5000);
              cem.findElement(currentPage,'taskFilterPlusePoint').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'taskFilterPlusePoint').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("TIL is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateUMTaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "Unplanned Maintenance";
                browser.sleep(5000);
              cem.findElement(currentPage,'taskFilterPlusePoint').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'taskFilterPlusePoint').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("Unplanned Maintenance is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateWatchlistTaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "Watchlist";
                browser.sleep(5000);
              cem.findElement(currentPage,'taskFilterPlusePoint').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'taskFilterPlusePoint').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("Watchlist is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateOtherTurbineTaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "Other";
                browser.sleep(5000);
              cem.findElement(currentPage,'taskFilterPlusePoint').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'taskFilterPlusePoint').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("Other (Turbine) is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateSiteBOPTaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "BOP";
                browser.sleep(9000);
              cem.findElement(currentPage,'siteTasktypeFilter').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'siteTasktypeFilter').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("BOP is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateSiteEHSTaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "EHS";
                browser.sleep(5000);
              cem.findElement(currentPage,'siteTasktypeFilter').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'siteTasktypeFilter').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("EHS is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateSiteOthersTaskFilter:function (callback) {
                var noRecord = "No result found";
                var Task = "Others";
                browser.sleep(5000);
              cem.findElement(currentPage,'siteTasktypeFilter').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'siteTasktypeFilter').getText().then(function (textValue) {
                            assert.equal(Task, textValue);
                            console.log("Others (Site) is present ");
                            callback();
                        });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            validateAPMCaseURL:function (callback) {
                var noRecord = "No result found";
                var Task = "APM Case(s)";
                var ApmCaseUrl = "https://apmpreprod.apm.aws-usw02-pr.predix.io/ren-wind-dev/cases/"
                //browser.sleep(10000);
                browser.driver.sleep(10000);
              cem.findElement(currentPage,'siteTasktypeFilter').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'siteTasktypeFilter').getText().then(function (textValue) {
                            //assert.equal(Task, textValue);
                            //console.log("APM Case(s) is present ");
                    cem.findElement(currentPage, 'aPMCaseLabel').isPresent().then(function () {                           
                    cem.findElement(currentPage,'aPMCaseLabel').click();
                    browser.driver.sleep(5000);
                    browser.getAllWindowHandles().then(function (handles) {
                    browser.driver.switchTo().window(handles[1]).then(function () {
                        browser.sleep(3000);
                 //browser.getCurrentUrl(); 
                 browser.getCurrentUrl().then(function (webPageUrl) {
              console.log(webPageUrl); 
                   //console.log(apmurl);
                browser.wait(apmurl.Contains(ApmCaseUrl), 5000); 
                 browser.getAllWindowHandles().then(function (handles) {
                    browser.driver.switchTo().window(handles[0]).then(function () {    
                    });
                }); 
            });                                 
                          //callback();
                        });
                     });
                });
            callback();
        });  
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            aPMCaseLabel: function () {
            browser.waitForAngular();
            browser.driver.sleep(8000);
            return cem.findElement(currentPage,'aPMCaseLabel').click();
        },
        validateEditAPMCaseURL:function (callback) {
                var noRecord = "No result found";
                var Task = "APM Case(s)";
                var ApmCaseUrl = "https://apmpreprod.apm.aws-usw02-pr.predix.io/ren-wind-dev/cases/"
                //browser.sleep(10000);
                browser.driver.sleep(10000);
              cem.findElement(currentPage,'siteTasktypeFilter').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'siteTasktypeFilter').getText().then(function (textValue) {
                            //assert.equal(Task, textValue);
                            //console.log("APM Case(s) is present ");
                    cem.findElement(currentPage, 'editTaskBtn').isPresent();
                    browser.driver.sleep(5000);        
                    cem.findElement(currentPage,'editTaskBtn').click();
                    browser.driver.sleep(5000);
                    cem.findElement(currentPage, 'editAPMCaseBtn').isPresent().then(function () { 
                    cem.findElement(currentPage,'editAPMCaseBtn').click();
                    browser.getAllWindowHandles().then(function (handles) {
                    browser.driver.switchTo().window(handles[1]).then(function () {
                        browser.sleep(3000);
                   var apmurl = browser.getCurrentUrl(); 
                browser.wait(apmurl.urlContains(ApmCaseUrl), 5000);     
                    });
                });                                  
                          callback();
                        });
                     });
                    }else{
                        cem.findElement(currentPage, 'noResultsFoundInTaskpage').isPresent();
                        cem.findElement(currentPage,'noResultsFoundInTaskpage').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            
            reportsPMTaskdragDrop:function (callback) {
                var noRecord = "No Records";
                browser.sleep(5000);
              element(by.xpath("//*[@ng-if='plannedtitle'][contains(@class,'ng-binding ng-scope')]")).isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                var ele = element.all(by.xpath("//*[@ng-if='plannedtitle'][contains(@class,'ng-binding ng-scope')]")).first();
                var target = element.all(by.xpath("//*[@ng-if='title'][contains(@class,'ng-binding ng-scope')]")).last();
                browser.sleep(3000);
                return browser.actions().dragAndDrop(ele, target).mouseUp().perform().then(function(){
                            callback();
                        });
                    }else{
                        element(by.xpath("//*[@colspan='6'][contains(@class,'ng-binding')]")).isPresent();
                        element(by.xpath("//*[@colspan='6'][contains(@class,'ng-binding')]")).getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            reportsPMTurbinedragDrop:function (callback) {
                var noRecord = "No Records";
                browser.sleep(5000);
              element(by.xpath("//*[@colspan='5'][contains(@class,'aHand')]")).isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                var ele = element.all(by.xpath("//*[@colspan='5'][contains(@class,'aHand')]")).last();
                var target = element.all(by.xpath("//*[@colspan='5'][contains(@class,'aHand')]")).first();
                browser.sleep(3000);
                return browser.actions().dragAndDrop(ele, target).mouseUp().perform().then(function(){
                            callback();
                        });
                    }else{
                        element(by.xpath("//*[@colspan='6'][contains(@class,'ng-binding')]")).isPresent();
                        element(by.xpath("//*[@colspan='6'][contains(@class,'ng-binding')]")).getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            reportsTaskdragDrop:function (callback) {
                var noRecord = "No Records";
                browser.sleep(5000);
              element(by.xpath("//*[@ng-if='title'][contains(@class,'ng-binding ng-scope')]")).isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                var ele = element.all(by.xpath("//*[@ng-if='title'][contains(@class,'ng-binding ng-scope')]")).last();
                var target = element.all(by.xpath("//*[@ng-if='plannedtitle'][contains(@class,'ng-binding ng-scope')]")).first();
                browser.sleep(3000);
                return browser.actions().dragAndDrop(ele, target).mouseUp().perform().then(function () {
                            callback();
                        });
                    }else{
                        element(by.xpath("//*[@colspan='4'][contains(@class,'ng-binding')]")).isPresent();
                        element(by.xpath("//*[@colspan='4'][contains(@class,'ng-binding')]")).getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            reportsTurbinedragDrop:function (callback) {
                var noRecord = "No Records";
                browser.sleep(5000);
              element(by.xpath("//*[@colspan='5'][contains(@class,'aHand')]")).isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                var ele = element.all(by.xpath("//*[@colspan='5'][contains(@class,'aHand')]")).first();
                var target = element.all(by.xpath("//*[@colspan='5'][contains(@class,'aHand')]")).last();
                browser.sleep(3000);
                return browser.actions().dragAndDrop(ele, target).mouseUp().perform().then(function () {
                            callback();
                        });
                    }else{
                        element(by.xpath("//*[@colspan='4'][contains(@class,'ng-binding')]")).isPresent();
                        element(by.xpath("//*[@colspan='4'][contains(@class,'ng-binding')]")).getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },
            clickOnTaskComplete: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return element.all(by.xpath("//a[contains(@title,'Mark as complete')]")).first().click();
              },

              CheckMendatoryFiledMark: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return element(by.xpath("//*[@class='u-1/1 float--left u-mb-']/span/i")).isPresent();;
              },

              CheckDoneButtonDisabled: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return element(by.xpath("//*[@class='float--right u-mt- ng-scope']/button[2]")).getAttribute('disabled');
              },

              changeActualDuration: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                element.all(by.xpath("(//*[@class='u-1/1 float--left u-mb-']//select)[1]")).click();
                browser.driver.sleep(4000);
                return element.all(by.xpath("(//*[@class='u-1/1 float--left u-mb-']//select/option[2])[1]")).click();
              },

              
              CheckDoneButtonEnabled: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return element(by.xpath("//*[@class='float--right u-mt- ng-scope']/button[2]")).isEnabled();
              },

              
              changeActualDurationHr: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                element.all(by.xpath("(//*[@class='u-1/1 float--left u-mb-']//select)[1]")).click();
                browser.driver.sleep(4000);
                element.all(by.xpath("(//*[@class='u-1/1 float--left u-mb-']//select/option[1])[1]")).click();

                browser.driver.sleep(4000);
                element.all(by.xpath("(//*[@class='u-1/1 float--left u-mb-']//select)[2]")).click();
                browser.driver.sleep(4000);
                return element.all(by.xpath("(//*[@class='u-1/1 float--left u-mb-']//select/option[2])[2]")).click();
              },
	      taskCompleteChkbox: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                element(by.xpath("(//*[@id='basic-form-checkbox'])[3]")).click();
                browser.driver.sleep(2000);
                element(by.xpath("(//*[@id='basic-form-checkbox'])[4]")).click();
                browser.driver.sleep(2000);
                return element(by.xpath("(//*[@id='basic-form-checkbox'])[5]")).click();
              },
              
	      completedTaskValidation: function () {
                browser.driver.sleep(8000);
                cem.findElement(currentPage, 'pendingTaskTitle').isPresent();
                return cem.findElement(currentPage, 'pendingTaskTitle').getText().then(function (pending) {              
                cem.findElement(currentPage, 'editTaskBtn').click();
                browser.driver.sleep(6000);
                cem.findElement(currentPage, 'editExecutionTab').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage, 'editTaskStatusCompletedChkbox').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'actualDuration').sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'actualDuration').sendKeys(protractor.Key.DELETE);
                browser.driver.sleep(6000);
                cem.findElement(currentPage,'actualDuration').sendKeys(protractor.Key.ARROW_UP);
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'CompleteTaskResolutionNotes').sendKeys('Complete Task');
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'editSaveBtn').click();
                browser.driver.sleep(6000);
                cem.findElement(currentPage,'successOkBtn').click();
                browser.driver.sleep(10000);
                cem.findElement(currentPage,'taskFilter').click();
                browser.driver.sleep(4000);
                element(by.xpath("(//*[@id='basic-form-checkbox'])[3]")).click();
                browser.driver.sleep(2000);
                element(by.xpath("(//*[@id='basic-form-checkbox'])[4]")).click();
                browser.driver.sleep(2000);
                element(by.xpath("(//*[@id='basic-form-checkbox'])[5]")).click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage,'filterApplyBtn').click();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage, 'pendingTaskTitle').getText().then(function (completed) {
                    console.log("Pending Task Title is : " + pending);
                    console.log("Completed Task is : " + completed);
                   assert.equal(pending,completed);                  
                });
             });
            },

            completedTaskValidationWith1000Char: function () {
                browser.driver.sleep(8000);
                cem.findElement(currentPage, 'pendingTaskTitle').isPresent();
                return cem.findElement(currentPage, 'pendingTaskTitle').getText().then(function (pending) {
                    cem.findElement(currentPage, 'editTaskBtn').click();
                    browser.driver.sleep(6000);
                    cem.findElement(currentPage, 'editExecutionTab').click();
                    browser.driver.sleep(4000);
                    cem.findElement(currentPage, 'editTaskStatusCompletedChkbox').click();
                    browser.driver.sleep(4000);
                    cem.findElement(currentPage,'actualDuration').sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                    browser.driver.sleep(4000);
                    cem.findElement(currentPage,'actualDuration').sendKeys(protractor.Key.DELETE);
                    browser.driver.sleep(6000);
                    cem.findElement(currentPage,'actualDuration').sendKeys(protractor.Key.ARROW_UP);
                    browser.driver.sleep(4000);
                    cem.findElement(currentPage,'CompleteTaskResolutionNotes').sendKeys('Before you can begin to determine what the composition of a particular paragraph will be, you must first decide on an argument and a working thesis statement for your paper. What is the most important idea that you are trying to convey to your reader? The information in each paragraph must be related to that idea. In other words, your paragraphs should remind your reader that there is a recurrent relationship between your thesis and the information in each paragraph. A working thesis functions like a seed from which your paper, and your ideas, will grow. The whole process is an organic one—a natural progression from a seed to a full-blown paper where there are direct, familial relationships between all of the ideas in the paper. The decision about what to put into your paragraphs begins with the germination of a seed of ideas this germination process is better known as brainstorming. There are many techniques for brainstorming; whichever one you choose, this stage of paragraph development cannot be skipped. Building paragraphs can be like building a skyscraper: there must be a well-planned foundation that supports what you are building. Any cracks, inconsistencies, or other corruptions of the foundation can cause your whole paper to crumble.So, let’s suppose that you have done some brainstorming to develop your thesis. What else should you keep in mind as you begin to create paragraphs.There are many different ways to organize a paragraph. The organization you choose will depend on the controlling idea of the paragraph. Below are a few possibilities for organization, with links to brief examples:Narration: Tell a story. Go chronologically,from start to finish. See an example. Description: Provide specific details about what something looks, smells, tastes, sounds, or feels like. Organize spatially, in order of appearance, or by topic. See an example. Narration: Tell a story. Go chronologically,from start to finish. See an example.Before you can begin to determine what the composition of a particular paragraph will be, you must first decide on an argument and a working thesis statement for your paper. What is the most important idea that you are trying to convey to your reader? The information in each paragraph must be related to that idea. In other words, your paragraphs should remind your reader that there is a recurrent relationship between your thesis and the information in each paragraph. A working thesis functions like a seed from which your paper, and your ideas, will grow. The whole process is an organic one—a natural progression from a seed to a full-blown paper where there are direct, familial relationships between all of the ideas in the paper. The decision about what to put into your paragraphs begins with the germination of a seed of ideas; this germination process is better known as brainstorming. There are many techniques for brainstorming; whichever one you choose, this stage of paragraph development cannot be skipped. Building paragraphs can be like building a skyscraper: there must be a well-planned foundation that supports what you are building. Any cracks, inconsistencies, or other corruptions of the foundation can cause your whole paper to crumble.So, let’s suppose that you have done some brainstorming to develop your thesis. What else should you keep in mind as you begin to create paragraphs The decision about what to put into your paragraphs begins with the germination of a seed of ideas this germination process is better known as brainstorming. There are many techniques for brainstorming whichever one you choose, this stage of paragraph development cannot be skipped. Building paragraphs can be like building a skyscraper: there must be a well-planned foundation that supports what you are building. Any cracks, inconsistencies, or other corruptions of the foundation can cause your whole paper to crumble');
                    browser.driver.sleep(4000);
                    cem.findElement(currentPage,'editSaveBtn').click();
                    browser.driver.sleep(6000);
                    cem.findElement(currentPage,'successOkBtn').click();
                    browser.driver.sleep(10000);
                    cem.findElement(currentPage,'taskFilter').click();
                    browser.driver.sleep(4000);
                    element(by.xpath("(//*[@id='basic-form-checkbox'])[3]")).click();
                    browser.driver.sleep(2000);
                    element(by.xpath("(//*[@id='basic-form-checkbox'])[4]")).click();
                    browser.driver.sleep(2000);
                    element(by.xpath("(//*[@id='basic-form-checkbox'])[5]")).click();
                    browser.driver.sleep(2000);
                    cem.findElement(currentPage,'filterApplyBtn').click();
                    browser.driver.sleep(10000);
                    return cem.findElement(currentPage, 'pendingTaskTitle').getText().then(function (completed) {
                        console.log("Pending Task Title is : " + pending);
                        console.log("Completed Task is : " + completed);
                        assert.equal(pending,completed);
                    });
                });
            },

            completedTaskSelect: function () {
                browser.driver.sleep(8000);
                cem.findElement(currentPage, 'taskFilter').isPresent();
                return cem.findElement(currentPage, 'taskFilter').click().then(function () {                    
                    cem.findElement(currentPage,'taskFilter').click();
                    browser.driver.sleep(4000);
                    element(by.xpath("(//*[@id='basic-form-checkbox'])[3]")).click();
                    browser.driver.sleep(2000);
                    element(by.xpath("(//*[@id='basic-form-checkbox'])[4]")).click();
                    browser.driver.sleep(2000);
                    element(by.xpath("(//*[@id='basic-form-checkbox'])[5]")).click();
                    browser.driver.sleep(2000);
                    cem.findElement(currentPage,'filterApplyBtn').click();
                    browser.driver.sleep(10000);                    
                });
            },

            completedToPendingTask: function () {
                browser.driver.sleep(6000);
                cem.findElement(currentPage, 'editTaskBtn').isPresent();
                return cem.findElement(currentPage, 'editTaskBtn').click().then(function () { 
                    browser.driver.sleep(4000);                   
                    cem.findElement(currentPage,'editExecutionTab').click();
                    browser.driver.sleep(4000); 
                    cem.findElement(currentPage,'editTaskStatusCompletedChkbox').click();
                    browser.driver.sleep(4000);
                    cem.findElement(currentPage,'editSaveBtn').click();
                    browser.driver.sleep(6000);
                    cem.findElement(currentPage,'successOkBtn').click();
                    browser.driver.sleep(6000);
                });
            },

            techReportShowhideTooltip:function() {
             var tooltip = 'Show/ Hide Column'   
            browser.waitForAngular();
            browser.driver.sleep(5000);
            browser.actions().mouseMove(element(by.xpath("(//*[@id='textWrap'])[3]"))).perform();
            browser.driver.sleep(3000);
            return element(by.xpath("(//*[@id='tooltip'])[61]")).getText().then(function (completed) {
                  console.log("Tooltip is : " + completed);
                   //assert.equal(tooltip,completed);                  
                });            
            },

            addTaskSearchBox: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'addTaskSearchBox').sendKeys('51');
                 },

            selectAssetOne:function (callback) {
                browser.sleep(5000);
              element(by.xpath("//*[@id='addTaskDialog_0']/div/div[1]/div[1]/div/span/div/div[2]/div[1]")).isPresent().then(function(value){
                    console.log(value);
                    if(value === true){
               element(by.xpath("//*[@id='addTaskDialog_0']/div/div[1]/div[1]/div/span/div/div[2]/div[1]")).click().then(function(){
                browser.sleep(3000);
                element(by.xpath("//*[@id='addTaskDialog_0']/div/div[2]/button[2]")).click().then(function(){
                browser.sleep(9000);
                element(by.xpath("//*[@id='animated-demo']/div[3]/div/section/div/div[3]/button[1]")).click();
                browser.sleep(3000);
                callback();
                });
            });
                    }else{
                        browser.sleep(2000);
                        element(by.xpath("//*[@id='addTaskDialog_0']/div/div[1]/div[1]/div/span/div/div[2]")).isPresent();
                        element(by.xpath("(//*[@class='u-1/1 u-mb- float--left epsilon ng-binding'][contains(text(),'Add Task')])[1]")).click().then(function () {
                            console.log("Turbine is already part of the plan");
                            callback();
                        });   
                    }
                });
            },

            planPageConfMsgCancelBtn: function() {
	browser.waitForAngular();
	browser.driver.sleep(8000);
	return cem.findElement(currentPage, 'planPageConfMsgCancelBtn').click();
},
planPageConfMsgNoBtn: function() {
	browser.waitForAngular();
	browser.driver.sleep(8000);
	return cem.findElement(currentPage, 'planPageConfMsgNoBtn').click();
},
reportPageConfMsgCancelBtn: function() {
	browser.waitForAngular();
	browser.driver.sleep(8000);
	return cem.findElement(currentPage, 'reportPageConfMsgCancelBtn').click();
},
reportPageConfMsgNoBtn: function() {
	browser.waitForAngular();
	browser.driver.sleep(8000);
	return cem.findElement(currentPage, 'reportPageConfMsgNoBtn').click();
},
reportPageConfMsgYesBtn: function() {
	browser.waitForAngular();
	browser.driver.sleep(8000);
	return cem.findElement(currentPage, 'reportPageConfMsgYesBtn').click();
},
taskPageUnsavedCancelBtn: function() {
	browser.waitForAngular();
	browser.driver.sleep(8000);
	return cem.findElement(currentPage, 'taskPageUnsavedCancelBtn').click();
},
siteGroupOtherSelect: function() {
	browser.waitForAngular();
	browser.driver.sleep(9000);
	cem.findElement(currentPage, 'siteGroupDropdwn').click();
	browser.driver.sleep(5000);
	return cem.findElement(currentPage, 'siteGroupSelectDifferent').click();
},

/** APM case detail */
            
            getAPMCaseDetail: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return element.all(by.xpath("//*[@id='top']/div[2]/table/tbody/tr/td[1]/div/div[2]/div[1]")).click();
            },
            APMCaseBtnOnPlan: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return element(by.xpath("//*[@class='section_title ng-binding ng-scope']//button")).isPresent();
            },
            ClickOnAPMCaseBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return element(by.xpath("//*[@class='section_title ng-binding ng-scope']//button")).isEnabled();
            },
            ClickOnExeTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return element.all(by.xpath("//*[@class='tab']//px-tab[2]/div")).click();
            },
            APMCaseBtnOnExe: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return element(by.xpath("//*[@class='section_title ng-binding ng-scope']//button")).isPresent();
            },
            ClickOnEditTaskIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return element(by.xpath("//*[@class='section_title ng-binding ng-scope']/i")).click();
            },
            APMCaseBtnOnEditExe: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return element(by.xpath("//*[@class='plan_exec']//button[contains(text(),'APM Case(s)')]")).isPresent();
            },
            ClickOnPlanTabInEdit: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return element.all(by.xpath("//*[@class='col-md-12 add-task-breadcrumb']//span[1]")).click();
            },
            APMCaseBtnOnEditPlan: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return element(by.xpath("//*[@class=\"t_page\"]//button[contains(text(),'APM Case(s)')]")).isPresent();
            },
            /** APM Case detail ends */

            /** Multi task delete */
            taskMangmntTabClick: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'taskMangmntTab').click();
            },
            searchAPMCasesTasks: function () {
                browser.waitForAngular();
                browser.driver.sleep(14000);
                element.all(by.xpath("(//*[@class='col-md-12 filter-cont has-feedback']//input)")).clear();
                browser.driver.sleep(4000);
                return element.all(by.xpath("(//*[@class='col-md-12 filter-cont has-feedback']//input)")).sendKeys('APM Case(s)');
            },
            isFoundAPMCasesTasks: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return element(by.xpath("//*[@class='taskList ng-scope'][1]")).isPresent();
            },
            checkDeleteButtonDisabled: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return element.all(by.xpath("//*[@class='taskListAction']//button[2]")).getAttribute('disabled');
            },
            selectAllTasks: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                element(by.xpath("(//*[@class='col-md-12 filter-stat']/strong/span)")).click();
                browser.driver.sleep(2000);
                return element(by.xpath("//*[@class='col-md-12 filter-stat']/strong/span[1]")).click();
            },
            checkDeleteButtonEnabled: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return element(by.xpath("//*[@class='taskListAction']//button[2]")).isEnabled();
            },
            clickOnDelete: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return element(by.xpath("//*[@class='taskListAction']//button[2]")).click();
            },
            closeAPMErrorPopup: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                var noRecord = "Please unselect APM Case(s) to proceed with delete";
                element(by.xpath("//*[@id='multiTaskDeleteApmCaseDialog']/div")).isPresent().then(function(value){
                    console.log(value);
                    if(value === true){
                        element(by.xpath("//*[@id='multiTaskDeleteApmCaseDialog']/div/p")).getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("Text matched");
                        });
                    }else{
                        console.log("Text matched failed");
                    }
                });
                return element.all(by.xpath("//*[@class='btn btn--primary float--right u-mr- ng-binding'][contains(text(),'Ok')]")).click();
            },
            displayAllTasks: function () {
                browser.driver.sleep(2000);
                element.all(by.xpath("//*[@class='col-md-12 filter-stat']/strong/span[2]")).click();
                browser.driver.sleep(2000);
                element.all(by.xpath("(//*[@class='col-md-12 filter-cont has-feedback']//input)")).clear();
                browser.driver.sleep(2000);
                return element.all(by.xpath("(//*[@class='col-md-12 filter-cont has-feedback']//input)")).sendKeys(' ');
            },
            checkDeleteButtonDisableForSingleTask: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                element.all(by.xpath("//*[@id='top']/div[2]/table/tbody/tr/td[1]/div/div[2]/div[1]//*[@class='side_bar']")).click();
                browser.driver.sleep(5000);
                return element(by.xpath("//*[@class='ng-binding disabledAction'][contains(text(),'Delete')]"));
            },
            checkDeleteButtonDisableOnTaskDetail: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return element.all(by.xpath("//*[@class='taskdetails']/div[1]/div/i[@class='fa fa-trash-o ng-scope disabledAction']"));
            },
            checkDeleteButtonDisableOnTaskEdit: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return element.all(by.xpath("//*[@class='btn deleteTaskBtn ng-binding ng-scope default-border disabledAction']"));
            },
            goToTaskDetailPage: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return element(by.xpath("//*[@class='layout border-bottom']//*[@class='setright']//button[contains(text(), 'Cancel')]")).click();
            },
            deleteSingleAPMTask: function(){
                browser.waitForAngular();
                browser.driver.sleep(2000);
                element.all(by.xpath("//*[@class='taskList ng-scope'][1]//*[@class='check'][1]")).click();
                browser.driver.sleep(2000);
                return element.all(by.xpath("//*[@class='taskList ng-scope'][2]//*[@class='check'][1]")).click();
            },
            displayNonAPMTasks: function(){
                browser.waitForAngular();
                browser.driver.sleep(2000);
                element(by.xpath("//*[@class='fa fa-filter search-filter']")).click();
                browser.driver.sleep(2000);
                element(by.xpath("//*[@id='myModal']/section/div[1]/form/fieldset/table/tbody/tr[1]/td[2]/section/ol/li[1]//input")).click();
                browser.driver.sleep(2000);
                return element(by.xpath("//*[@id='btnModalPositive']")).click();
            },
            selectFirstTwoTasks: function(){
                browser.waitForAngular();
                browser.driver.sleep(2000);
                element(by.xpath("(//*[@class='col-md-12 filter-cont has-feedback']//input)")).sendKeys('testing');
                browser.driver.sleep(4000);
                element(by.xpath("//*[@class='taskList ng-scope'][1]//*[@class='check'][1]")).click();
                browser.driver.sleep(2000);
                return element(by.xpath("//*[@class='taskList ng-scope'][2]//*[@class='check'][1]")).click();
            },
            checkNoteWarningMsg: function(){
                browser.waitForAngular();
                browser.driver.sleep(2000);
                var title = "Warning"
                var msg1 = "Are you sure you want to delete this task?";
                var msg2 = "Note: tasks that are “locked“ on your reports page would be successfully deleted.";
                var btn1 = "Cancel";
                var btn2 = "Delete";
                element(by.xpath("//*[@id='multiTaskDeleteDialog']")).isPresent().then(function(value){
                    if(value === true){
                        element(by.xpath("//*[@id='multiTaskDeleteDialog']//h3")).getText().then(function (textValue) {
                            assert.equal(title, textValue);
                            console.log(textValue + " Text matched");
                        });
                        browser.driver.sleep(2000);
                        element(by.xpath("//*[@id='multiTaskDeleteDialog']//p[1]")).getText().then(function (textValue) {
                            assert.equal(msg1, textValue);
                            console.log(textValue + " Text matched");
                        });
                        browser.driver.sleep(2000);
                        element(by.xpath("//*[@id='multiTaskDeleteDialog']//p[2]")).getText().then(function (textValue) {
                            assert.equal(msg2, textValue);
                            console.log(textValue + " Text matched");
                        });
                        browser.driver.sleep(2000);
                        element(by.xpath("//*[@id='multiTaskDeleteDialog']//button[contains(text(), 'Cancel')]")).getText().then(function (textValue) {
                            assert.equal(btn1, textValue);
                            console.log(textValue + " Button matched");
                        });
                        browser.driver.sleep(2000);
                        element(by.xpath("//*[@id='multiTaskDeleteDialog']//button[contains(text(), 'Delete')]")).getText().then(function (textValue) {
                            assert.equal(btn2, textValue);
                            console.log(textValue + " Button matched");
                        });
                    }
                });
                browser.driver.sleep(4000);
                return element(by.xpath("//*[@id='multiTaskDeleteDialog']//button[contains(text(), 'Cancel')]")).click();
            },
            selectSingleAPMTask: function(){
                browser.waitForAngular();
                browser.driver.sleep(2000);
                element(by.xpath("(//*[@class='col-md-12 filter-stat']/strong/span)")).click();
                browser.driver.sleep(2000);
                return element(by.xpath("//*[@class='taskList ng-scope'][1]//*[@class='check'][1]")).click();
            },
            multiDeleteFinalCall: function(){
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return element(by.xpath("//*[@id='multiTaskDeleteDialog']//button[contains(text(), 'Delete')]")).click();
            },
            taskDeleteSuccessMessge: function(callback){
                browser.waitForAngular();
                browser.driver.sleep(2000);
                var val = "Task is deleted successfully.";
                element(by.xpath("//*[@id='js-toasts']//*[@class='pxh-toast__text']")).getText().then(function (value) {
                    if(val == value){
                        console.log(value);
                    } else{
                        console.log("Error: " +  value + " does not match");
                    }
                   callback();
                });

            },
            /** Multi task delete */

            aPMCaseLabelTurbineWidget: function (callback) {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                element(by.xpath("//*[@id='assetStatus_6']")).isPresent().then(function(value){
                    console.log(value);
                    if(value === true){
                        element(by.xpath("//*[@id='assetStatus_6']")).click().then(function () {
                        browser.driver.sleep(3000);    
                        element(by.xpath("//*[@id='popover']/div/div[1]/span[2]/span")).click().then(function(){                            
                        browser.getAllWindowHandles().then(function (handles) {
                    browser.driver.switchTo().window(handles[1]);
                    browser.driver.sleep(5000);
                    browser.driver.close();
                    browser.driver.sleep(3000);
                    browser.driver.switchTo().window(handles[0]).then(function () {
                      browser.driver.sleep(3000);  
                        element(by.xpath("(//*[@id='overlay'][@class='light style-scope px-overlay'])[1]")).click().then(function () {
                        console.log("APM Case label Matched");    
                        callback();
                        });
                    });
                });    
                        });
                    });
                }else{                    
                        browser.sleep(2000);
                        element(by.xpath("//*[@id='turbine_widget']/div[2]/div[5]/p/span[2]/span")).isPresent();
                        element(by.xpath("//*[@id='turbine_widget']/div[2]/div[5]/p/span[2]/span")).click().then(function () {
                            console.log("APM Case label matched failed");
                            callback();
                        });                        
                    }
                });
                
            },

            aPMCaseLabelTasksPlanTab: function (callback) {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                element(by.xpath("//*[@class='pull-right task-apm-icon ng-binding ng-scope'][contains(text(),'APM Case(s) ')]")).isPresent().then(function(value){
                    console.log(value);
                    if(value === true){
                        element(by.xpath("//*[@class='pull-right task-apm-icon ng-binding ng-scope'][contains(text(),'APM Case(s) ')]")).click().then(function () {
                        browser.driver.sleep(6000);                                                    
                        browser.getAllWindowHandles().then(function (handles) {
                    browser.driver.switchTo().window(handles[1]);
                    browser.driver.sleep(5000);
                    browser.driver.close();
                    browser.driver.sleep(3000);
                    browser.driver.switchTo().window(handles[0]).then(function () {
                      browser.driver.sleep(3000);                        
                        console.log("APM Case label Matched");    
                        callback();
                        });
                    });
                });
                }else{                    
                        browser.sleep(2000);
                        element(by.xpath("//*[@id='tabtitle'][contains(text(),'Plan')]")).isPresent();
                        element(by.xpath("//*[@id='tabtitle'][contains(text(),'Plan')]")).click().then(function () {
                            console.log("APM Case label matched failed");
                            callback();
                        });                        
                    }
                });
                
            },

            aPMCaseLabelEditTasks: function (callback) {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                element(by.xpath("//*[@class='fa fa-pencil task-edit-icon pull-right ng-scope']")).isPresent().then(function(value){
                    console.log(value);
                    if(value === true){
                        element(by.xpath("//*[@class='fa fa-pencil task-edit-icon pull-right ng-scope']")).click().then(function () {
                       browser.driver.sleep(8000);     
                       element(by.xpath("//*[@class='pull-right task-apm-icon ng-binding ng-scope'][contains(text(),'APM Case(s) ')]")).click().then(function () {     
                        browser.driver.sleep(6000);                                                    
                        browser.getAllWindowHandles().then(function (handles) {
                    browser.driver.switchTo().window(handles[1]);
                    browser.driver.sleep(5000);
                    browser.driver.close();
                    browser.driver.sleep(3000);
                    browser.driver.switchTo().window(handles[0]).then(function () {
                      browser.driver.sleep(3000);
                      element(by.xpath("(//*[@class='btn btn-default ng-binding'][contains(text(),'Cancel')])[1]")).click().then(function () {                        
                        console.log("APM Case label Matched");    
                        callback();
                              });
                           });
                        });
                    });
                });
                }else{                    
                        browser.sleep(2000);
                        element(by.xpath("//*[@id='tabtitle'][contains(text(),'Plan')]")).isPresent();
                        element(by.xpath("//*[@id='tabtitle'][contains(text(),'Plan')]")).click().then(function () {
                            console.log("APM Case label matched failed");
                            callback();
                        });                        
                    }
                });
                
            },

            aPMCaseLabelEditTasksExecutionTab: function (callback) {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                element(by.xpath("//*[@class='fa fa-pencil task-edit-icon pull-right ng-scope']")).isPresent().then(function(value){
                    console.log(value);
                    if(value === true){
                        element(by.xpath("//*[@class='fa fa-pencil task-edit-icon pull-right ng-scope']")).click().then(function () {
                       browser.driver.sleep(8000);     
                       element(by.xpath("(//*[@class='pull-right task-apm-icon ng-binding ng-scope'][contains(text(),'APM Case(s) ')])[2]")).click().then(function () {     
                        browser.driver.sleep(6000);                                                    
                        browser.getAllWindowHandles().then(function (handles) {
                    browser.driver.switchTo().window(handles[1]);
                    browser.driver.sleep(5000);
                    browser.driver.close();
                    browser.driver.sleep(3000);
                    browser.driver.switchTo().window(handles[0]).then(function () {
                      browser.driver.sleep(3000);
                      element(by.xpath("(//*[@class='btn btn-default ng-binding'][contains(text(),'Cancel')])[1]")).click().then(function () {                        
                        console.log("APM Case label Matched");    
                        callback();
                              });
                           });
                        });
                    });
                });
                }else{                    
                        browser.sleep(2000);
                        element(by.xpath("//*[@id='tabtitle'][contains(text(),'Plan')]")).isPresent();
                        element(by.xpath("//*[@id='tabtitle'][contains(text(),'Plan')]")).click().then(function () {
                            console.log("APM Case label matched failed");
                            callback();
                        });                        
                    }
                });
                
            },

            apmCasePriorityValidation: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'apmCasePriority').getAttribute('disabled');
                 },

            apmCaseRecurrenceValidation: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'apmCaseRecurrence').getAttribute('disabled');
                 },              

            activeSearchBtnMaintenance: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return cem.findElement(currentPage,'activeSearchBtn').sendKeys('Maintenance');
            },

            apmCaseDuedateFld: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return expect(element(by.xpath("//*[@id='createTurbine']/div/div[3]/form/div[14]/div[2]/div")).isEnabled()).to.eventually.be.true
                 },
            
                maintenanceTaskPriority: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return element(by.xpath("//*[@id='createTurbine']/div/div[3]/form/div[10]/div[1]/select")).isEnabled();
            },

            maintenanceTaskRecurrence: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return element(by.xpath("//*[@id='createTurbine']/div/div[3]/form/div[14]/div[1]/select")).isEnabled();
            },

            maintenanceDuedateFld: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return expect(element(by.xpath("//*[@id='createTurbine']/div/div[3]/form/div[12]/div[2]/div")).isEnabled()).to.eventually.be.true
                 },

        /** Report column changes -start */
           showHideColumnInTurbineOperating: function (callback) {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                element(by.xpath("//*[@id='turbineReducedDd']//*[@id='dropcell']")).isPresent();
                browser.driver.sleep(6000);
                return element(by.xpath("//*[@id='turbineReducedDd']//*[@id='dropcell']")).click();
           },
           checkPlannedOnDueOnAvailable: function(callback){
                browser.waitForAngular();
                browser.driver.sleep(6000);
                element(by.xpath("//*[@id='turbineReducedDd']//*[@id='list']/li[contains(text(),'Planned On')]")).isPresent();
                browser.driver.sleep(4000);
                element(by.xpath("//*[@id='turbineReducedDd']//*[@id='list']/li[contains(text(),'Due On')]")).isPresent();
                browser.driver.sleep(4000);
                return element(by.xpath("//*[@id='turbineReducedDd']//*[@id='dropcell']")).click();
           },
           selectPlannedOnDueOnInTurbine: function(callback){
                browser.waitForAngular();
                browser.driver.sleep(6000);
                var title1 = "Planned On";
                var match1 = false;
                element.all(by.xpath("//*[@id='parentDiv1']/div[2]/div/table/thead/tr/td/strong")).count().then(function (count) {
                    element.all(by.xpath("//*[@id='parentDiv1']/div[2]/div/table/thead/tr/td/strong")).each(function(el, index) {
                        el.getText().then(function (textValue) {
                            if(title1 == textValue){
                                console.log(title1 + ": title matched in table column - i.e. saved");
                                match1 = true;
                            }
                            if(count == (index+1) && match1 == false){
                                console.log(title1 + ": title not available in table column - i.e. "+title1+" has been removed");
                            }
                        });
                    });
                });
                if(match1 == false){
                    element(by.xpath("//*[@id='turbineReducedDd']//*[@id='dropcell']")).click();
                    browser.driver.sleep(2000);
                    element(by.xpath("//*[@id='turbineReducedDd']//*[@id='list']/li[4]")).click();
                    browser.driver.sleep(2000);
                    element.all(by.xpath("//*[@id='parentDiv1']/div[2]/div/table/thead/tr/td/strong")).count().then(function (count) {
                        element.all(by.xpath("//*[@id='parentDiv1']/div[2]/div/table/thead/tr/td/strong")).each(function(el, index) {
                            el.getText().then(function (textValue) {
                                if(title1 == textValue){
                                    console.log(title1 + ": column is now available in table");
                                    match1 = true;
                                }
                                if(count == (index+1) && match1 == false){
                                    assert.equal(title1, "not matched");//to make it fail
                                }
                            });
                        });
                    });
                    element(by.xpath("//*[@id='turbineReducedDd']//*[@id='dropcell']")).click();
                  }

                var title2 = "Due On";
                browser.driver.sleep(4000);
                var match2 = false;
                element.all(by.xpath("//*[@id='parentDiv1']/div[2]/div/table/thead/tr/td/strong")).count().then(function (count) {
                    element.all(by.xpath("//*[@id='parentDiv1']/div[2]/div/table/thead/tr/td/strong")).each(function(el, index) {
                        el.getText().then(function (textValue) {
                            if(title2 == textValue){
                                console.log(title2 + ": title matched in table column - i.e. saved");
                                match2 = true;
                            }
                            if(count == (index+1) && match2 == false){
                                console.log(title2 + ": title not available in table column - i.e. "+title2+" has been removed");
                            }
                        });
                    });
                })
                if(match2 == false){
                    browser.driver.sleep(2000);
                    element(by.xpath("//*[@id='turbineReducedDd']//*[@id='dropcell']")).click();
                    browser.driver.sleep(2000);
                    element(by.xpath("//*[@id='turbineReducedDd']//*[@id='list']/li[5]")).click();
                    browser.driver.sleep(2000);
                    element.all(by.xpath("//*[@id='parentDiv1']/div[2]/div/table/thead/tr/td/strong")).count().then(function (count) {
                        element.all(by.xpath("//*[@id='parentDiv1']/div[2]/div/table/thead/tr/td/strong")).each(function(el, index) {
                            el.getText().then(function (textValue) {
                                if(title2 == textValue){
                                    console.log(title2 + ": column is now available in table");
                                    match2 = true;
                                }
                                if(count == (index+1) && match2 == false){
                                    assert.equal(title2, "not matched"); //to make it fail
                                }
                            });
                        });
                    });
                      
                }
                return element(by.xpath("//*[@id='turbineReducedDd']//*[@id='dropcell']")).click();;
           },
           showHideColumnInPlannedMaintenance: function (callback) {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                element(by.xpath("//*[@id='plannedMainDropdown']//*[@id='dropcell']")).isPresent();
                browser.driver.sleep(4000);
                return element(by.xpath("//*[@id='plannedMainDropdown']//*[@id='dropcell']")).click();
            },                       
            checkPlannedOnDueOnAvailableInPlannedMaintenance: function(callback){
                browser.waitForAngular();
                browser.driver.sleep(4000);
                element(by.xpath("//*[@id='plannedMainDropdown']//*[@id='list']/li[contains(text(),'Planned On')]")).isPresent();
                browser.driver.sleep(4000);
                element(by.xpath("//*[@id='plannedMainDropdown']//*[@id='list']/li[contains(text(),'Due On')]")).isPresent();
                browser.driver.sleep(4000);
                return element(by.xpath("//*[@id='plannedMainDropdown']//*[@id='dropcell']")).click();
        },
        reportPODayTab: function () {
            browser.waitForAngular();
            browser.driver.sleep(9000);
            element(by.xpath("//*[@id='tabtitle'][text()='Plan of the Day']")).click();
            browser.driver.sleep(6000);
            return element(by.xpath("//*[@id='reportUnsaveMsgDialog']/div/div/button[contains(text(),'Yes')]")).click();
        },
        reportEODayTabSave: function () {
            browser.waitForAngular();
            browser.driver.sleep(9000);
            cem.findElement(currentPage,'reportEODTab').click();
            browser.driver.sleep(8000);
            return element(by.xpath("//*[@id='reportUnsaveMsgDialog']/div/div/button[contains(text(),'Yes')]")).click();
        },
        reportEODayTab: function () {
            browser.waitForAngular();
            browser.driver.sleep(9000);
            cem.findElement(currentPage,'reportEODTab').click();
            browser.driver.sleep(6000);
            return element(by.xpath("//*[@id='reportUnsaveMsgDialog']/div/div/button[contains(text(),'No')]")).click();
        },
        reportTechnicainTab: function () {
            browser.waitForAngular();
            browser.driver.sleep(9000);
            element(by.xpath("//*[@id='tabtitle'][text()='Technician']")).click();
            browser.driver.sleep(4000);
            return element(by.xpath("//*[@id='reportUnsaveMsgDialog']/div/div/button[contains(text(),'No')]")).click();
        },
        reportTechnicainTabSave: function () {
            browser.waitForAngular();
            browser.driver.sleep(6000);
            element(by.xpath("//*[@id='tabtitle'][text()='Technician']")).click();
            browser.driver.sleep(6000);
            return element(by.xpath("//*[@id='reportUnsaveMsgDialog']/div/div/button[contains(text(),'Yes')]")).click();
        },
        selectPlannedOnDueOnInPlannedMaintenance: function(callback){
            browser.waitForAngular();
            browser.driver.sleep(6000);
            var match1 = false;
            var title1 = "Planned On";
            element.all(by.xpath("//*[@id='parentDivPlanned']/div[2]/div/table/thead/tr/td/strong")).count().then(function (count) {
                element.all(by.xpath("//*[@id='parentDivPlanned']/div[2]/div/table/thead/tr/td/strong")).each(function(el, index) {
                    el.getText().then(function (textValue) {
                        if(title1 == textValue){
                            console.log(title1 + ": title matched in table column - i.e. saved");
                            match1 = true;
                        }
                        if(count == (index+1) && match1 == false){
                            console.log(title1 + ": title not available in table column - i.e. "+title1+" has been removed");
                        }
                    });
                });
            });
            if(match1 == false){
                element(by.xpath("//*[@id='plannedMainDropdown']//*[@id='dropcell']")).click();
                browser.driver.sleep(6000);
                element(by.xpath("//*[@id='plannedMainDropdown']//*[@id='list']/li[4]")).click();
                browser.driver.sleep(5000);
                element.all(by.xpath("//*[@id='parentDivPlanned']/div[2]/div/table/thead/tr/td/strong")).count().then(function (count) {
                    element.all(by.xpath("//*[@id='parentDivPlanned']/div[2]/div/table/thead/tr/td/strong")).each(function(el, index) {
                        el.getText().then(function (textValue) {
                            if(title1 == textValue){
                                console.log(title1 + ": column is now available in table");
                                match1 = true;
                            }
                            if(count == (index+1) && match1 == false){
                                assert.equal(title1, "not matched"); //to make it fail
                            }
                        });
                    });
                });
                element(by.xpath("//*[@id='plannedMainDropdown']//*[@id='dropcell']")).click();
            }

            
            browser.driver.sleep(6000);
            var title2 = "Due On";
            var match2 = false;
            element.all(by.xpath("//*[@id='parentDivPlanned']/div[2]/div/table/thead/tr/td/strong")).count().then(function (count) {
                element.all(by.xpath("//*[@id='parentDivPlanned']/div[2]/div/table/thead/tr/td/strong")).each(function(el, index) {
                    el.getText().then(function (textValue) {
                        if(title2 == textValue){
                            console.log(title2 + ": title matched in table column - i.e. saved");
                            match2 = true;
                        }
                        if(count == (index+1) && match2 == false){
                            console.log(title2 + ": title not available in table column - i.e. "+title2+" has been removed");
                        }
                    });
                });
            });
            if(match2 == false){
                browser.driver.sleep(6000);
                element(by.xpath("//*[@id='plannedMainDropdown']//*[@id='dropcell']")).click();
                browser.driver.sleep(5000);
                element(by.xpath("//*[@id='plannedMainDropdown']//*[@id='list']/li[5]")).click();
                browser.driver.sleep(2000);
                element.all(by.xpath("//*[@id='parentDivPlanned']/div[2]/div/table/thead/tr/td/strong")).count().then(function (count) {
                    element.all(by.xpath("//*[@id='parentDivPlanned']/div[2]/div/table/thead/tr/td/strong")).each(function(el, index) {
                        el.getText().then(function (textValue) {
                            if(title2 == textValue){
                                console.log(title2 + ": column is now available in table");
                                match2 = true;
                            }
                            if(count == (index+1) && match2 == false){
                                assert.equal(title2, "not matched"); //to make it fail
                            }
                        });
                    });
                });
              }
              return element(by.xpath("//*[@id='plannedMainDropdown']//*[@id='dropcell']")).click();
            },
            showHideColumnInTechncian: function (callback) {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                element(by.xpath("//*[@id='parentTechPlanned']//*[@id='dropcell']")).isPresent();
                browser.driver.sleep(4000);
                return element(by.xpath("//*[@id='parentTechPlanned']//*[@id='dropcell']")).click();
           },
           checkPlannedOnDueOnAvailableInechncian: function(callback){
                browser.waitForAngular();
                browser.driver.sleep(4000);
                element(by.xpath("//*[@id='parentTechPlanned']//*[@id='list']/li[contains(text(),'Planned On')]")).isPresent();
                browser.driver.sleep(4000);
                element(by.xpath("//*[@id='parentTechPlanned']//*[@id='list']/li[contains(text(),'Due On')]")).isPresent();
                browser.driver.sleep(4000);
                return element(by.xpath("//*[@id='parentTechPlanned']//*[@id='dropcell']")).click();
           },
           selectPlannedOnDueOnInTechnician: function(callback){
            browser.waitForAngular();
            browser.driver.sleep(6000);
            var match1 = false;
            var title1 = "Planned On";
            element.all(by.xpath("//*[@id='parentTechPlanned']/div[2]/div/table/thead/tr/td/strong")).count().then(function (count) {
                element.all(by.xpath("//*[@id='parentTechPlanned']/div[2]/div/table/thead/tr/td/strong")).each(function(el, index) {
                    el.getText().then(function (textValue) {
                        if(title1 == textValue){
                            console.log(title1 + " title matched in table column - i.e. saved");
                            match1 = true;
                        }
                        if(count == (index+1) && match1 == false){
                            console.log(title1 + ": title not available in table column - i.e. "+title1+" has been removed");
                        }
                    });
                });
            });
            if(match1 == false){
                element(by.xpath("//*[@id='parentTechPlanned']//*[@id='dropcell']")).click();
                browser.driver.sleep(6000);
                element(by.xpath("//*[@id='parentTechPlanned']//*[@id='list']/li[4]")).click();
                browser.driver.sleep(4000);
                element.all(by.xpath("//*[@id='parentTechPlanned']/div[2]/div/table/thead/tr/td/strong")).count().then(function (count) {
                    element.all(by.xpath("//*[@id='parentTechPlanned']/div[2]/div/table/thead/tr/td/strong")).each(function(el, index) {
                        el.getText().then(function (textValue) {
                            if(title1 == textValue){
                                console.log(title1 + ": column is now available in table");
                                match1 = true;
                            }
                            if(count == (index+1) && match1 == false){
                                assert.equal(title1, "not matched");//to make it fail
                            }
                        });
                    });
                });
                element(by.xpath("//*[@id='parentTechPlanned']//*[@id='dropcell']")).click();
              }

            
            browser.driver.sleep(6000);
            var title2 = "Due On";
            var match2 = false;
            element.all(by.xpath("//*[@id='parentTechPlanned']/div[2]/div/table/thead/tr/td/strong")).count().then(function (count) {
                element.all(by.xpath("//*[@id='parentTechPlanned']/div[2]/div/table/thead/tr/td/strong")).each(function(el, index) {
                    el.getText().then(function (textValue) {
                        if(title2 == textValue){
                            console.log(textValue + ": title matched in table column - i.e. saved");
                            match2 = true;
                        }
                        if(count == (index+1) && match2 == false){
                            console.log(title2 + ": title not available in table column - i.e. "+title2+" has been removed");
                        }
                    });
                });
            });
            if(match2 == false){
                browser.driver.sleep(5000);
                element(by.xpath("//*[@id='parentTechPlanned']//*[@id='dropcell']")).click();
                browser.driver.sleep(3000);
                element(by.xpath("//*[@id='parentTechPlanned']//*[@id='list']/li[5]")).click();
                browser.driver.sleep(3000);
                element.all(by.xpath("//*[@id='parentTechPlanned']/div[2]/div/table/thead/tr/td/strong")).count().then(function (count) {
                    element.all(by.xpath("//*[@id='parentTechPlanned']/div[2]/div/table/thead/tr/td/strong")).each(function(el, index) {
                        el.getText().then(function (textValue) {
                            if(title2 == textValue){
                                console.log(title2 + ": column is now available in table");
                                match2 = true;
                            }
                            if(count == (index+1) && match2 == false){
                                assert.equal(title2, "not matched"); //make it fail
                            }
                        });
                    });
                });
              }
              return element(by.xpath("//*[@id='parentTechPlanned']//*[@id='dropcell']")).click();
            },
           /** Report column changes -end */

           taskTypeAPMChkbox: function () {
           browser.waitForAngular();
           browser.driver.sleep(3000);
           return cem.findElement(currentPage,'taskTypeAPMChkbox').click();
        },
        
         taskTypeMaintenance: function () {
           browser.waitForAngular();
           browser.driver.sleep(3000);
           return cem.findElement(currentPage,'taskTypeMaintenanceChkbox').click();
        },
        
        assetTypeTurbine: function () {
           browser.waitForAngular();
           browser.driver.sleep(4000);
           return cem.findElement(currentPage,'assetTypeTurbine').click();
        },
        
        //* Previous day reports functions 

        navigateToPreviusDayReport: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
               return cem.findElement(currentPage,'previousDayReportNav').click();
            },

            navigateToCurrentDayReport: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'currentDayReportNav').click();
            },

           fetchCountTurbinesOnline: function () {
                    browser.driver.sleep(5000);
                   //return cem.findElement(currentPage,'workPlanDate').getText();
                    return cem.findElement(currentPage,'countTurbinesOnline').getText().then(function (countTurbinesOnline) {
                        console.log("Count of Turbines Online: "+ countTurbinesOnline);
                        storeCountTurbinesOnline = countTurbinesOnline;
                    });

                },

                validateCountTurbinesOnline: function () {
                    browser.driver.sleep(8000);
                    //return cem.findElement(currentPage,'workPlanDate').getText();
                    return cem.findElement(currentPage,'countTurbinesOnline').getText().then(function (countTurbinesOnline) {
                        console.log("Count of Turbines Online in Previous Day Report: "+ countTurbinesOnline);
                        return assert.equal(storeCountTurbinesOnline, countTurbinesOnline);
                   });

                },

                fetchWeatherWidgetSiteName: function () {
                    browser.driver.sleep(5000);
                    //return cem.findElement(currentPage,'workPlanDate').getText();
                    return cem.findElement(currentPage,'weatherWidgetSiteName').getText().then(function (weatherWidgetSiteName) {
                        console.log("Site Name Displayed in Weather Widget: "+ weatherWidgetSiteName);
                        storeWeatherWidgetSiteName = weatherWidgetSiteName;
                    });

                },

                validateWeatherWidgetSiteName: function () {
                    browser.driver.sleep(5000);
                    //return cem.findElement(currentPage,'workPlanDate').getText();
                   return cem.findElement(currentPage,'weatherWidgetSiteName').getText().then(function (weatherWidgetSiteName) {
                        console.log("Previous Day Report Site Name Displayed in Weather Widget: "+ weatherWidgetSiteName);
                        return assert.equal(storeWeatherWidgetSiteName, weatherWidgetSiteName);
                    });

                },

              reportEODNotes: function () {
                 browser.driver.sleep(10000);
                 return cem.findElement(currentPage,'reportEODNotes').clear();
                },

                reportTechReportNotes: function () {
                 browser.driver.sleep(10000);
                 return cem.findElement(currentPage,'reportTechReportNotes').clear();
                },

            addReportEODNotes: function () {
                 browser.driver.sleep(8000);
                 return cem.findElement(currentPage,'reportEODNotesAfterClear').sendKeys("Test EOD notes...");
                },

                addTechReportNotes: function () {
                 browser.driver.sleep(8000);
                 return cem.findElement(currentPage,'reportTechReportNotesAfterClear').sendKeys("Test Technician notes...");
               },

          

		}

	};

    module.exports = new TaskMgmtPage();

}());
