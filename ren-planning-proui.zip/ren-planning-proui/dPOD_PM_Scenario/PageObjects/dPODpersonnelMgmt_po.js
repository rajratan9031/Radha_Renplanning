(function() {
    'use strict';

    var currentPage = 'taskMgmtPage';
    var text;
    var email = text;
    var lFirstName;
    var lLastName;
    var lJobTitle;
    var lMobileNumber;
    var lFullName;
    var records;
    var Count;
    var flag1;
    var flag2;
    var site;
    var CrewName;
    var saveSite;
    var mNumber;
    var allStoppedCount;
    var allFaultedCount;
    var allNetcomCount;
    var allImpactedCount;
    var activeTurbine;
    var totalTurbine;
    var allApmCases;
    var sEmail;
    var enabledSites;
    var disabledSite;
    var allSites;
    var currentSite;
    var currentDate;
    var turbineNumber;
    var taskNmber;
    var taskName;
    var CrewCount;
    var initialCrewCount;
    var deleteCrewCount;
    var assignContra;
    var previousAssignCrew;
    var saveSiteName;
    var SitesNamePM;
    var SiteNameDpod;
    var crewsCrewName;
    var personnelName = "z z";
    var workplanCrewCount;
    var currentURL;

    var TaskMgmtPage = function() {

        return {
            get: function () {
                return browser.driver.get(browser.params.login.baseUrl);
                browser.waitForAngular();
            },
            setName: function (username) {
                return cem.findElement(currentPage, 'username').sendKeys(username);
            },
            setPassword: function (password) {
                return cem.findElement(currentPage, 'password').sendKeys(password);
            },
            clickLogin: function () {
                return cem.findElement(currentPage, 'password').sendKeys(protractor.Key.ENTER);
            },
            getLogin: function (url) {
                browser.driver.get(browser.params.login.baseUrl);
                return browser.driver.isElementPresent(by.xpath(browser.params.login.btn));
            },

            getELogin: function (url) {
                browser.driver.get(browser.params.login.baseUrl);
                return browser.driver.isElementPresent(by.xpath(browser.params.login.btn1));
            },

            waitForturbineTaskStatusLink: function () {
                browser.waitForAngular();
                return TestHelper.isElementPresent(currentPage, 'turbineTaskStatusLink');
            },

            turbineTaskStatusLink: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage, 'turbineTaskStatusLink').click();
            },

            waitFortaskPlanTabInfo: function () {
                browser.waitForAngular();
                browser.driver.sleep(15000);
                return TestHelper.isElementPresent(currentPage, 'taskPlanTabInfo');
            },

            taskExecutionTab: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage, 'taskExecutionTab').click();
            },
            compCompleteDate: function () {
                browser.waitForAngular();
                var date = cem.findElement(currentPage, 'date').getText();
                return date;

            },
            taskTypetext1: function () {
                browser.waitForAngular();
                var taskType = cem.findElement(currentPage, 'taskType1').getText();
                return taskType;

            },

            taskExecutionTabComplDate: function () {
                browser.waitForAngular();
                var exeComplDate = cem.findElement(currentPage, 'exeTabCompleteDateField').getText();
                return exeComplDate;
            },
            taskMainCompleteDate: function () {
                browser.waitForAngular();
                var exeComplDate1 = cem.findElement(currentPage, 'completeDateField').getText();
                return exeComplDate1;
            },

            //Create Execution code
            waitForcreateButton: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return TestHelper.isElementPresent(currentPage, 'createButton');
            },


            isTaskMangmntTabVisibile: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return TestHelper.isElementPresent(currentPage, 'taskMangmntTab');
            },

            taskMangmntTab: function (callback) {
                browser.sleep(10000);
                cem.findElement(currentPage, 'taskMangmntTab').click();
                callback();
            },

            createButton: function () {
                browser.waitForAngular();
                browser.driver.sleep(30000);
                return cem.findElement(currentPage, 'createButton').click();
            },

            waitFortitleField: function () {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return TestHelper.isElementPresent(currentPage, 'titleField');
            },

            titleField: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'titleField').sendKeys('Automation_Testing');
            },
            titleField1: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'titleField').sendKeys('Delete_Task');
            },
            descriptionField: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'descriptionField').sendKeys('Automation Testing');
            },

            categoryDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'categorySelect').click();
            },
            groupDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'groupDropdown').click();
            },

            turbinesIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'turbinesIcon').click();
            },
            turbineSearch: function (Value) {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'turbineSearch').sendKeys(Value);

            },
            turbineSelectAll: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage, 'turbineSelectAll').click();
            },
            turbines114: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'turbines114').click();
            },
            turbines43: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'turbines43').click();
            },
            turbines141: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'turbines141').click();
            },
            turbinesSelectionSaveBtn: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage, 'turbinesSelectionSaveBtn').click();
            },
            priorityDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'priorityDropdown').click();
            },
            sitePriorityDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'sitePriorityDropdown').click();
            },
            estimatedTechsDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'estimatedTechsDropdown').click();
            },
            siteEstimatedTechsDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'siteEstimatedTechsDropdown').click();
            },
            dueDateBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'dueDateBtn').click();
            },
            dueDateSelection: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'dueDateSelection').click();
            },
            recurrenceDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'recurrenceDropdown').click();
            },
            recurrenceEndAfterBtn: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage, 'recurrenceEndAfterBtn').click();
            },
            recurrenceEndAfterOcc: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage, 'recurrenceEndAfterTxt').sendKeys('2');
            },


            partsNeededTxtField: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage, 'partsNeededTxtField').sendKeys('Automation Testing');
            },
            techNotesTxtField: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage, 'techNotesTxtField').sendKeys('Automation Testing');
            },
            pODEODNotesTxtField: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage, 'pODEODNotesTxtField').sendKeys('Automation Testing');
            },
            clickOnChoosefile: function () {
                browser.waitForAngular();
                cem.findElement(currentPage, 'clickOnChoosefile').click();
                return cem.findElement(currentPage, 'clickOnChoosefile').sendKeys("C://Users//Public//Pictures//Sample Pictures//Desert");
            },
            clickOpen: function () {
                return cem.findElement(currentPage, 'password').sendKeys(protractor.Key.ENTER);
            },
            clickAddBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'clickAddBtn').click();
            },
            clickErrorBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'clickErrorBtn').click();
            },
            successOkBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'successOkBtn').click();
            },
            activeSearchBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(80000);
                return cem.findElement(currentPage, 'activeSearchBtn').sendKeys('Automation_Testing');
            },
            activeSearchBtn1: function () {
                browser.waitForAngular();
                browser.driver.sleep(70000);
                return cem.findElement(currentPage, 'activeSearchBtn').sendKeys('Delete_Task');
            },
            createdTaskVerfication1: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'createdTaskVerfication1').getText();
            },
            createdTaskVerfication2: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'createdTaskVerfication2').getText();
            },
            createdTaskTurbine1: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'createdTaskTurbine1').getText();
            },
            createdTaskTurbine2: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage, 'createdTaskTurbine2').getText();
            },
            completedTaskTurbine1: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'completedTaskTurbine1').getText();
            },
            completedTaskTurbine3: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'completedTaskTurbine3').getText();
            },
            completedTaskVerification: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage, 'completedTaskVerification').getText();
            },
            completedTaskVerification1: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'completedTaskVerification1').getText();
            },
            turbineTaskStatusLink1: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'turbineTaskStatusLink1').click();
            },
            planModuleTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return cem.findElement(currentPage, 'planModuleTab').click();
            },
            WaitForPlanModuleTab: function () {
                browser.waitForAngular();
                return TestHelper.isElementPresent(currentPage, 'planModuleTab');
            },
            editTaskBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage, 'editTaskBtn').click();
            },
            editExecutionTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'editExecutionTab').click();
            },
            editTaskStatusCompletedChkbox: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'editTaskStatusCompletedChkbox').click();
            },
            editCompletedDatePic: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'editCompletedDatePic').click();
            },
            editCompletedDateSelect: function () {
                browser.waitForAngular();
                //cem.findElement(currentPage,'editCompletedMonthSelect').click();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'editCompletedDateSelect').click();
            },

            waitForeditResolutionField: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return TestHelper.isElementPresent(currentPage, 'editResolutionField');
            },
            editResolutionField: function () {
                browser.waitForAngular();
                return cem.findElement(currentPage, 'editResolutionField').sendKeys('Resolution notes');
            },
            editSaveBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                cem.findElement(currentPage, 'editSaveBtn').click();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage, 'successOkBtn').click();
            },
            turbineTaskStatusLink2: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                cem.findElement(currentPage, 'activeSearchBtn').sendKeys('Automation_Testing');
                browser.driver.sleep(6000);
                return cem.findElement(currentPage, 'turbineTaskStatusLink2').click();
            },
            turbineTaskStatus2: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                cem.findElement(currentPage, 'editTaskBtn').click();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'editExecutionTab').click();
            },
            editTaskStatus2: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'editTaskStatusCompletedChkbox').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'actualDuration').sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'actualDuration').sendKeys(protractor.Key.DELETE);
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'actualDuration').sendKeys('08');
                ;
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'editResolutionField').sendKeys('Resolution notes');
                browser.driver.sleep(5000);
                cem.findElement(currentPage, 'editSaveBtn').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'successOkBtn').click();
            },
            applicationRefresh: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                cem.findElement(currentPage, 'dashboardTab').click();
                browser.driver.sleep(10000);
                cem.findElement(currentPage, 'taskTab').click();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage, 'activeSearchBtn').sendKeys('Automation_Testing');
            },
            completedTaskVerfication2: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'createdTaskAssertion2').getText();
            },
            planModule: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'dashboardTab').click();
            },
            completedTaskTurbine2: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'completedTaskTurbine2').getText();
            },
            categoryDropdown1: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'categoryDropdown1').click();
            },
            categoryDropdown2: function () {
                browser.waitForAngular();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'categoryDropdown2').click();
            },
            editTaskpage: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                cem.findElement(currentPage, 'turbineTaskStatusLink2').click();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage, 'editTaskBtn').click();
            },
            editingDescriptionField: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                cem.findElement(currentPage, 'descriptionField').clear();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'descriptionField').sendKeys('dPOD Testing');
            },
            verifyEditedDescField: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                cem.findElement(currentPage, 'activeSearchBtn').sendKeys('Automation_Testing');
                browser.driver.sleep(8000);
                cem.findElement(currentPage, 'turbineTaskStatusLink2').click();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'descriptionText').getText();
            },
            dueDateErrorMessage: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'dueDateErrorMessage').getText();
            },
            dueDateSelecting: function () {
                browser.waitForAngular();
                cem.findElement(currentPage, 'dueDateCalendar').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'dueDateCalenderIcon').click();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'dueDateSelect').click();
            },

            crewThetaCrew1: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'crewThetaCrew1').getText();
            },
            crewThetaCrew2: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'crewThetaCrew2').getText();
            },
            crewThetaCrew3: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'crewThetaCrew3').getText();
            },
            crewThetaCrew4: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'crewThetaCrew4').getText();
            },
            workPlanThetaCrew1: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'workPlanThetaCrew1').getText();
            },
            workPlanThetaCrew2: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage, 'workPlanThetaCrew2').getText();
            },
            workPlanThetaCrew3: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'workPlanThetaCrew3').getText();
            },
            workPlanThetaCrew4: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'workPlanThetaCrew4').getText();
            },
            crewSection3: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'crewSection3').getText();
            },
            crewSection: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'crewSection3').click();
            },
            removeAllTech: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'removeAllTech').click();
            },
            removeAllTech1: function () {
                browser.driver.sleep(4000);
                cem.findElement(currentPage, 'removeAllTech').click();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'removeAllTechNoBtn').click();
            },

            deleteTaskBtn: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'deleteTaskBtn').click();
            },

            deleteConformation: function () {
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'deleteTaskBtn').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'deleteConformationYesBtn').click();
            },

            deleteConformationYesBtn: function () {
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'deleteConformationYesBtn').click();
            },

            deleteConformationText: function () {
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'deleteConformationText').getText();
            },
            deleteConformationOKBtn: function () {
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'deleteConformationOKBtn').click();
            },
            errorConformationText: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'errorConformationText').getText();
            },
            statusOKbtn: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'statusOKbtn').click();
            },

            turbineTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage, 'turbineTab').click();
            },

            deleteHashTag: function () {
                browser.driver.sleep(6000);
                return cem.findElement(currentPage, 'deleteHashTag').click();
            },
            waitForclickOnHashTag: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return TestHelper.isElementPresent(currentPage, 'clickOnHashTag');
            },

            clickOnHashTag: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage, 'clickOnHashTag').click();
            },
            createHashTag: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                cem.findElement(currentPage, 'hashTagTextField').sendKeys('Test_UAT');
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'textClick').click();
            },

            turbineLandingSearch: function () {
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'turbineLandingSearch').sendKeys('101');
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'selectFirstTurbine').click();
            },

            selectFirstTurbine: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'selectFirstTurbine').click();
            },

            turbineNameInSearch: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'turbineNameInSearch').getText();
            },

            turbineModelInSearch: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'turbineModelInSearch').getText();
            },
            lastVisitInSearch: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'lastVisitInSearch').getText();
            },
            nextTaskInSearch: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'nextTaskInSearch').getText();
            },
            turbineNameInPane: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'turbineNameInPane').getText();
            },
            turbineModelInPane: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'turbineModelInPane').getText();
            },
            lastVisitInPane: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'lastVisitInPane').getText();
            },
            nextTaskInPane: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'nextTaskInPane').getText();
            },

            turbineDisplayNameSort: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                cem.findElement(currentPage, 'sortMenuTab').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'turbineDisplayNameSort').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'sortMenuTab').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'selectFirstTurbine').click();
            },
            turbineNameSort: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'sortMenuTab').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'turbineNameSort').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'sortMenuTab').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'selectFirstTurbine').click();
            },
            turbineModelSort: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'sortMenuTab').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'turbineModelSort').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'sortMenuTab').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'selectFirstTurbine').click();
            },
            lastVisitSort: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'sortMenuTab').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'lastVisitSort').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'sortMenuTab').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'selectFirstTurbine').click();
            },
            nextTaskSort: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'sortMenuTab').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'nextTaskSort').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'sortMenuTab').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'selectFirstTurbine').click();
            },
            waitForturbineTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return TestHelper.isElementPresent(currentPage, 'turbineTab');
            },
            waitForturbineNames: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return TestHelper.isElementPresent(currentPage, 'turbineHomePage');
            },
            turbineLanding: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'turbineHomePage').click()
            },

            fromDateRangeSearch: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'turbineFromDate').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'turbineFromDateIcon').click();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'turbineFromDateSelect').click();
            },
            toDateRangeSearch: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'turbineToDate').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'turbineToDateToday').click();
            },
            dateRangeSearchFld: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'turbineHistorySearch').sendKeys('Testing1');
            },
            planSaveBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage, 'planSaveBtn').click();
            },
            reportsTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage, 'reportsTab').click();
            },
            waitForreportsTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return TestHelper.isElementPresent(currentPage, 'reportsTab');
            },
            reportsPerformanceBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'reportsPerformanceBtn').click();
            },
            reportsSiteContractsBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'reportsSiteContractsBtn').click();
            },
            turbineInReducedTask: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'turbineInReducedTask').click();
            },
            reportsSaveBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage, 'reportsSaveBtn').click();
            },
            reportsPreviewBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'reportsPreviewBtn').click();
            },
            reportsPrintToEmailBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'reportsPrintToEmailBtn').click();
            },
            reportsInPlnnedMntTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'reportsInPlnnedMntTab').getText();
            },
            turbineInPlnnedMnt: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'turbineInPlnnedMnt').getText();
            },
            taskInPlnnedMnt: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'taskInPlnnedMnt').getText();
            },
            reportWeatherDetails: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'reportWeatherDetails').getText();
            },
            reportWeatherDate: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'reportWeatherDate').getText();
            },

            reportWeatherSky: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'reportWeatherSky').getText();
            },
            reportWeatherWind: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'reportWeatherWind').getText();
            },
            reportWeatherWindDirection: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'reportWeatherWindDirection').getText();
            },
            reportEODTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage, 'reportEODTab').click();
            },
            reportTORSAddTower: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage, 'reportTORSAddTower').click();
            },
            reportAddTaskDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                cem.findElement(currentPage, 'reportAddTaskDropdown').click();
                browser.driver.sleep(5000);
                //cem.findElement(currentPage,'reportAddTaskSearch').sendKeys('10');
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'reportAddTaskSelect').click();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'reportAddTaskBtn').click();
            },
            reportPMAddTower: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'reportPMAddTower').click();
            },
            reportPMAddTaskDropdown: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'reportPMAddTaskDropdown').click();
                browser.driver.sleep(2000);
                //cem.findElement(currentPage,'reportPMAddTaskSearch').sendKeys('11');
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'reportPMAddTaskSelect').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'reportPMAddTaskBtn').click();
            },
            waitForreportArchiveBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return TestHelper.isElementPresent(currentPage, 'reportEODArchivebtn');
            },
            reportArchiveBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'reportEODArchivebtn').click();
            },
            reportEODArchivePDFReport: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'reportEODArchivePDFReport').getText();
            },
            addExistingTaskRadioBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage, 'addExistingTaskRadioBtn').click();
            },
            addNewORexistingTaskBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage, 'addNewORexistingTaskBtn').click();
            },
            saveConformationNoBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage, 'saveConformationNoBtn').click();
            },
            existingTaskSelectDrpdwn: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage, 'existingTaskSelectDrpdwn').click();
            },
            selectAsset: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'selectAsset').click();
            },
            selectAsset1: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'addTaskSelectBtn').click();
            },
            workplanSaveBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'workplanSaveBtn').click();
            },
            addButton: function () {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage, 'addButton').click();
            },
            newlyAddedTask: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'newlyAddedTask').getText();
            },
            dragAndDropText: function () {
                browser.waitForAngular();
                TestHelperPO.isElementPresent(cem.findElement(currentPage, 'field')).then(function () {
                    var src = cem.findElement(currentPage, 'field');
                    var drop = cem.findElement(currentPage, 'src');
                    return browser.actions().dragAndDrop(src, drop).mouseUp().perform();
                    //browser.pause();
                });
                // })
            },
            taskCompletion: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'titleField').sendKeys('Automation_Testing');
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'descriptionField').sendKeys('Automation Testing');
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'categorySelect').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'turbinesIcon').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'turbines114').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'turbinesSelectionSaveBtn').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'priorityDropdown').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'dueDateCalendar').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'dueDateSelection').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'recurrenceDropdown').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'recurrenceEndAfterBtn').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'recurrenceEndAfterTxt').sendKeys('2');
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'partsNeededTxtField').sendKeys('Automation Testing');
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'techNotesTxtField').sendKeys('Automation Testing');
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'clickAddBtn').click();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'taskSuccessOkBtn').click();
            },
            testPlanedTaskLnk: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'testPlanedTaskLnk').click();
            },
            actualDuration: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'actualDuration').sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'actualDuration').sendKeys(protractor.Key.DELETE);
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'actualDuration').sendKeys('06');
            },
            workplanSideArrow: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage, 'workplanSideArrow').click();
            },
            workplanAddTurbineIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage, 'workplanAddTurbineIcon').click();
            },
            addExistingTaskRadioBtn4: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'addExistingTaskRadioBtn4').click();
            },
            addExistingTask3: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'addExistingTaskDropdwn').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'addExistingTaskSelection').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'addExistingTaskAddbtn3').click();
            },
            editTaskStatus: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'editExecutionTab1').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'editTaskStatusCompletedChkbox1').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'editCompletedDatePic1').click();
                cem.findElement(currentPage, 'editCompletedMonthSelect1').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'editCompletedDateSelect1').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'editResolutionField1').clear();
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'editResolutionField1').sendKeys('Resolution notes');
                browser.driver.sleep(5000);
                cem.findElement(currentPage, 'editSaveBtn1').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'successOkBtn1').click();
            },
            testPlanNotCompleted: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'testPlanNotCompleted').getCssValue('background-color');
            },
            testPlanCompleted: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage, 'testPlanCompleted').getCssValue('background-color');
            },
            testPlanNotCompOperation: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'testPlanNotCompleted').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'actualDurationHour').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'actualDurationMinute').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'resolutionNotes1').clear();
                cem.findElement(currentPage, 'resolutionNotes1').sendKeys('Resolution notes');
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'doneBtn1').click();
            },
            unknownNotCompOperation: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'unknownNotCompleted').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'actualDurationHour2').click();
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'actualDurationMinute2').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'resolutionNotes2').sendKeys('Resolution notes');
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'doneBtn2').click();
            },
            MultipleCancelImage1: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'MultipleCancelImage').getText();
            },
            MultipleCancelImage: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage, 'MultipleCancelImage').click();
            },
            MultipleRefreshImage: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage, 'MultipleRefreshImage').click();
            },
            editTechDetails: function () {
                cem.findElement(currentPage, 'contractorNameClik').click();
                browser.driver.sleep(8000);
                cem.findElement(currentPage, 'editTechDetailsLink').click();
                browser.driver.sleep(8000);
                cem.findElement(currentPage, 'initialsFld').clear();
                browser.driver.sleep(8000);
                cem.findElement(currentPage, 'initialsFld').sendKeys('UAT');
                browser.driver.sleep(12000);
                return cem.findElement(currentPage, 'editTechSaveBtn').click();
            },
            editTechDetailsTooltip: function () {
                cem.findElement(currentPage, 'contractorNameClik').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'editTechDetailsLink').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'FirstNameFld').clear();
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'FirstNameFld').sendKeys('Radha1');
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'lastNameFld').clear();
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'lastNameFld').sendKeys('C323');
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'editTechSaveBtn').click();
            },
            initialVerification: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'contractorNameTooltip').getText();
            },
            toolTipVerification: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'contractorNameVerif').click();
            },
            markAsWorkingAndOnCallStatus: function () {
                cem.findElement(currentPage, 'contractorName').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'markAsNotWorking').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'markAsOnCall').click();
            },
            saveButton: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'saveButton').click();
            },
            turbineStatusWidget: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'turbineStatusText').getText();
            },
            faultedDetails: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'faultedName').getText();
            },
            stoppedDetails: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'stoppedName').getText();
            },
            impactedDetails: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'impactedName').getText();
            },
            netcomDetails: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'netcomName').getText();
            },
            diagnosticsDetails: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'diagnosticsName').getText();
            },

            faultedTurbines: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'faultedTurbines').getText();
            },
            stoppedTurbines: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'stoppedTurbines').getText();
            },
            impactedTurbines: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'impactedTurbines').getText();
            },
            netcomTurbines: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'netcomTurbines').getText();
            },
            diagnosticsTurbines: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'diagnosticsTurbines').getText();
            },
            adminTabInfo: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'adminTabInfo').click();
            },
            adminAddButton: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'adminAddButton').click();
            },
            personalInformation: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'personalInfoSSOField').sendKeys('502728626');
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'personalInfoRoleDropdown').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'personalInfoFirstField').sendKeys('dPOD');
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'personalInfoLastField').sendKeys('Testing');
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'personalInfoInitialsField').sendKeys('Test');
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'personalInfoEmailField').sendKeys('testing@ge.com');
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'personalInfoCountryCode').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'personalInfoCountryCodeSelection').click();
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'personalInfoPhoneNumber').sendKeys('8885432000');
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'personalInfoNextButton').click();
            },
            assginSiteCheckbox: function () {
                browser.driver.sleep(1000);
                cem.findElement(currentPage, 'assginSiteCheckbox').click();
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'adminAddButton').click();
            },
            personalInfoValidation: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'updatedSuccessMsg').getText();
            },
            personalInfoUpdateBtn: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'updatedSuccessBtn').click();
            },
            personalInfoSSOValidation: function () {
                browser.driver.sleep(1000);
                return cem.findElement(currentPage, 'updatedSuccessMsg').getText();
            },
            workPlanDate: function () {
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'workPlanDate').getText();
            },
            pastPlanDateChaneIcon: function () {
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'pastPlanDateChaneIcon').click();
            },

            siteTaskSelect: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'siteTaskSelect').click();
            },
            siteCategoryDropdown: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'siteCategoryDropdown').click();
            },
            recipientBtn: function () {
                browser.driver.sleep(10000);
                return cem.findElement(currentPage, 'recipientBtn').click();
            },
            recipientMailidTxtFld: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'recipientMailidTxtFld').sendKeys('dpod2.0devteam@ge.com');
            },
            recipientMailidEnter: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'recipientMailidEnter').click();
            },
            recipientDeleteBtn: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'recipientDeleteBtn').click();
            },
            recipientBackBtn: function () {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'recipientBackBtn').click();
            },
            reportNotes: function () {
                browser.driver.sleep(10000);
                return cem.findElement(currentPage, 'reportNotes').clear();
            },
            reportNotes1: function () {
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'reportNotes').sendKeys('dPOD_Testing');
            },
            turbineRemoveWorkplan: function () {
                browser.driver.sleep(6000);
                return cem.findElement(currentPage, 'turbineRemoveWorkplan').click();
            },
            addNewORexistingTaskBtn1: function () {
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'addNewORexistingTaskBtn1').click();
            },
            addExistingTaskRadioBtn1: function () {
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'addExistingTaskRadioBtn1').click();
            },
            existingTaskDropdwn: function () {
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'existingTaskDropdwn').click();
            },
            taskAddButton: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                cem.findElement(currentPage, 'existingTurbineSelection').click();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'taskAddButton').click();
            },
            existingTurbineSelect: function () {
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'existingTurbineSelect').click();
            },
            PlanWeatherWidget: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'PlanWeatherWidget').getText();
            },
            PlanWeather: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'PlanWeather').getText();
            },
            PlanWeatherTemp: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'PlanWeatherTemp').getText();
            },
            performanceWidgetPOD: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'performanceWidgetPOD').getText();
            },
            turbineStatusWidgetPOD: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'turbineStatusWidgetPOD').getText();
            },
            siteContactsWidgetPOD: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'siteContactsWidgetPOD').getText();
            },
            attachmentsWidgetPOD: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'attachmentsWidgetPOD').getText();
            },
            groupDropdwn: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'groupDropdwn').click();
            },
            waitForsiteGroupDropdwn: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return TestHelper.isElementPresent(currentPage, 'siteGroupDropdwn');
            },
            siteGroupSelect: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                cem.findElement(currentPage, 'siteGroupDropdwn').click();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'siteGroupSelect').click();
            },

            siteCrewsHeading: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'siteCrewsHeading').getText();
            },
            siteCrew1: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'siteCrew1').getText();
            },
            siteCrew2: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'siteCrew2').getText();
            },
            siteCrew3: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'siteCrew3').getText();
            },
            siteCrew4: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'siteCrew4').getText();
            },
            siteCrew5: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'siteCrew5').getText();
            },
            siteCrew6: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'siteCrew6').getText();
            },
            performanceWidget: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'performanceWidget').getText();
            },
            mTDPWProduction: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'mTDPWProduction').getText();
            },
            mTDPWProductionValue: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'mTDPWProductionValue').getText();
            },
            mTDPWAvailability: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'mTDPWAvailability').getText();
            },
            mTDPWAvailabilityValue: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'mTDPWAvailabilityValue').getText();
            },
            performanceYTDButton: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'performanceYTDButton').click();
            },
            taskFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'taskFilter').click();
            },
            turbineCheckbox: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'turbineCheckbox').click();
            },
            filterApplyBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'filterApplyBtn').click();
            },
            turbinePendingCheckbox: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'turbinePendingCheckbox').click();
            },

            turbineFilter: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'turbineFilter').click();
            },
            turbineOnlineCheckbox: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'turbineOnlineCheckbox').click();
            },
            turbineOnlineStatus: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage, 'turbineOnlineStatus').getText();
            },
            turbineStatusTriangular1: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'turbineStatusTriangular').getText();
            },
            firstPulsePoint: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'firstPulsePoint').click();
            },
            crewAssignForPulsePoint: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'crewAssignForPulsePoint').click();
            },
            turbineStatusTriangular: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'turbineStatusTriangular').isPresent();
            },
            taskTypeFilterChkbox: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'taskTypeETCChkbox').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'taskTypeMCEChkbox').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'taskTypeMaintenanceChkbox').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'taskTypePunchListChkbox').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'taskTypeRetrofitsChkbox').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'taskTypeTILChkbox').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'taskTypeUMChkbox').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'taskTypeOthersChkbox').click();
            },
            taskFilterPlusePoint: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'taskFilterPlusePoint').getText();
            },
            taskFilterResetBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'taskFilterResetBtn').click();
            },
            taskTypeFilterUM: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'taskTypeDiagnosticsChkbox').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'taskTypeUMChkbox').click();
            },
            taskTypeFilterMaintenance: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'taskTypeUMChkbox').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'taskTypeMaintenanceChkbox').click();
            },
            taskCompleteIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'taskCompleteIcon').click();
            },
            completeTaskInWorkPlan: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'taskActualDuration').click();
                browser.driver.sleep(2000);
                cem.findElement(currentPage, 'taskActualDurationNotes').sendKeys('dPOD_Testing');
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'taskActualDurationDoneBtn').click();
            },

            taskActualDuration: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'taskActualDuration').isPresent();
            },
            workPlanTaskCompleted: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'workPlanTaskCompleted').isPresent();
            },
            turbineSortLastvisit: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                cem.findElement(currentPage, 'turbineSortDisplayIcon').click();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'turbineSortLatVisit').click();
            },
            waitForturbineFirstselection: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return TestHelper.isElementPresent(currentPage, 'turbineFirstselection');
            },
            turbineFirstselection: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage, 'turbineFirstselection').click();
            },
            turbineUpdatedDate: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'turbineUpdatedDate').getText();
            },
            turbineTaskTitle: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'turbineTaskTitle').getText();
            },
            turbineResolutionNotes: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'turbineResolutionNotes').getText();
            },
            turbineTaskCompletionInPlan: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                cem.findElement(currentPage, 'turbineFirstselectionInPlan').click();
                browser.driver.sleep(5000);
                cem.findElement(currentPage, 'executionTabSelect').click();
                browser.driver.sleep(5000);
                cem.findElement(currentPage, 'executionTabSelectCheckBox').click();
                browser.driver.sleep(5000);
                cem.findElement(currentPage, 'executionTabSaveBtn').click();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, 'executionTabSaveConfBtn').click();
            },
            noDataforCurrentDate: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'noDataforCurrentDate').getText();
            },
            EditReportSavePromptYesBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'EditReportSavePromptYesBtn').click();
            },
            techReportTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage, 'techReportTab').click();
            },

            validatePM: function () {
                browser.driver.sleep(8000);
                TestHelper.isElementPresent(currentPage, 'leftNav');
                browser.sleep(5000);
                return cem.findElement(currentPage, 'leftNav').click();
            },

            validateTaskPage:function(){
                browser.driver.sleep(8000);
                TestHelper.isElementPresent(currentPage, 'taskMangmntTab');
                browser.sleep(5000);
                return cem.findElement(currentPage, 'taskMangmntTab').click()
            },

            validateDpod:function () {
                browser.driver.sleep(5000);
                TestHelper.isElementPresent(currentPage, 'leftNavDPOD');
                return cem.findElement(currentPage, 'leftNavDPOD').click();
            },

            addPersonnel: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'addPersonnel').click();
                return cem.findElement(currentPage, 'addPersonnel').click();
            },

            addEmailId: function () {
                browser.driver.sleep(5000);
                text = "yatharth" + Math.random() + ".trivedi@ge.com";
                return cem.findElement(currentPage, 'addEmail').sendKeys(text + protractor.Key.TAB);
            },

            addExcitingEmail: function () {
                browser.driver.sleep(20000);
                return cem.findElement(currentPage,'addExcitingEmail').sendKeys(text + protractor.Key.TAB);
            },

            addSSO: function (userId) {
                browser.driver.sleep(5000);
                console.log(userId);
                cem.findElement(currentPage, "addSSO").clear();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, "addSSO").sendKeys(userId + protractor.Key.TAB);
            },

            addFName: function (firstName) {
                browser.driver.sleep(3000);
                console.log(firstName);
                cem.findElement(currentPage, "addFName").clear();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage, "addFName").sendKeys(firstName + protractor.Key.TAB);
            },

            addLName: function (lastName) {
                browser.driver.sleep(3000);
                console.log(lastName);
                cem.findElement(currentPage, "addLName").clear();
                return cem.findElement(currentPage, "addLName").sendKeys(lastName + protractor.Key.TAB);
            },

            addNName: function (nickName) {
                browser.driver.sleep(3000);
                console.log(nickName);
                cem.findElement(currentPage, "addNName").clear();
                return cem.findElement(currentPage, "addNName").sendKeys(nickName);
            },

            addMNumber: function (mobileNumber) {
                browser.driver.sleep(3000);
                console.log(mobileNumber);
                cem.findElement(currentPage, "addMNumber").clear();
                return cem.findElement(currentPage, "addMNumber").sendKeys(mobileNumber);
            },

            addRNumber: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, "addMNumber").clear();
                mNumber = "7939" + Math.round(Math.random() * 1000000);
                console.log("Mobile Number is: " + mNumber);
                return cem.findElement(currentPage, 'addMNumber').sendKeys(mNumber + protractor.Key.TAB);
            },

            addONumber: function (officeNumber) {
                browser.driver.sleep(3000);
                console.log(officeNumber);
                cem.findElement(currentPage, "addONumber").clear();
                return cem.findElement(currentPage, "addONumber").sendKeys(officeNumber);
            },

            addJobTitle: function (role) {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, "addJobTitle").click();
                console.log(role);
                return element(by.xpath('//*[@id="role"]//*[text()="' + role + '"]')).click();
            },

            addSite: function (site) {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, "addSite").click();
                console.log(site);
                element(by.xpath('//*[@class="acol"]//span[contains(@class,"ng-binding")][contains(text(),"' + site + '")]')).click();
                return cem.findElement(currentPage, "addSite").click();
            },

            addAllSite: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, "addSite").click();
                cem.findElement(currentPage, "selectAll").click();
                // element(by.xpath('//*[@class="line ng-scope"]//button[contains(text(),"Select All")]')).click();
                return cem.findElement(currentPage, "addSite").click();
            },

            clickRequestAccess: function (callback) {
                var message = "Request access email sent successfully.";
                for (var i = 0; i < 5; i++) {
                    browser.sleep(5000);
                    cem.findElement(currentPage, 'requestAccess').click();
                    browser.sleep(3000);
                    cem.findElement(currentPage, 'successMessage').getText().then(function (value) {
                        // assert.equal(message, value);
                    });
                }
                callback();
            },
            
            clickRequestAccessOnce: function (callback) {
            	cem.findElement(currentPage, 'requestAccess').click();
                callback();
            },

            validateAssignSite: function () {
                browser.driver.sleep(3000);
                console.log(saveSite);
                cem.findElement(currentPage,'addSite').click();
               return cem.findElement(currentPage,'validateAssignSite').getText().then(function (value) {
                    console.log(value.trim());
                    assert.equal(value.trim(), saveSite)
                });
            },

            saveSiteName: function () {
                browser.driver.sleep(5000);
                return element.all(by.xpath("(//*[@class='layout__item u-1/1'][1]//div/span)[1]")).getText().then(function (siteName) {
                    saveSite = siteName.toString();
                    console.log(saveSite);
                });
            },

            clickCancel: function () {
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'clickCancel').click();
            },

            clickFirstRow: function () {
                browser.sleep(8000);
                return cem.findElement(currentPage, 'clickFirstRow').click();
            },

            storeFirstNameLForm: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'storeFirstNameLForm').isPresent();
                return cem.findElement(currentPage, 'storeFirstNameGetText').getText().then(function (firstName) {
                    lFirstName = firstName;
                    console.log("First Name is : " + lFirstName);
                });
            },

            storeLastNameLForm: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'storeLastNameLForm').isPresent();
                return cem.findElement(currentPage, 'storeLastNameGetText').getText().then(function (lastName) {
                    lLastName = lastName;
                    console.log("Last name is : " + lLastName);
                    lFullName = lFirstName + " " + lLastName;
                    console.log("Full Name is :" + lFullName);
                });
            },

            storeRoleLForm: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'storeRoleLForm').isPresent();
                return cem.findElement(currentPage, 'storeRoleLFormGetText').getText().then(function (role) {
                    lJobTitle = role;
                    console.log("Job title is : " + lJobTitle);
                });
            },

            storeMobileLForm: function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'storeMobileLForm').isPresent();
                return cem.findElement(currentPage, 'storeMobileLFormGetNumber').getText().then(function (mNumber) {
                    lMobileNumber = mNumber;
                    console.log("Mobile number is : " + lMobileNumber);
                });
            },

            validateFullName: function () {
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'validateFullName').getText().then(function (fullName) {
                    var sFullName = fullName;
                    console.log("Full name from Left nav. : " + sFullName);
                    return assert.equal(lFullName, sFullName);
                });
            },

            validateRole: function () {
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'validateRole').getText().then(function (jobtitle) {
                    var sJobTitle = jobtitle;
                    console.log("Jib Title from Left nav. : " + sJobTitle);
                    return assert.equal(lJobTitle, sJobTitle);
                });
            },

            validateMobileNumber: function () {
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'validateMobileNumber').getText().then(function (mobileNumber) {
                    var sMNumber = mobileNumber;
                    console.log("Mobile Number from Left nav. : " + sMNumber);
                    return assert.equal(lMobileNumber, sMNumber);
                });
            },

            logOut: function () {
                browser.driver.sleep(3000);
                return element(by.css('a[title="Log Out"]')).click();
            },

            validateEditIcon: function () {
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'validateEditIcon').isPresent();
            },

            validateEditIconNP: function () {
                browser.driver.sleep(3000);
                return expect(element(by.xpath("//*[@class='search searchList pt']/li[1]/p//i[1]")).isPresent()).to.eventually.be.equals(false);
            },

            validateDeleteIconNP:function () {
                browser.driver.sleep(3000);
                return expect(element(by.xpath("//*[@class='search searchList pt']/li[1]/p//i[2]")).isPresent()).to.eventually.be.equals(false);
            },

            validateEditIconRNP: function () {//*[@ui-view='personDetailView']
                browser.driver.sleep(3000);
                return expect(element(by.xpath("//*[@class='layout__item u-1/2 ng-scope']/span")).isPresent()).to.eventually.be.equals(false);
            },

            clickEditIcon: function () {
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'validateEditIcon').click();
            },

            clickDeleteIcon: function () {
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'clickDeleteIcon').click();
            },

            emailDisable: function () {
                browser.sleep(5000);
                return expect(cem.findElement(currentPage, 'emailDisable').getAttribute('disabled')).to.eventually.be.equals('true');
            },

            userIdDisable: function () {
                browser.sleep(5000);
                return expect(cem.findElement(currentPage, 'userIdDisable').getAttribute('disabled')).to.eventually.be.equals('true');
            },

            validateUserId:function () {
                var disabledSite= 'Rei Dos Ventos';
                browser.sleep(5000);
                return element(by.css('#userid')).getAttribute('disabled').then(function (value) {
                  console.log("User Id value is :" +value);
                  if(value==='true') {
                      browser.sleep(3000);
                     console.log("User is Present");
                      browser.sleep(3000);
                      cem.findElement(currentPage, "addMNumber").clear();
                      mNumber = "7939" + Math.round(Math.random() * 1000000);
                      console.log("Mobile Number is: " + mNumber);
                      cem.findElement(currentPage, 'addMNumber').sendKeys(mNumber + protractor.Key.TAB);
                      element.all(by.xpath("//*[@class='displaySites ng-binding']")).getText().then(function (displaySite) {
                          console.log("Display sites are : " +displaySite.toString().toLowerCase());
                          if(displaySite.toString().toLowerCase().includes(disabledSite.toLowerCase())){
                             cem.findElement(currentPage, 'clkSave').click();
                             return  console.log("Site is Present");
                          }else{
                              cem.findElement(currentPage, "addSite").click();
                              browser.sleep(3000);
                              element(by.xpath('//*[@class="acol"]//span[contains(@class,"ng-binding")][contains(text(),"Rei Dos Ventos")]')).click();
                              browser.sleep(3000);
                              return cem.findElement(currentPage, 'clkSave').click();
                          }
                     });
                  }else{
                      browser.sleep(2000);
                      cem.findElement(currentPage, "addSSO").sendKeys('Test123' + protractor.Key.TAB);
                      browser.sleep(2000);
                      cem.findElement(currentPage, "addFName").sendKeys('Unique' + protractor.Key.TAB);
                      browser.sleep(2000);
                      cem.findElement(currentPage, "addLName").sendKeys('User' + protractor.Key.TAB);
                      browser.sleep(2000);
                      cem.findElement(currentPage, "addNName").sendKeys("TYLUN"+ protractor.Key.TAB);
                      browser.sleep(2000);
                      cem.findElement(currentPage, "addInitials").clear();
                      cem.findElement(currentPage, "addInitials").sendKeys('TULYN' + protractor.Key.TAB);
                      browser.sleep(2000);
                      cem.findElement(currentPage, "addJobTitle").click();
                      var role="Site Manager";
                      element(by.xpath('//*[@id="role"]//*[text()="' + role + '"]')).click();
                      browser.sleep(2000);
                      cem.findElement(currentPage, "addSite").click();
                      var site = "Rei Dos Ventos";
                      element(by.xpath('//*[@class="acol"]//span[contains(@class,"ng-binding")][contains(text(),"' + site + '")]')).click();
                      browser.sleep(2000);
                     return cem.findElement(currentPage, 'clkSave').click();
                  }
              });
            },

            rightEditIcon: function () {
                browser.driver.sleep(20000);
                return cem.findElement(currentPage, 'rightEditIcon').isPresent();
            },

            rightClkEditIcon: function () {
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'rightEditIcon').click();
            },

            rightClkDeleteIcon:function () {
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'rightDeleteIcon').click();
            },

            validateSortFName: function (callback) {
                browser.sleep(3000);
                return element.all(by.xpath("//*[@class='search searchList pt']/li/p/strong")).getText().then(function (value) {
                    var val = value.toString();
                    var newVal = value.reverse(value);
                    var newVa = value.reverse(newVal.toString());
                    var newValue = newVa.toString();
                    // assert.equal(val,newValue);
                    if (val === newValue) {
                        console.log("Sorting is working as per behavior");
                        callback();
                    } else {
                        console.log("Sorting is not working as per behavior");
                        callback();
                    }
                });

            },

            clickSort: function () {
                browser.waitForAngular();
                browser.sleep(7000);
                cem.findElement(currentPage, 'clickSort').isPresent();
                return cem.findElement(currentPage, 'clickSort').click();
            },

            selectFName: function () {
                browser.sleep(3000);
                cem.findElement(currentPage, 'selectFName').isPresent();
                return cem.findElement(currentPage, 'selectFName').click();
            },

            selectSortText: function () {
                browser.sleep(3000);
                cem.findElement(currentPage, 'selectSortText').isPresent();
                return cem.findElement(currentPage, 'selectSortText').click();

            },

            validateDescOrder: function (callback) {
                browser.sleep(3000);
                element.all(by.xpath("//*[@class='search searchList pt']/li/p/strong")).getText().then(function (value) {
                    var newVal = value.reverse(value);
                    var newVal1 = newVal.reverse(newVal).toString();
                    // assert.equal(value.toString(),newVal1)
                    if (value.toString() === newVal1) {
                        console.log("Sorting is working as per behavior");
                        callback();
                    } else {
                        console.log("Sorting is not working as per behavior");
                        callback();
                    }

                });
            },

            selectLName: function () {
                browser.sleep(3000);
                cem.findElement(currentPage, 'selectLName').isPresent();
                return cem.findElement(currentPage, 'selectLName').click();
            },

            descOrderLName: function (callback) {
                browser.sleep(3000);
                element.all(by.xpath("//*[@class='search searchList pt']/li/p/strong")).getText().then(function (value) {
                    var newVal = value.reverse(value);
                    var newVal1 = newVal.reverse(newVal).toString();
                    // assert.equal(value.toString(),newVal1);
                    if (value.toString() === newVal1) {
                        console.log("Sorting is working as per behavior");
                        callback();
                    } else {
                        console.log("Sorting is not working as per behavior");
                        callback();
                    }
                });
            },

            validateSortLName: function (callback) {
                browser.sleep(3000);
                return element.all(by.xpath("//*[@class='search searchList pt']/li/p/strong")).getText().then(function (value) {
                    var val = value.toString();
                    var newVal = value.reverse(value);
                    var newVa = value.reverse(newVal.toString());
                    var newValue = newVa.toString();
                    // assert.equal(val,newValue);
                    if (val === newValue) {
                        console.log("Sorting is working as per behavior");
                        callback();
                    } else {
                        console.log("Sorting is not working as per behavior");
                        callback();
                    }
                });
            },

            selectJTitle: function () {
                browser.sleep(3000);
                cem.findElement(currentPage, 'selectJTitle').isPresent();
                return cem.findElement(currentPage, 'selectJTitle').click();
            },

            validateSortJTitle: function (callback) {
                browser.sleep(3000);
                return element.all(by.xpath("//*[@class='search searchList pt']/li/p[2]/span")).getText().then(function (value) {
                    var val = value.toString();
                    var newVal = value.reverse(value);
                    var newVa = value.reverse(newVal.toString());
                    var newValue = newVa.toString();
                    // assert.equal(val,newValue);
                    if (val === newValue) {
                        console.log("Sorting is working as per behavior");
                        callback();
                    } else {
                        console.log("Sorting is not working as per behavior");
                        callback();
                    }
                });
            },

            descJTitle: function (callback) {
                browser.sleep(3000);
                element.all(by.xpath("//*[@class='search searchList pt']/li/p[2]/span")).getText().then(function (value) {
                    var newVal = value.reverse(value);
                    var newVal1 = newVal.reverse(newVal).toString();
                    // assert.equal(value.toString(),newVal1);
                    if (value.toString() === newVal1) {
                        console.log("Sorting is working as per behavior");
                        callback();
                    } else {
                        console.log("Sorting is not working as per behavior");
                        callback();
                    }

                });
            },

            removeSort: function () {
                browser.sleep(3000);
                cem.findElement(currentPage, 'removeSort').isPresent();
                return cem.findElement(currentPage, 'removeSort').click();
            },

            verifyColumns: function (name) {
                return element(by.xpath('//*[text()="' + name + '"]')).isDisplayed();
            },

            verifyPopUp: function(name){
                return element(by.xpath('//*[@id="unsaveMsgDialog"]/div//*[text()="'+name+'"]')).isDisplayed();
            },

            textPagiValid: function () {
                browser.sleep(3000);
                return expect(taskMgmtPage.verifyColumns("Record per page: ")).to.eventually.be.eql(true);
                return expect(taskMgmtPage.verifyColumns("« Prev")).to.eventually.be.eql(true);
                return expect(taskMgmtPage.verifyColumns("Next »")).to.eventually.be.eql(true);
                return expect(taskMgmtPage.verifyColumns("1")).to.eventually.be.eql(true);
            },

            validateRecords: function (records) {
                browser.sleep(3000);
                return element(by.xpath('//*[@id="mySelect"]/option[text()="' + records + '"]')).click();
                return cem.findElement(currentPage, 'validateRecords').click();
            },

            countRecords: function () {
                browser.sleep(3000);
                return  cem.findElement(currentPage,'nextButton').isEnabled().then(function (value) {
                    console.log(value);
                    if (value === true) {
                        element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).count().then(function (Count) {
                            var elm = element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).last();
                            browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                                var until = protractor.ExpectedConditions;
                                browser.sleep(5000);
                                browser.executeScript('window.scrollTo(0,1000);').then(function () {
                                    console.log('Page Scroll Down');
                                    // return console.log("First Count is: " + Count);
                                    var elm = element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).first();
                                    browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                                        var until = protractor.ExpectedConditions;
                                        browser.sleep(5000);
                                        browser.executeScript('window.scrollTo(10000,0);').then(function () {
                                            console.log('Page Scroll Up');
                                            return console.log("First Count is: " + Count);

                                        });
                                    });
                                });
                            });
                        });
                    } else {
                        cem.findElement(currentPage,'nextButton').click();
                        expect(taskMgmtPage.verifyColumns("2")).to.eventually.be.eql(true);
                        element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).count().then(function (count) {
                            console.log("Record which is present is either 10 or less then 10");
                            return console.log("Total count is: " + (count + Count));
                        });
                    }
                });
            },

            validateNoDataMsg: function () {
                browser.sleep(3000);
                return cem.findElement(currentPage, 'validateNoDataMsg1').isPresent().then(function (flag1) {
                    return cem.findElement(currentPage, 'validateNoDataMsg2').isPresent().then(function (flag2) {
                        console.log("Flag is:" + flag1);
                        console.log("Flag is:" + flag2);
                    });
                });
            },

            validateMsg: function (callback) {
                browser.sleep(3000);
                if (flag1 === true && flag2 === true) {
                    console.log("Data is not present ");
                    callback();
                } else {
                    console.log("Data is present");
                    callback();
                }
            },

            validateAddPer: function () {
                browser.sleep(8000);
                return cem.findElement(currentPage, 'validateAddPer').isPresent();

            },

            validateButton: function () {
                browser.sleep(7000);
                expect(cem.findElement(currentPage, 'validateButton1').getAttribute('disabled')).to.eventually.eql('true');
                return expect(cem.findElement(currentPage, 'validateButton2').getAttribute('disabled')).to.eventually.eql('true');
            },

            validateCancelAndSaveButton: function () {
                browser.sleep(7000);
                expect(cem.findElement(currentPage, 'validateButton2').getAttribute('disabled')).to.eventually.eql('true');
                return cem.findElement(currentPage, 'validateButton1').click();
            },

            clkSave: function () {
                browser.sleep(7000);
                return cem.findElement(currentPage, 'clkSave').click();
            },

            successMessage: function () {
                browser.waitForAngular();
                var message='Person has been successfully added';
             !browser.isElementPresent(by.css('pxh-spinner pxh-spinner--large ng-scope'));
                    cem.findElement(currentPage, 'successMessage').isPresent();
                    return cem.findElement(currentPage, 'successMessage').getText().then(function (value) {
                        console.log("Message is :" + value);
                        assert.equal(message, value);
                     });
                // });
                },

            updateSuccessMsg: function () {
                browser.sleep(4000);
                var message = "Personnel details updated successfully.!";
                return cem.findElement(currentPage, 'successMessage').getText().then(function (value) {
                    // console.log("Message is :" + value);
                    // return assert.equal(message, value);
                });
            },

            requestAccess: function () {
                browser.sleep(3000);
                return cem.findElement(currentPage, 'requestAccess').isPresent();
            },

            requestAccessNP:function () {
                browser.sleep(3000);
                return TestHelper.isElementNotPresent(currentPage, 'requestAccess');
            },

            addEmail: function (email) {
                browser.driver.sleep(3000);
                console.log(email);
                return cem.findElement(currentPage, 'addEmail').sendKeys(email + protractor.Key.TAB);
            },

            errorMessage: function () {
                cem.findElement(currentPage, 'errorMessage').isPresent();
                return cem.findElement(currentPage, 'errorMessage').getText().then(function (value) {
                    console.log("Message is :" + value);
                });
            },

            errorFMessage: function () {
                cem.findElement(currentPage, 'errorFMessage').isPresent();
                return cem.findElement(currentPage, 'errorFMessage').getText().then(function (value) {
                        console.log("Message is :" + value);
                });
            },

            errorMessageValidationFN: function () {
                cem.findElement(currentPage, 'errorMessageFN').isPresent();
                return cem.findElement(currentPage, 'errorMessageFN').getText().then(function (value) {
                        console.log("Error Message for First Name field is :" + value);
                        assert.equal(value, "Enter valid first name");
                });
            },

            errorMessageNotPresentValidationFN: function () {
                return expect(element(by.xpath("(//*[@class='displayErrorMsg ng-scope'])[1]")).isPresent()).to.eventually.be.equals(false);
            },

            errorMessageNotPresentValidationLN: function () {
                return expect(element(by.xpath("(//*[@class='displayErrorMsg ng-scope'])[2]")).isPresent()).to.eventually.be.equals(false);
            },

            errorMessageValidationLN: function () {
                cem.findElement(currentPage, 'errorMessageLN').isPresent();
                return cem.findElement(currentPage, 'errorMessageLN').getText().then(function (value) {
                        console.log("Error Message for Last Name field is :" + value);
                        assert.equal(value, "Enter valid last name");
                });
            },

            errorLMessage: function () {
                cem.findElement(currentPage,'errorLMessage').isPresent();
                return cem.findElement(currentPage,'errorLMessage').getText().then(function (value) {
                    console.log("Message is :" + value);
                });
            },

            clearEField: function () {
                browser.sleep(5000);
                return cem.findElement(currentPage, 'addEmail').click().clear();
            },

            clearFNameField: function () {
                browser.sleep(3000);
                return cem.findElement(currentPage,'clearFNameField').click().clear();
            },

            clearLNameField: function () {
                browser.sleep(3000);
                return cem.findElement(currentPage,'clearLNameField').click().clear();
            },

            validateEMand: function () {
                browser.sleep(3000);
                return cem.findElement(currentPage, 'validateEMand').isPresent();
            },

            validateFMand: function () {
                browser.sleep(3000);
                return cem.findElement(currentPage, 'validateFMand').isPresent();
            },

            validateLMand: function () {
                browser.sleep(3000);
                return cem.findElement(currentPage,'validateLMand').isPresent();
            },

            addContractor: function () {
                browser.sleep(3000);
                var elm = element(by.xpath("//*[@id='newcrewPopOver']"));
                return elm.click();
            },

            selectLastContractor: function () {
                var ele = element.all(by.xpath("//*[@class='unassignedCrewTop u-mr-']//div[contains(@ng-show,'unACrews.userInitials')]//div[contains(@class,'contractor-person')]")).last();
                return ele.click();
            },

            dropToFirstCrew:function () {
                browser.sleep(3000);
                var ele = element.all(by.xpath("//*[@class='unassignedCrewTop u-mr-']//div[contains(@ng-show,'unACrews.userInitials')]//div[contains(@class,'contractor-person')]")).last();
                var target = element.all(by.xpath("//*[@id='displayCrewNamePopup']")).first();
                // return browser.driver.actions().dragAndDrop(ele,target).mouseUp().perform();
                browser.sleep(3000);
                return browser.actions().dragAndDrop(ele, target).mouseUp().perform();
            },

            selectEdit: function () {
                var ele = element(by.xpath("//*[@class='crewActionPopup crewPopWidth ng-scope']//li[contains(@title,'Edit tech details')]"));
                return ele.click();
            },

            selectDelete: function () {
                var ele = element(by.xpath("//*[@class='crewActionPopup crewPopWidth ng-scope']//li[contains(@title,'Delete')]"));
                return ele.click();
            },

            ssoDisable: function () {
                return expect(element(by.xpath("//*[@class='layout padding-none'][2]//*[@class='box_33'][1]//input")).getAttribute('disabled')).to.eventually.eql('true');
            },

            dragDrop: function () {
                browser.sleep(3000);
                var ele = element.all(by.xpath("//*[@class='unassignedCrewTop u-mr-']//div[contains(@ng-show,'unACrews.userInitials')]//div[contains(@class,'contractor-person')]")).last();
                var target = element(by.xpath(" //*[@id='crewPopOver']//span//center"));
                // return browser.driver.actions().dragAndDrop(ele,target).mouseUp().perform();
                browser.sleep(3000);
                return browser.actions().dragAndDrop(ele, target).mouseUp().perform();
            },

            validateCrewName: function () {
                var newCrewName;
                console.log("Crew name before delete is :" + CrewName);
                browser.sleep(3000);
                var ele = element.all(by.xpath("//*[@ng-model='crewDetails']//*[@class='disShortName 0']")).last();
                return ele.getText().then(function (newCrewName) {
                    console.log("New Crew  is :" + newCrewName);
                    assert.notEqual(CrewName, newCrewName)
                });

            },

            validateCrewCountWorkPlanSection: function () {
                browser.sleep(3000);
                return element.all(by.xpath("//*[@id='crewColumnId']/div[1]/span")).count().then(function (Count) {
                    console.log("Count of crews: "+ Count);
                    workplanCrewCount = Count;
                });

            },

            validateUpdatedCrewCountWorkPlanSection: function () {
                browser.sleep(3000);
                return element.all(by.xpath("//*[@id='crewColumnId']/div[1]/span")).count().then(function (Count) {
                    console.log("Updated count of crews: "+ Count);
                    assert.notEqual(workplanCrewCount, Count);
                });

            },

            performOneClick: function () {
                browser.sleep(3000);
                var ele = element.all(by.xpath("//*[@ng-model='crewDetails']")).last();
                return ele.click()
            },

            saveCrewName: function () {
                browser.sleep(3000);
                var ele = element.all(by.xpath("//*[@ng-model='crewDetails']//*[@class='disShortName 0']")).last();
                return ele.getText().then(function (crewName) {
                    CrewName = crewName;
                    console.log("Crew name before delete is :" + crewName);
                });
            },

            lastCrew: function () {
                browser.sleep(3000);
                var ele = element.all(by.xpath("//*[@ng-model='crewDetails']")).last();
                ele.click();
                browser.sleep(3000);
                return ele.click()
            },

            workStatus: function () {

                return element(by.xpath("//*[@class='layout padding-none']//input[@class='Oncall_WorkStatus ng-pristine ng-untouched ng-valid ng-not-empty']")).isSelected();
            },

            addFiName: function (firstName) {
                browser.driver.sleep(3000);
                console.log(firstName);
                element(by.xpath("//*[@id='firstname']")).clear();
                return element(by.xpath("//*[@id='firstname']")).sendKeys(firstName + protractor.Key.TAB);
            },

            addLaName: function (lastName) {
                browser.driver.sleep(3000);
                console.log(lastName);
                element(by.xpath("//*[@id='lastname']")).clear();
                return element(by.xpath("//*[@id='lastname']")).sendKeys(lastName + protractor.Key.TAB);
            },
            addNiName: function (nickName) {
                browser.driver.sleep(3000);
                console.log(nickName);
                element(by.xpath("//*[@id='nickname']")).clear();
                return element(by.xpath("//*[@id='nickname']")).sendKeys(nickName + protractor.Key.TAB);
            },
            addInitials: function (initials) {
                browser.driver.sleep(3000);
                console.log(initials);
                element(by.xpath("//*[@id='initials']")).clear();
                return element(by.xpath("//*[@id='initials']")).sendKeys(initials + protractor.Key.TAB);
            },
            disRole: function () {
                return element(by.xpath("//select[@class='ng-pristine ng-untouched ng-valid ng-not-empty disableEditor']")).isPresent();
            },

            addEma: function (email) {
                browser.driver.sleep(3000);
                console.log(email);
                element(by.xpath("//*[@id='email']")).clear();
                return element(by.xpath("//*[@id='email']")).sendKeys(email + protractor.Key.TAB);
            },
            addPhone: function (phone) {
                browser.driver.sleep(3000);
                console.log(phone);
                element(by.xpath("//*[@id='phone']")).clear();
                return element(by.xpath("//*[@id='phone']")).sendKeys(phone + protractor.Key.TAB);
            },

            clickSave: function () {
                return element(by.xpath("//*[@class='editTechSaveSection']/button")).click();
            },

            onCall: function () {
                browser.sleep(3000);
                element(by.xpath("((//*[@class='layout padding-none'])[1]//input)[1]")).click();
                browser.sleep(3000);
                element(by.xpath("((//*[@class='layout padding-none'])[1]//input)[2]")).click();
                browser.sleep(3000);
                return element(by.xpath("((//*[@class='layout padding-none'])[1]//input)[2]")).isSelected();
            },

            onCallSymbol: function () {
                browser.sleep(5000);
                var ele = element.all(by.xpath("//*[@ng-model='crewDetails']//*[@class='fa fa-volume-control-phone user-call-status-icon ng-scope']")).last();
                return ele.isPresent();
            },

            errorMessageDpod: function () {
                element(by.xpath("//*[@class='error ng-binding ng-scope']")).isPresent();
                return element(by.xpath("//*[@class='error ng-binding ng-scope']")).getText().then(function (value) {
                    console.log("Message is :" + value);
                });
            },

            searchPresent: function () {
                browser.sleep(3000);
                return cem.findElement(currentPage,'searchPresent').isPresent();
                // return element(by.xpath("//*[@class='search_box']")).isPresent();
            },

            enterFName: function (firstName) {
                browser.driver.sleep(3000);
                console.log(firstName);
                cem.findElement(currentPage,'enterFName').clear();
                cem.findElement(currentPage,'enterFName').sendKeys(firstName + protractor.Key.ENTER);
                return element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).count().then(function (Count) {
                    console.log(Count);
                });
            },

            enterLName: function (lastName) {
                browser.driver.sleep(3000);
                console.log(lastName);
                cem.findElement(currentPage,'enterLName').clear();
                cem.findElement(currentPage,'enterLName').sendKeys(lastName + protractor.Key.ENTER);
                return element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).count().then(function (Count) {
                    console.log(Count);
                });
            },
            fetchCrewNameCrewsSection: function () {
                return element.all(by.className("crewNames ng-binding ng-scope")).count().then(function (crewCount) {
                    console.log("Crew Count is :" +crewCount);
                    browser.sleep(5000);
                    var ele = element(by.xpath("//*[@id='crew_section_widget']/div["+crewCount+"]/div/span"));
                    return ele.getText().then(function (crewName) {
                        console.log("Crew name with new personnel is :" + crewName);
                        crewsCrewName = crewName;
                    });
                });
            },

            validatePersonnelDeletion: function () {
                return element.all(by.className("crewNames ng-binding ng-scope")).count().then(function (crewCount) {
                    console.log("Crew Count is :" +crewCount);
                    browser.sleep(5000);
                    var ele = element(by.xpath("//*[@id='crew_section_widget']/div["+crewCount+"]/div/span"));
                    return ele.getText().then(function (crewName) {
                        console.log("New Crew name is :" + crewName);
                        assert.notEqual(crewsCrewName, crewName);
                    });
                });
            },

            validateFName: function (firstName) {
                return element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li/li/p/strong")).getText().then(function (value) {
                    var change = value.lowercase;
                    var lower4 = firstName.lowercase;
                    return Array.prototype.contains = function (lower4) {
                        if (isNotNull(lower4), "Move to check ") {
                            for (lower4 in change || lower4 in change) {
                                if (lower4 === change || lower4 === change)
                                    return true;
                            }
                            return false;
                        }
                    }
                });
            },

            validateLName: function (lastName) {
                return element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li/li/p/strong")).getText().then(function (value) {
                    var change = value.lowercase;
                    var lower4 = lastName.lowercase;
                    return Array.prototype.contains = function (lower4) {
                        if (isNotNull(lower4), "Move to check ") {
                            for (lower4 in change || lower4 in change) {
                                if (lower4 === change || lower4 === change)
                                    return true;
                            }
                            return false;
                        }
                    }
                });
            },

            validatePNumber: function (phoneNumber) {
                return element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li/p/strong")).getText().then(function (value) {
                    var change = value
                    var lower4 = phoneNumber;
                    return Array.prototype.contains = function (lower4) {
                        if (isNotNull(lower4), "Move to check ") {
                            for (lower4 in change || lower4 in change) {
                                if (lower4 === change || lower4 === change)
                                    return true;
                            }
                            return false;
                        }
                    }
                });
            },

            enterPNumber: function (phoneNumber) {
                browser.driver.sleep(3000);
                console.log(phoneNumber);
                cem.findElement(currentPage,'enterPNumber').clear();
                cem.findElement(currentPage,'enterPNumber').sendKeys(phoneNumber + protractor.Key.ENTER);
                return element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).count().then(function (Count) {
                    console.log(Count);
                });
            },

            addSNumber: function () {
                browser.driver.sleep(7000);
                console.log(mNumber);
                cem.findElement(currentPage,"addSNumber").clear();
                cem.findElement(currentPage,"addSNumber").sendKeys(mNumber + protractor.Key.ENTER);
                return element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).count().then(function (Count) {
                    console.log(Count);
                });
            },

            addExistingEmailId:function () {
                browser.driver.sleep(5000);
                console.log(personnelName);
                cem.findElement(currentPage,"addSNumber").clear();
                return cem.findElement(currentPage,"addSNumber").sendKeys(personnelName + protractor.Key.TAB);
            },

            searchExistingPersonnel:function (personnelName) {
                browser.driver.sleep(5000);
                console.log(personnelName);
                cem.findElement(currentPage,"addSNumber").clear();
                return cem.findElement(currentPage,"addSNumber").sendKeys(personnelName + protractor.Key.TAB);
            },

            addSEmail:function () {
                browser.driver.sleep(5000);
                console.log(sEmail);
                cem.findElement(currentPage,"addEmail").clear();
                return cem.findElement(currentPage,"addEmail").sendKeys(sEmail + protractor.Key.TAB);
            },

            validateWName: function (wrongName) {
                browser.driver.sleep(3000);
                console.log(wrongName);
                cem.findElement(currentPage,'validateWName').clear();
                return  cem.findElement(currentPage,'validateWName').sendKeys(wrongName + protractor.Key.ENTER);
            },

            validateWNumber: function (wrongNumber) {
                browser.driver.sleep(3000);
                console.log(wrongNumber);
                cem.findElement(currentPage,'validateWNumber').clear();
                return cem.findElement(currentPage,'validateWNumber').sendKeys(wrongNumber + protractor.Key.ENTER);
            },

            validateMessage: function (message) {
                return cem.findElement(currentPage, 'validateNoDataMsg1').isPresent().then(function (flag1) {
                    console.log(flag1);
                    if (flag1 === true) {
                        return cem.findElement(currentPage, 'validateMessage').getText().then(function (value) {
                            assert.equal(message, value);
                        });
                    } else {
                        console.log("Name is Not Present")
                    }
                });
            },

            selectSite: function (site) {
                browser.driver.navigate().refresh();
                browser.waitForAngular();
                browser.driver.sleep(9000);
                saveSiteName = site;
                cem.findElement(currentPage, 'siteGroupDropdwn').click();
                browser.driver.sleep(5000);
                return element(by.xpath('//*[@class="selected list-bare level style-scope px-context-browser"]//li//span[text()="' + site + '"]')).click();
            },

            selectSite1: function (site) {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                cem.findElement(currentPage, 'siteGroupDropdwn').click();
                browser.driver.sleep(5000);
                return element(by.xpath('//*[@class="selected list-bare level style-scope px-context-browser"]//li//span[text()="' + site + '"]')).click();
            },

            clickCsv: function () {
                return cem.findElement(currentPage,'clickCsv').click();
                // return element(by.xpath("//*[@class='style-scope px-icon x-scope iron-icon-1']")).click();
            },

            validateWidget: function () {
                browser.sleep(5000);
                return cem.findElement(currentPage, 'validateWidget').isPresent();
            },

            numberOfTurbine: function () {
                browser.sleep(2000);
                return cem.findElement(currentPage, 'numberOfTurbine').getText().then(function (nTurbine) {
                    console.log("Status of turbine is :" + nTurbine);
                    activeTurbine = nTurbine.toString().split(" ").slice(0, 1).join(" ").replace(/,/, "");
                    console.log("Active Turbine :" + activeTurbine);
                    totalTurbine = nTurbine.toString().split(" ").slice(2, 3).join(" ").replace(/,/, "");
                    return console.log("Total Turbine :" + totalTurbine);
                });
            },

            countFaultedStatus: function (){
            browser.sleep(2000);
                return cem.findElement(currentPage, 'faulted').getText().then(function (faulted) {
                    console.log("faulted of turbine is :" + faulted);
                    var value = faulted.toString().split(" ").join(" ").replace(/Faulted/g, "");
                    var init = value.indexOf('(');
                    var fin = value.indexOf(')');
                    allFaultedCount = Number((value.substr(init + 1, fin - init - 1)));
                    console.log("Number of total faulted turbine is:" + allFaultedCount);
                });
            },

            getPillsCount: function () {
                return element(by.xpath('(//*[@id="turbine_widget"]/div[2]//p)[1]//span[contains(@class,"badge badge-2  style-scope plan-turbine-status-widget")]')).count();
            },


            validateFaultedMsg: function () {
                TestHelper.isElementPresent(currentPage, 'pills').then(function (hasPill) {
                    if (hasPill) {
                        currentPage.getPillsCount().then(function (cnt) {
                            for (var i = 0; i < cnt; i++) {
                                var elm = element.all(by.xpath('(//*[@id="turbine_widget"]/div[2]//p)[1]//span[contains(@class,"badge badge-2  style-scope plan-turbine-status-widget")])'));
                                browser.actions().mouseMove(elm).getText().then(function (value) {
                                    console.log("Text is Value" + value);
                                })
                                // TestHelper.elementToBeClickable(currentPage, 'removePillButton');
                            }
                        }).then(function () {
                            callback();
                        });
                    } else {
                        callback();
                    }
                });
            },

            // },

            countStoppedStatus: function () {
                browser.sleep(2000);
                return cem.findElement(currentPage, 'stopped').getText().then(function (stopped) {
                    console.log("Stopped of turbine is :" + stopped);
                    var value = stopped.toString().split(" ").join(" ").replace(/Stopped/g, "");
                    var init = value.indexOf('(');
                    var fin = value.indexOf(')');
                    allStoppedCount = Number((value.substr(init + 1, fin - init - 1)));
                    console.log("Number of total stopped turbine is:" + allStoppedCount);
                });
            },

            countNetcomStatus: function () {
                browser.sleep(2000);
                return cem.findElement(currentPage, 'netcom').getText().then(function (netcom) {
                    console.log("Netcom of turbine is :" + netcom);
                    var value = netcom.toString().split(" ").join(" ").replace(/Netcom/g, "");
                    var init = value.indexOf('(');
                    var fin = value.indexOf(')');
                    allNetcomCount = Number((value.substr(init + 1, fin - init - 1)));
                    return console.log("Number of total netcom turbine is:" + allNetcomCount);
                });
            },

            countImpactedStatus: function () {
                browser.sleep(2000);
                return cem.findElement(currentPage, 'impacted').getText().then(function (impacted) {
                    console.log("Impacted of turbine is :" + impacted);
                    var value = impacted.toString().split(" ").join(" ").replace(/Impacted/g, "");
                    var init = value.indexOf('(');
                    var fin = value.indexOf(')');
                    allImpactedCount = Number((value.substr(init + 1, fin - init - 1)));
                    return console.log("Number of total impacted turbine is:" + allImpactedCount);
                });
            },

            validateCount: function (callback) {
                browser.sleep(2000);
                var totalOfflineTurbine = allFaultedCount + allStoppedCount + allNetcomCount;
                console.log("TotalOffline Turbine: " + totalOfflineTurbine);

                var validateStatus = parseInt(activeTurbine) + parseInt(totalOfflineTurbine);
                console.log("Total count: " + validateStatus);

                assert.equal(parseInt(totalTurbine), validateStatus);

                callback();
            },

            validateToolTipStopped: function (callback) {
                browser.sleep(2000);
                console.log("Stopped Turbine: " + allStoppedCount);
                if (allStoppedCount > 0) {

                    var elm = element(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-3')]"));
                    var i;
                    TestHelper.isElementPresent(elm).then(function (hasPill) {
                        console.log("Pills Validation :" + hasPill);
                        if (hasPill) {
                            element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-3')]")).count().then(function (cnt) {
                                console.log("Count is : " + cnt);
                                var count = 0;
                                for (i = 0; i < cnt; i++) {
                                    browser.sleep(2000);
                                    browser.actions().mouseMove(element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-3')]")).get(i)).click().perform().then(function () {
                                        browser.sleep(2000);
                                        (element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-3')]//ul/li")).get(count)).getText().then(function (value) {
                                            console.log("Text is Value : " + value);
                                            count++;
                                        });
                                    });
                                }
                            }).then(function () {
                                callback();
                            });
                        } else {
                            callback();

                        }

                    });
                } else {
                    console.log("Non of the turbine is present");
                    callback();
                }
            },

            validateToolTipFaulted: function (callback) {
                browser.sleep(2000);
                console.log("Faulted Turbine: " + allFaultedCount);
                if (allFaultedCount > 0) {

                    var elm = element(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-2')]"));
                    var i;
                    TestHelper.isElementPresent(elm).then(function (hasPill) {
                        console.log("Pills Validation :" + hasPill);
                        if (hasPill) {
                            element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-2')]")).count().then(function (cnt) {
                                console.log("Count is : " + cnt);
                                var count = 0;
                                for (i = 0; i < cnt; i++) {
                                    browser.sleep(2000);
                                    browser.actions().mouseMove(element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-2')]")).get(i)).click().perform().then(function () {
                                        browser.sleep(2000);
                                        (element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-2')]//ul/li")).get(count)).getText().then(function (value) {
                                            console.log("Text is Value : " + value);
                                            count++;
                                        });
                                    });
                                }
                            }).then(function () {
                                callback();
                            });
                        } else {
                            callback();

                        }

                    });
                } else {
                    console.log("Non of the turbine is present");
                    callback();
                }
            },

            validateToolTipNetcom: function (callback) {
                browser.sleep(2000);
                console.log("Netcom Turbine: " + allNetcomCount);
                if (allNetcomCount > 0) {

                    var elm = element(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-5')]"));
                    var i;
                    TestHelper.isElementPresent(elm).then(function (hasPill) {
                        console.log("Pills Validation :" + hasPill);
                        if (hasPill) {
                            element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-5')]")).count().then(function (cnt) {
                                console.log("Count is : " + cnt);
                                var count = 0;
                                for (i = 0; i < cnt; i++) {
                                    browser.sleep(2000);
                                    browser.actions().mouseMove(element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-5')]")).get(i)).click().perform().then(function () {
                                        browser.sleep(2000);
                                        (element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-5')]//ul/li")).get(count)).getText().then(function (value) {
                                            console.log("Text is Value : " + value);
                                            count++;
                                        });
                                    });
                                }
                            }).then(function () {
                                callback();
                            });
                        } else {
                            callback();

                        }

                    });
                } else {
                    console.log("Non of the turbine is present");
                    callback();
                }
            },

            validateToolTipImpacted: function (callback) {
                browser.sleep(2000);
                console.log("Impacted Turbine: " + allImpactedCount);
                if (allImpactedCount > 0) {

                    var elm = element(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-4')]"));
                    var i;
                    TestHelper.isElementPresent(elm).then(function (hasPill) {
                        console.log("Pills Validation :" + hasPill);
                        if (hasPill) {
                            element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-4')]")).count().then(function (cnt) {
                                console.log("Count is : " + cnt);
                                var count = 0;
                                for (i = 0; i < cnt; i++) {
                                    browser.sleep(2000);
                                    browser.actions().mouseMove(element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-4')]")).get(i)).click().perform().then(function () {
                                        (element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-4')]//ul/li")).get(count)).getText().then(function (value) {
                                            browser.sleep(2000);
                                            console.log("Text is Value : " + value);
                                            count++;
                                        });
                                    });
                                }
                            }).then(function () {
                                callback();
                            });
                        } else {
                            callback();

                        }

                    });
                } else {
                    console.log("Non of the turbine is present");
                    callback();
                }
            },

            validateWeaWidget: function () {
                browser.sleep(3000);
                return cem.findElement(currentPage, 'validateWeaWidget').isPresent();
            },

            validateDarkSky: function () {
                browser.sleep(3000);
                cem.findElement(currentPage, 'validateDarkSky').isPresent();
                return cem.findElement(currentPage, 'validateDarkSky').click();
            },

            childWindow: function (callback) {
                browser.sleep(2000);
                browser.getAllWindowHandles().then(function (handles) {
                    browser.driver.switchTo().window(handles[1]).then(function () {
                        browser.sleep(3000);
                        callback();
                    });
                });
            },

            urlRead: function (callback) {
                browser.sleep(5000);
                browser.getCurrentUrl().then(function (webPageUrl) {
                    currentURL = webPageUrl;
                    console.log(currentURL);
                    callback();
                });


            },

            titleRead: function (callback) {
                browser.sleep(2000);
                browser.getTitle().then(function (webPageTitle) {
                    console.log(webPageTitle);
                    callback();
                });
            },

            parentWind: function (callback) {
                browser.sleep(2000);
                browser.getAllWindowHandles().then(function (handles) {
                    browser.driver.switchTo().window(handles[1]);
                    browser.driver.close();
                    browser.driver.switchTo().window(handles[0]).then(function () {
                        callback();
                    });
                });
            },

            countApmCasesStatus: function () {
                return cem.findElement(currentPage, 'apmCases').getText().then(function (cases) {
                    console.log("Apm Cases of turbine is :" + cases);
                    var value = cases.toString().split(" ").slice(2, 3).join(" ").replace(/,/g, "");
                    console.log("New Value is : " + value);
                    var init = value.indexOf('(');
                    var fin = value.indexOf(')');
                    allApmCases = Number((value.substr(init + 1, fin - init - 1)));
                    return console.log("Number of total Apm Cases is:" + allApmCases);
                });
            },

            validateToolTipCases: function (callback) {
                console.log("APM Cases : " + allApmCases);
                if (allApmCases > 0) {

                    var elm = element(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-6')]"));
                    var i;
                    TestHelper.isElementPresent(elm).then(function (hasPill) {
                        console.log("Pills Validation :" + hasPill);
                        if (hasPill) {
                            element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-6')]")).count().then(function (cnt) {
                                console.log("Count is : " + cnt);
                                var count = 0;
                                for (i = 0; i < cnt; i++) {
                                    browser.actions().mouseMove(element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-6')]")).get(i)).click().perform().then(function () {
                                        browser.sleep(2000);
                                        (element.all(by.xpath("//*[@class='u-mb- style-scope plan-turbine-status-widget']//span[contains(@class, 'badge badge-6')]//ul//li")).get(count)).getText().then(function (value) {
                                            browser.sleep(2000);
                                            console.log("Text is Value : " + value);
                                            count++;
                                        });
                                    });
                                }
                            }).then(function () {
                                callback();
                            });
                        } else {
                            callback();

                        }

                    });
                } else {
                    console.log("Non of the turbine is present");
                    callback();
                }
            },

            validateCase: function () {
                browser.actions().mouseMove(cem.findElement(currentPage, 'case')).click().perform();
                cem.findElement(currentPage, 'validateCase').isPresent();
                browser.sleep(2000);
                return cem.findElement(currentPage, 'validateCase').click();
            },

            validateRef: function () {
                return cem.findElement(currentPage, 'refDate').getText().then(function (date) {
                    console.log("Date is:" + date);
                    var foo = date.toString().split(" ").slice(2, 5).join(" ").replace(/,/g, "");
                    console.log("Value of foo: " +foo);
                    var value = date.toString().split(" ").slice(5, 6).join(" ").replace(/,/g, "");
                    console.log("Value of value: " +value);
                    var value1 = value.toString().split(" ").join(" ").replace(/@/g, "");
                    console.log("Value of value1: " +value1);

                    var value2 = value1.toString().split(" ").join(" ").replace(/PM/g, "").replace(/AM/g, "");


                    console.log("Value of value2: " +value2);
                    var combDate = foo + " " + value2;
                    console.log("Value of combDate: " +combDate);
                    var date1 = new Date(combDate);
                    console.log("Value of date1: " +date1);
                    console.log("Last Refresh Time is: " + combDate);

                    var mill = new Date(date1.getTime() + (15 * 60 * 1000));
                    console.log("Value of mill: " +mill);
                    var dateFormat = require('dateformat');
                    var accDate = dateFormat(mill, "dd mmm yyyy h:MM");

                    var value3 = value1.toString().split(value2).toString().replace(/,/g,"");
                    console.log(value3);
                    if(value3 === 'PM'){
                        var nextRefreshAt = accDate+' '+'PM';
                        console.log("Refresh Date is :" +nextRefreshAt)
                    }else{
                        var nextRefreshAtAM = accDate+' '+'AM';
                        console.log("Refresh Date is :" +nextRefreshAtAM)
                    }
                });
            },

            validateSortList: function () {
                return cem.findElement(currentPage, 'validateSortList').isPresent().then(function (value) {
                console.log("Present Value is: " +value);
                    assert.equal(true,value);
                // element(by.xpath("//*[@id='display_sort']")).isPresent().then(function (value) {
                //     console.log("Value is : " +value );
                });
            },

            notPresentSortList: function () {
                return TestHelper.isElementNotPresent(currentPage, 'notPresentSortList').then(function (value) {
                    console.log("Not Present Value is: " +value);
                    assert.equal(true,value);
                });
            },

            validateErrorMsg:function () {
                var message = 'Please select at least one site';
               return element(by.xpath("(//*[@class='displayErrorMsg ng-scope'])[3]")).getText().then(function (msg) {
                    console.log("Error Message for site is: " +msg);
                    assert.equal(message,msg);
                });
            },

            selectRecord:function () {
              return element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).count().then(function (Count) {
                    var elm = element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).last();
                    browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                        var until = protractor.ExpectedConditions;
                        browser.sleep(5000);
                        browser.executeScript('window.scrollTo(0,1000);').then(function () {
                            console.log('Page Scroll Down');
                            browser.sleep(5000);
                            console.log("Count is :" +Count);
                                browser.sleep(5000);
                             return element(by.xpath('//*[@class="search searchList fx-left-scrollbar"]/li'+'['+Count+']')).click();
                        });
                    });
                });
            },

            selectLastRecord:function () {
                return element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).count().then(function (Count) {
                    var elm = element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).last();
                    browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                        var until = protractor.ExpectedConditions;
                        browser.sleep(5000);
                        browser.executeScript('window.scrollTo(0,1000);').then(function () {
                            console.log('Page Scroll Down');
                            element(by.xpath('//*[@class="search searchList fx-left-scrollbar"]/li'+'['+Count+']/p[1]/strong')).getText().then(function (fullName) {
                                var sFullName = fullName;
                                console.log("Full name from Left nav. : " + sFullName);
                                return assert.equal(lFullName, sFullName);
                            });
                        });
                    });
                });
            },

            selectLastRecordJob:function () {
                return element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).count().then(function (Count) {
                    var elm = element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).last();
                    browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                        var until = protractor.ExpectedConditions;
                        browser.sleep(5000);
                        browser.executeScript('window.scrollTo(0,1000);').then(function () {
                            console.log('Page Scroll Down');
                            element(by.xpath('//*[@class="search searchList fx-left-scrollbar"]/li'+'['+Count+']/p[2]/span')).getText().then(function (jobtitle) {
                                var sJobTitle = jobtitle;
                                console.log("Job Title from Left nav. : " + sJobTitle);
                                return assert.equal(lJobTitle, sJobTitle);
                            });
                        });
                    });
                });
            },

            selectLastRecordMobile:function () {
                return element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).count().then(function (Count) {
                    var elm = element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).last();
                    browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                        var until = protractor.ExpectedConditions;
                        browser.sleep(5000);
                        browser.executeScript('window.scrollTo(0,1000);').then(function () {
                            console.log('Page Scroll Down');
                            element(by.xpath('//*[@class="search searchList fx-left-scrollbar"]/li'+'['+Count+']/p[2]/span[2]')).getText().then(function (mobileNumber) {
                                var sMNumber = mobileNumber;
                                console.log("Mobile Number from Left nav. : " + sMNumber);
                                return assert.equal(lMobileNumber, sMNumber);
                            });
                        });
                    });
                });
            },

            searchClr:function () {
                browser.sleep(3000);
                return  cem.findElement(currentPage,'enterFName').clear().sendKeys(protractor.Key.ENTER);
            },

            validatePopUp:function(){
                var msg= 'There are unsaved changes in personnel section, Would you like to save them before you move away from this Section?';
                browser.sleep(3000);
                return cem.findElement(currentPage,'validatePopUp').isPresent().then(function (value) {
                    console.log("Is Popup Present? " +value);
                    assert.equal(value,true);
                   return cem.findElement(currentPage,'validatePopMsg').getText().then(function(text){
                       console.log("Message of PopUp is: " +text);
                         assert.equal(text,msg);
                        expect(taskMgmtPage.verifyPopUp("Cancel")).to.eventually.be.eql(true);
                        expect(taskMgmtPage.verifyPopUp("No")).to.eventually.be.eql(true);
                        console.log("Validate buttons");
                        return expect(taskMgmtPage.verifyPopUp("Yes")).to.eventually.be.eql(true);
                     });
                });
            },

            clickPopCancel:function () {
                browser.sleep(3000);
               return cem.findElement(currentPage,'cancelPopUp').click()
            },

            clickPopSave:function(){
                browser.sleep(3000);
                return cem.findElement(currentPage,'savePopUp').click()
            },

            clickPopNo:function () {
                browser.sleep(3000);
                return cem.findElement(currentPage,'noPopUp').click()
            },

            retFName:function (firstName) {
                console.log("First name is: " + firstName);
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'storeFirstNameLForm').isPresent();
                return cem.findElement(currentPage, 'storeFirstNameGetText').getText().then(function (firstLName) {
                   console.log("Firstname from Longform is : " +firstLName);
                   assert.equal(firstName,firstLName);
                });
            },

            retLName:function(lastName){
                console.log("First name is: " + lastName);
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'storeLastNameLForm').isPresent();
                return cem.findElement(currentPage, 'storeLastNameGetText').getText().then(function (lastLName) {
                    console.log("LastName from Longform is : " +lastName);
                    assert.equal(lastName,lastLName);
               });
            },

            validateEmail:function () {
                console.log("Existing email is: " + sEmail);
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'emailLForm').isPresent();
                return cem.findElement(currentPage, 'emailGetText').getText().then(function (email) {
                    console.log("Email from Longform is : " + email);
                    assert.equal(sEmail, email);
                });
            },

            diffEmailId:function () {
                console.log("Existing email is: " + sEmail);
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'emailLForm').isPresent();
                return cem.findElement(currentPage, 'emailGetText').getText().then(function (email) {
                    console.log("Email from Longform is : " + email);
                    assert.notEqual(sEmail, email);
                });
            },

            validateEId:function () {
                console.log("Existing email is: " + text);
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'emailLForm').isPresent();
                return cem.findElement(currentPage, 'emailGetText').getText().then(function (email) {
                    console.log("Email from Longform is : " + email);
                    assert.equal(text, email);
                });
            },

            storeEmail:function () {
                browser.driver.sleep(3000);
                cem.findElement(currentPage, 'emailLForm').isPresent();
                return cem.findElement(currentPage, 'emailGetText').getText().then(function (email) {
                    sEmail = email;
                    console.log("Email from Longform is : " + email);
                });
            },

            validateEXPopUp:function () {
                browser.sleep(3000);
                return cem.findElement(currentPage,'validatePopUp').isPresent().then(function (value) {
                    console.log("Is Popup Present? " + value);
                    assert.equal(value, true);
                });
            },

            validatePopUpText:function () {
                var msg= 'There are unsaved changes in personnel. Would you like to save personnel details before leaving this page?';
                browser.sleep(3000);
                return cem.findElement(currentPage,'validatePopUp').isPresent().then(function (value) {
                    console.log("Is Popup Present? " +value);
                    assert.equal(value,true);
                    return cem.findElement(currentPage,'validatePopMsg').getText().then(function(text){
                        console.log("Message of PopUp is: " +text);
                        assert.equal(text,msg);
                        expect(taskMgmtPage.verifyPopUp("Cancel")).to.eventually.be.eql(true);
                        expect(taskMgmtPage.verifyPopUp("No")).to.eventually.be.eql(true);
                        console.log("Validate buttons");
                        return expect(taskMgmtPage.verifyPopUp("Yes")).to.eventually.be.eql(true);
                    });
                });
            },

            validateSecPopUpText:function(){
                var msg= 'There are unsaved changes in personnel section, Would you like to save them before you move away from this Section?';
                browser.sleep(3000);
                return cem.findElement(currentPage,'validatePopUp').isPresent().then(function (value) {
                    console.log("Is Popup Present? " +value);
                    assert.equal(value,true);
                    return cem.findElement(currentPage,'validatePopMsg').getText().then(function(text){
                        console.log("Message of PopUp is: " +text);
                        assert.equal(text,msg);
                        expect(taskMgmtPage.verifyPopUp("Cancel")).to.eventually.be.eql(true);
                        expect(taskMgmtPage.verifyPopUp("No")).to.eventually.be.eql(true);
                        console.log("Validate buttons");
                        return expect(taskMgmtPage.verifyPopUp("Yes")).to.eventually.be.eql(true);
                    });
                });
            },

            planModuleSel:function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage, 'dashboardTab').isSelected().then(function (value) {
                    console.log("Is plan module get selected ? :" +value);

                });
            },

            waitForSpinnerToComplete: function(){
               return !browser.isElementPresent(by.css("#top article div div.pxh-spinner.pxh-spinner--large.ng-scope"));
            },

            lastPage:function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
               return  cem.findElement(currentPage, 'lastPageArrow').isPresent().then(function (value) {
                    console.log("Is plan module get selected ? :" + value);
                    return cem.findElement(currentPage, 'lastPageArrow').click();
                });
            },

            validateData:function () {
                browser.sleep(3000);
                return cem.findElement(currentPage, 'validateNoDataMsg1').isPresent().then(function (flag1) {
                     console.log("Flag is:" + flag1);
                     assert.equal(flag1,false);
                });
            },

            validateEditText:function () {
                browser.sleep(3000);
                 cem.findElement(currentPage,'validatePersonnelText').isPresent();
                     return cem.findElement(currentPage,'validatePersonnelText').getText().then(function(value){
                         console.log("Text is: " +value);
                });
            },

            validateEditNotPre:function () {
                browser.sleep(3000);
                TestHelper.isElementNotPresent(currentPage, 'validatePersonnelText');
                return cem.findElement(currentPage,'personnelDetails').isPresent();
            },

            removeSite:function () {
                browser.sleep(7000);
                TestHelper.isElementPresent(currentPage, 'removeSite');
                cem.findElement(currentPage,'removeSitePills').isPresent();
                return cem.findElement(currentPage,'removeSitePills').click();

            },

            validateEnaDisabled:function (callback) {
                browser.driver.sleep(7000);
                 cem.findElement(currentPage, "addSite").click();
                 element.all(by.xpath("//*[@class='checkBoxContainer']//*[@class='multiSelectItem ng-scope selected vertical disabled']//label/span")).getText().then(function(enabled){
                    console.log("Enabled site is :" +enabled);
                     element.all(by.xpath("//*[@class='checkBoxContainer']//*[@class='multiSelectItem ng-scope vertical']//label/span")).getText().then(function(disabled){
                        console.log("Disabled site is :" +disabled);
                            callback();
                    });
                });
            },

            addExtSite:function (callback) {
                browser.sleep(5000);
                cem.findElement(currentPage, "addSite").click();
                cem.findElement(currentPage,"getEnabledSite").click();
                callback();
            },

            saveAllSite:function (callback) {
                cem.findElement(currentPage, "addSite").click();
                element.all(by.xpath("//*[@class='checkBoxContainer']//*[@class='ng-binding']")).getText().then(function(sites) {
                    console.log("Value of the site is :" +sites);
                    allSites =sites;
                    callback();
                });
            },

            existingSite:function (callback) {
                browser.sleep(5000);
                cem.findElement(currentPage, "addSite").click();
                element.all(by.xpath("//*[@class='ng-binding disabled']")).getText().then(function(present) {
                    var present1 = present.sort();
                    console.log("Sites are : " + present1);
                    console.log("All sites are :" +allSites);

                 if(JSON.stringify(allSites) === JSON.stringify(present1)){
                     console.log("Value Present");
                     callback();
                 }else {
                     console.log("Need to check");
                     callback();
                 }
                });
            },

            scrollDownTask:function (callback) {
                browser.sleep(5000);
                var elm = element(by.xpath("//*[text()='Files:']"));
                browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                    var until = protractor.ExpectedConditions;
                    browser.sleep(5000);
                    browser.executeScript('window.scrollTo(0,5000);');
                    console.log('Page Scroll Down');
                    callback();
                });
            },
            scrollDownTurbine:function (callback) {
                browser.sleep(5000);
                var elm = element(by.xpath("//*[text()='Items per page:']"));
                browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                    var until = protractor.ExpectedConditions;
                    browser.sleep(5000);
                    browser.executeScript('window.scrollTo(0,5000);');
                    console.log('Page Scroll Down');
                    callback();
                });
            },

            validateCreate:function (callback) {
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'createButton').isPresent();
                cem.findElement(currentPage,'createButton1').isPresent().then(function (value) {
                    console.log("Value is : " +value);
                    assert.equal(value,true);
                    callback();
                });
            },

            clickCreate:function(){
                browser.driver.sleep(5000);
               return cem.findElement(currentPage,'createButton').click();

            },

            validateSite:function (callback) {
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'createButton1').isPresent().then(function (value) {
                    console.log("Value is : " + value);
                    assert.equal(value, true);
                    callback();
                });
            },

            dropDownLeft:function (callback) {
                browser.sleep(5000);
                var elm = element.all(by.xpath("//*[@class='taskList ng-scope']")).last();
                browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                    var until = protractor.ExpectedConditions;
                    browser.sleep(5000);
                    browser.executeScript('window.scrollTo(0,5000);');
                    console.log('Page Scroll Down');
                    callback();
                });
            },

            dropDownLeftTurbine:function (callback) {
                browser.sleep(5000);
                var elm = element.all(by.xpath("//*[@class='taskList float--left u-1/1 ng-scope']")).last();
                browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                    var until = protractor.ExpectedConditions;
                    browser.sleep(5000);
                    browser.executeScript('window.scrollTo(0,5000);');
                    console.log('Page Scroll Down');
                    callback();
                });
            },

            validateUpper:function (callback) {
                cem.findElement(currentPage,'validateUpper').isPresent().then(function (value) {
                    console.log("Value is : " +value);
                    assert.equal(value,true);
                    callback();
                });
            },

            validateLower:function (callback) {
                cem.findElement(currentPage,'validateLower').isPresent().then(function (value) {
                    console.log("Value is : " +value);
                    assert.equal(value,true);
                    callback();
                });
            },

            validateLowerTurbine:function(callback){
                cem.findElement(currentPage,'validateLowerTurbine').isPresent().then(function (value) {
                    console.log("Value is : " + value);
                    assert.equal(value, true);
                    callback();
                });
            },

            validateLastSel:function (callback) {
                 return element.all(by.xpath("//*[contains(@class,'taskList ng-scope')]")).count().then(function (Count) {
                    var elm = element.all(by.xpath("//*[contains(@class,'taskList ng-scope')]")).last();
                    browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                        var until = protractor.ExpectedConditions;
                        browser.sleep(5000);
                        browser.executeScript('window.scrollTo(0,1000);').then(function () {
                            console.log('Page Scroll Down');
                            element(by.xpath('//*[contains(@class,"taskList ng-scope")]'+'['+Count+']')).click();
                             element(by.xpath('//*[contains(@class,"taskList ng-scope selected")]')).isPresent().then(function(value){
                             assert.equal(value,true);
                             callback();
                         })
                        });
                    });
                });
            },

            validateLastSelTur:function(callback){
                return element.all(by.xpath("//*[contains(@class,'taskList float--left u-1/1 ng-scope')]")).count().then(function (Count) {
                    var elm = element.all(by.xpath("//*[contains(@class,'taskList float--left u-1/1 ng-scope')]")).last();
                    browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                        var until = protractor.ExpectedConditions;
                        browser.sleep(5000);
                        browser.executeScript('window.scrollTo(0,1000);').then(function () {
                            console.log('Page Scroll Down');
                            element(by.xpath('//*[contains(@class,"taskList float--left u-1/1 ng-scope")]'+'['+Count+']')).click();
                            element(by.xpath('//*[contains(@class,"taskList float--left u-1/1 ng-scope selected")]')).isPresent().then(function(value){
                                assert.equal(value,true);
                                callback();
                            })
                        });
                    });
                });
            },

            storeSite:function () {
                return cem.findElement(currentPage,'storeSite').getText().then(function(storeSite){
                    currentSite = storeSite.toLowerCase();
                    console.log("Value of current Site is:" +currentSite);
                })
            },

            validateDeleteSite:function () {
                browser.sleep(3000);
                console.log("Store site is : " +currentSite);
             return  element.all(by.xpath("//*[@class='displaySites ng-binding']")).getText().then(function (displaySite) {
                    console.log("Display sites are : " +displaySite.toString().toLowerCase());
                    if(displaySite.toString().toLowerCase().includes(currentSite)){
                        console.log("Site is Present");
                    }else{
                        console.log("Site is not Present");
                    }

                })

            },

            deleteText:function () {
                var deleteHeader = "Delete Personnel";
                var deleteBody = 'You are about to delete the personnel from this site.';
                var deletePad = 'Do you want to continue?';
                var deleteNote = 'Note: Deleting the personnel will remove them from the Crews ribbon in DPOD and revoke their access to this site.';

                return cem.findElement(currentPage,'deleteHeader').getText().then(function (presentHeader) {
                    console.log("Header is : "+presentHeader);
                    assert.equal(deleteHeader,presentHeader);


                    cem.findElement(currentPage,'deleteBody').getText().then(function (presentBody) {
                        console.log("Body is : " + presentBody);
                        assert.equal(deleteBody, presentBody);


                        cem.findElement(currentPage, 'deletePad').getText().then(function (presentPad) {
                            console.log("Pad is : " + presentPad);
                            assert.equal(deletePad, presentPad);


                            cem.findElement(currentPage, 'deleteNote').getText().then(function (presentNote) {
                                console.log("Note is : " + presentNote);
                                assert.equal(deleteNote, presentNote);
                            });
                        });
                    });
                });
            },

            deleteYes:function () {
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'deleteYes').isPresent();
                return cem.findElement(currentPage,'deleteYes').click();
            },

            validateNoRecord:function (callback) {
                var noRecord = "No record found";
              cem.findElement(currentPage,'noRecord').isPresent().then(function(value){
                    console.log(value);

                    if(value === true){
                        cem.findElement(currentPage,'noRecord').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }else{
                            cem.findElement(currentPage, 'clickFirstRow').click();
                            cem.findElement(currentPage, 'clickDeleteIcon').click();
                            cem.findElement(currentPage, 'deleteYes').isPresent();
                            cem.findElement(currentPage, 'deleteYes').click();
                            browser.sleep(5000);
                        cem.findElement(currentPage,'noRecord').getText().then(function (textValue) {
                            assert.equal(noRecord, textValue);
                            console.log("No record is present ");
                            callback();
                        });
                    }
                });
            },

            initialCrewCount:function(callback){
                browser.sleep(7000);
                cem.findElement(currentPage,'validateInCrew').isPresent().then(function(promise){
                    element.all(by.xpath("//*[@id='crewSpan']//*[text()='TY']")).count().then(function(count) {
                        initialCrewCount = count;
                        console.log("Initial count of crew is : " + initialCrewCount);
                        console.log("Value from DPOD : " + promise);
                        if(count === 0){
                            assert.equal(promise, false);
                        }else{
                            assert.equal(promise, true);
                        }

                        callback();
                    });
                });
            },

            validateInCrew:function(callback){
                browser.sleep(7000);
                cem.findElement(currentPage,'validateInCrew').isPresent().then(function(promise){
                    element.all(by.xpath("//*[@id='crewSpan']//*[text()='TY']")).count().then(function(count) {
                        deleteCrewCount = count;
                        console.log("Initial crew count is :  " +initialCrewCount);
                        console.log("Crew count is :  " +CrewCount);
                        console.log("Delete Crew count is :  " +deleteCrewCount);
                       console.log("Value from DPOD : " + promise);
                       if(count > 0 && CrewCount > initialCrewCount && CrewCount < deleteCrewCount){
                           assert.equal(promise, false);
                       }else{
                           assert.equal(promise, true);
                       }

                       callback();
                   });
               });
            },

            validateCrewPre:function (callback) {
                browser.sleep(7000);
                 cem.findElement(currentPage, 'validateInCrew').isPresent().then(function (promise) {
                     element.all(by.xpath("//*[@id='crewSpan']//*[text()='TY']")).count().then(function (count) {
                         CrewCount = count;
                         console.log("Crew count is :  " +CrewCount);
                        console.log("Value from DPOD : " +promise);
                        assert.equal(promise, true);
                        callback();
                     });
                });
            },

            selectTask:function(task){
                browser.sleep(5000);
                element(by.xpath("//*[@ng-model='createType']")).click();
               return element(by.xpath('//*[@ng-model="createType"]/option[@value="'+task+'"]')).click();

            },

            taskName:function(task){
                browser.driver.sleep(5000);
                var dateFormat = require('dateformat');
                var now = new Date();
                currentDate = dateFormat(now,"d mmm yyyy");
                console.log("Today's date is " +currentDate);
                taskNmber = "7939" + Math.round(Math.random() * 1000);
                taskName = task.toUpperCase() + ' - '+ taskNmber + ' - '+  currentDate;
                cem.findElement(currentPage,'taskName').sendKeys(taskName + protractor.Key.TAB);
                    return cem.findElement(currentPage,'addTask').isPresent();
            },

            selectDescription:function(){
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'description').sendKeys("Description is task created on " + currentDate + ' with ' +taskNmber+ protractor.Key.TAB);

            },

            selectCategory:function(){
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'selectCategoryDrop').click();
               return cem.findElement(currentPage,'selectCategory').click();

            },

            selectDocumentation:function(){
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'selectDocumentationDrop').click();
               return  cem.findElement(currentPage,'selectDocumentation').click();

            },

            selectSection:function(){
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'selectSectionDrop').click();
               return cem.findElement(currentPage,'selectSection').click();
            },

            selectPlus:function(){
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'selectPlus').isPresent();
                return cem.findElement(currentPage,'selectPlus').click();

            },

            turbineValue:function(){
                browser.driver.sleep(5000);
                return  cem.findElement(currentPage,'turbineValue').getText().then(function(number){
                    turbineNumber = number;
                    console.log("Turbine Number is : " +turbineNumber);
                });
            },

            selectFirstValue:function(){
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'selectFirstValue').click();

            },

            saveButtonTur:function(){
                browser.driver.sleep(5000);
                return  cem.findElement(currentPage,'saveButtonTur').click();

            },

            selectPriority:function(){
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'selectPriorityDrop').click();
                return cem.findElement(currentPage,'selectPriority').click();

            },

            selectTech:function () {
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'selectTechDrop').click();
                return   cem.findElement(currentPage,'selectTech').click();

            },

            selectDue:function () {
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'selectDue').click();
                browser.sleep(2000);
                return cem.findElement(currentPage,'selectDue').click();


            },

            selectPlanned:function(){
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'selectPlanned').click();
                browser.sleep(2000);
                return  cem.findElement(currentPage,'selectPlanned').click();

            },

            changeHour:function(){
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'changeHour').click();
                cem.findElement(currentPage,'changeHour').sendKeys(protractor.Key.BACK_SPACE);
                cem.findElement(currentPage,'changeHour').click();
                cem.findElement(currentPage,'changeHour').sendKeys(protractor.Key.BACK_SPACE );
                browser.sleep(2000);
                return cem.findElement(currentPage,'changeHour').sendKeys('04');

            },

            partsNeed:function() {
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'partsNeed').sendKeys('None'+protractor.Key.TAB);

            },

            techNotes:function() {
                browser.driver.sleep(5000);
                return  cem.findElement(currentPage,'techNotes').sendKeys('Be Careful'+protractor.Key.TAB);

            },

            podEodNotes:function() {
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'podEodNotes').sendKeys('Do Your Best'+protractor.Key.TAB);

            },

            addTask:function(){
                browser.driver.sleep(5000);
                return  cem.findElement(currentPage,'addTask').click();

            },

            clickOK:function () {
                browser.driver.sleep(5000);
                return  cem.findElement(currentPage,'clickOK').click();
            },

            clickSearch:function(){
                browser.driver.sleep(5000);
                return  cem.findElement(currentPage,'clickSearch').click();
            },

            sendTaskValue:function(){
                browser.driver.sleep(5000);
                return  cem.findElement(currentPage,'clickSearch').sendKeys(taskName+ protractor.Key.ENTER);
            },

            validateTaskValue:function () {
               return element.all(by.xpath(" //*[@class='ng-binding ng-scope']")).getText().then(function(othersValue){
                    console.log("All task value which has task type as others : " +othersValue);
                    othersValue.toString().includes(taskName);
                });
            },

            validateTurbineNumber:function () {
                return element.all(by.xpath(" (//*[@ng-bind='task.assetDisplayName'])[1]")).getText().then(function(numberOfTurbine) {
                    console.log("All task value which has task type as others : " + numberOfTurbine);
                    numberOfTurbine.toString().includes(turbineNumber);
                });
            },

            validateUniUser:function(){
                cem.findElement(currentPage,'validateUniUser').isPresent();
                return cem.findElement(currentPage,'validateUniUser').click();
            },

            validateUrNotPre:function () {
                browser.sleep(5000);
              return element(by.xpath("//*[@id='crewSpan']//*[text()='TULYN']")).isPresent().then(function (value) {
                    console.log("User Id value is :" + value);
                    assert.equal(value, false)
                });
            },

            dropUniUser:function(){
                browser.sleep(3000);
                var ele = element(by.xpath("//*[@id='crewSpan']//*[text()='TULYN']"));
                var target = element.all(by.xpath("//*[@id='displayCrewNamePopup']")).first();
                // return browser.driver.actions().dragAndDrop(ele,target).mouseUp().perform();
                browser.sleep(3000);
                return browser.actions().dragAndDrop(ele, target).mouseUp().perform();
            },

            releaseUniUser:function () {
                browser.sleep(3000);
                var ele = element(by.xpath("//*[@id='displayCrewNamePopup']//*[text()='TULYN']"));
                var target = element.all(by.xpath("//*[@id='crewSpan']")).last();
                // return browser.driver.actions().dragAndDrop(ele,target).mouseUp().perform();
                browser.sleep(3000);
                return browser.actions().dragAndDrop(ele, target).mouseUp().perform();
            },

            validateCrewPresent:function () {
               return cem.findElement(currentPage,'validateCrewPresent').isPresent().then(function(present){
                    console.log("Is any crew present : " +present);
                    if(present===true){
                        return console.log("Crew is present");
                    }else{
                        var elm = element(by.xpath("//*[@id='newcrewPopOver']"));
                        elm.click();
                        var ele = element.all(by.xpath("//*[@class='unassignedCrewTop u-mr-']//div[contains(@ng-show,'unACrews.userInitials')]//div[contains(@class,'contractor-person')]")).last();
                        ele.click();
                        var ele1 = element.all(by.xpath("//*[@class='unassignedCrewTop u-mr-']//div[contains(@ng-show,'unACrews.userInitials')]//div[contains(@class,'contractor-person')]")).last();
                        var target = element(by.xpath(" //*[@id='crewPopOver']//span//center"));
                        browser.sleep(3000);
                       return browser.actions().dragAndDrop(ele1, target).mouseUp().perform();
                    }
                });
            },

            clickPlus:function () {
                browser.sleep(3000);
                 cem.findElement(currentPage,'validatePlus').isPresent();
                browser.sleep(3000);
                 cem.findElement(currentPage,'validatePlus').click();
                browser.sleep(3000);
                    cem.findElement(currentPage,'addTask').isPresent();
                browser.sleep(3000);
                    return cem.findElement(currentPage,'addTask').click();
            },

            getAssignContractor:function () {
                return element.all(by.xpath("(//*[@id='crewColumnId'])[1]//*[@id='workUsersTooltip']")).getText().then(function (contra) {
                    assignContra =contra;
                    previousAssignCrew =contra;
                    console.log("Assign Contractor is : " +assignContra);
                })
            },

            clkSavedTaskName:function() {
                console.log("Task name is : " + taskName);
                return browser.actions().mouseMove(element(by.xpath("(//*[@id='workModule'])[1]//*[@class='ng-binding ng-scope'][contains(.,'"+taskName+"')]"))).perform();
                // element(by.xpath('(//*[@id="workModule"])[1]//*[@class="ng-binding ng-scope"][contains(.,"'+taskName+'")]')).click();
            },

            completedTask:function(){
                browser.sleep(3000);
                return element.all(by.xpath("//a[contains(@title,'Mark as complete')]")).last().click();

            },

            addDurationNote:function(){
                var notes= 'First completed Task';
                browser.sleep(3000);
                cem.findElement(currentPage,'addDurationNote').click();
                browser.sleep(3000);
                cem.findElement(currentPage,'selectHours').click();
                browser.sleep(3000);
                return cem.findElement(currentPage,'sendNotes').sendKeys(notes);

            },

            clickDone:function () {
               return cem.findElement(currentPage,'clickDone').click();
            },

            dPODScroll:function () {
                browser.sleep(5000);
                var elm = element(by.xpath("//*[text()=' Plan']"));
             return browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                    var until = protractor.ExpectedConditions;
                    browser.sleep(5000);
                    browser.executeScript('window.scrollTo(0,5000);');
                    console.log('Page Scroll Down');
                });
            },

            sendTurbineName:function(){
                browser.sleep(5000);
                cem.findElement(currentPage,'clickSearch').isPresent();
              return  cem.findElement(currentPage,'clickSearch').sendKeys(turbineNumber);
            },

            validateTableDate:function () {
                browser.sleep(8000);
              return element(by.xpath("(//*[@class='table table-bordered u-mt-']//td)[1]")).getText().then(function(dPODDate){
                    console.log("Date from the tabel is : " +dPODDate);
                    var dateFormat = require('dateformat');
                    var now = new Date();
                    currentDate = dateFormat(now,"d mmm yyyy");
                    console.log("Today's date is " +currentDate);
                   assert.equal(dPODDate,currentDate);
                });
            },

            ableToValidateCrew:function() {
                browser.sleep(5000);
                console.log("Assign contractor is : " + assignContra);
                return element.all(by.xpath("(//*[@class='table table-bordered u-mt-']//td)[3]//span[@class='ng-binding']")).getText().then(function (crewInTable) {
                    console.log("Crew in History are : " + crewInTable);
                    var crewFromTable = crewInTable.sort();
                    var planContractor = assignContra.sort();
                    console.log("Crew from table : " + crewFromTable);
                    console.log("Crew from Plan page : " + planContractor);
                    assert.equal(JSON.stringify(planContractor),JSON.stringify(crewFromTable))
                });
            },

            CrewNotPresent:function () {
                var name= 'TULYN';
                browser.sleep(5000);
                console.log("Assign contractor is : " + assignContra);
                return element.all(by.xpath("((//*[@class='table table-bordered u-mt-'])//tr[1])//td[3]//span[@class='ng-binding']")).getText().then(function (crewInTable) {
                    console.log("Crew in History are : " + crewInTable);
                    var crewFromTable = crewInTable.sort();
                    var planContractor = assignContra.sort();
                    console.log("Crew from table : " + crewFromTable);
                    console.log("Crew from Plan page : " + planContractor);
                    if(name.toString().toLowerCase().includes(crewFromTable)){
                        console.log("Crew is Present");
                    }else{
                        console.log("Crew is not Present");
                    }
                });
            },

            assignContractorSecRow:function(){
                browser.sleep(5000);
                console.log("Assign contractor is : " + assignContra);
                return element.all(by.xpath("((//*[@class='table table-bordered u-mt-'])//tr[1])//td[3]//span[@class='ng-binding']")).getText().then(function (crewInFirRow) {
                    element.all(by.xpath("((//*[@class='table table-bordered u-mt-'])//tr[2])//td[3]//span[@class='ng-binding']")).getText().then(function (crewInSecRow) {
                        console.log("Crew in History are : " + crewInFirRow);
                        console.log("Crew in History are : " + crewInSecRow);
                        var crewRow1 = crewInFirRow.sort();
                        var crewRow2 = crewInSecRow.sort();
                        console.log("Crew from table : " + crewRow1);
                        console.log("Crew from Plan page : " + crewRow2);
                        assert.notEqual(JSON.stringify(crewRow1), JSON.stringify(crewRow2));
                    });
                });
            },

            validateTaskTitle:function(){
                return element.all(by.xpath("(//*[@class='table table-bordered u-mt-']//td)[4]")).getText().then(function (taskTitle) {
                    console.log("Crew in History are : " + taskTitle);
                    assert.equal(taskName,taskTitle);
                });
            },

            deleteCrew:function() {
             return element.all(by.xpath("//*[@ng-model='crewDetails']")).count().then(function (numberOfCrew) {
                 console.log("Locator is present : " +numberOfCrew);
                    var i;
                        if (numberOfCrew) {
                            console.log("Enter");
                                for (i=0; i<numberOfCrew; i++) {
                                    browser.sleep(5000);
                                    console.log("Enter 1: " +i);
                                    browser.sleep(5000);
                                    element(by.xpath("//*[@ng-model='crewDetails']")).click().then(function () {
                                        browser.sleep(5000);
                                        element(by.xpath("//*[@title='Remove all techs from this crew']")).click().then(function () {
                                            browser.sleep(3000);
                                            element(by.xpath("(//*[@class='modal__content u-p+ style-scope px-modal'][contains(@role,'region')])[2]")).isDisplayed().then(function(value){
                                                console.log(value);
                                                if(value==true ){
                                                browser.sleep(3000);
                                                element(by.xpath("//*[@class='btn btn--primary deleteAllTechCrewBtn ng-binding']")).click();
                                            }else{
                                                console.log("Not associated with workplan");
                                            }
                                            });
                                        });

                                    });
                                }

                        } else {
                    }
                });
            },

            contextBrowserValidation:function () {
                browser.sleep(3000);
                return cem.findElement(currentPage,'contextBrowser').isPresent();

            },

            recordValidation:function(){
                browser.sleep(3000);
                return cem.findElement(currentPage,'recordValidation').isPresent();
            },

            scrollUp:function () {
                browser.sleep(5000);
                var elm = element.all(by.xpath("//*[@class='search searchList fx-left-scrollbar']/li")).first();
               return browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                    var until = protractor.ExpectedConditions;
                    browser.sleep(5000);
                    browser.executeScript('window.scrollTo(5000,0);');
                    console.log('Page Scroll Up');
                });
            },

            addNewPersonnel:function () {
                browser.sleep(5000);
                return cem.findElement(currentPage, 'addPersonnel').isPresent();
            },

            validateContext:function () {
                browser.driver.sleep(5000);
                console.log("Site name from context browser : " +saveSiteName.toUpperCase());
                browser.driver.sleep(5000);
                TestHelper.isElementPresent(currentPage, 'leftNavDPOD');
                cem.findElement(currentPage, 'leftNavDPOD').click();
               return element(by.xpath("(//*[@class='context-browser-disabled-false style-scope px-context-browser'])[1]")).getText().then(function(siteNme){
                    console.log("Site name from POd in plan is : " + siteNme);
                    assert.equal(saveSiteName.toUpperCase(),siteNme)
                });

            },

            validatePlanContext:function () {
                browser.driver.sleep(5000);
                console.log("Site name from context browser : " +saveSiteName.toUpperCase());
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'planModuleTab').click();
                browser.driver.sleep(5000);
                return element(by.xpath("(//*[@class='context-browser-disabled-false style-scope px-context-browser'])[1]")).getText().then(function(siteNme) {
                    console.log("Site name from POd in plan is : " + siteNme);
                    assert.equal(saveSiteName.toUpperCase(), siteNme)
                });
            },

            validateTaskContext:function () {
                browser.driver.sleep(5000);
                console.log("Site name from context browser : " +saveSiteName.toUpperCase());
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'taskPage').click();
                browser.driver.sleep(5000);
                return element(by.xpath("(//*[@class='context-browser-disabled-false style-scope px-context-browser'])[1]")).getText().then(function(siteNme) {
                    console.log("Site name from POd in task is : " + siteNme);
                    assert.equal(saveSiteName.toUpperCase(), siteNme)
                });
            },

            validateTurbineContext:function () {
                browser.driver.sleep(5000);
                console.log("Site name from context browser : " +saveSiteName.toUpperCase());
                browser.driver.sleep(5000);
                cem.findElement(currentPage, 'turbineTab').click();
                browser.driver.sleep(5000);
                return element(by.xpath("(//*[@class='context-browser-disabled-false style-scope px-context-browser'])[1]")).getText().then(function(siteNme) {
                    console.log("Site name from POd in turbine is : " + siteNme);
                    assert.equal(saveSiteName.toUpperCase(), siteNme)
                });
            },

            validateReportContext:function(){
                browser.driver.sleep(5000);
                console.log("Site name from context browser : " +saveSiteName.toUpperCase());
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'reportsTab').click();
                browser.driver.sleep(5000);
                return element(by.xpath("(//*[@class='context-browser-disabled-false style-scope px-context-browser'])[1]")).getText().then(function(siteNme) {
                    console.log("Site name from POd in report is : " + siteNme);
                    assert.equal(saveSiteName.toUpperCase(), siteNme)
                });
            },

            pmSiteList:function () {
                browser.driver.sleep(5000);
                cem.findElement(currentPage, 'siteGroupDropdwn').click();
                browser.sleep(5000);
               return element.all(by.xpath("//*[@class='selected list-bare level style-scope px-context-browser']//span")).getText().then(function(PMSiteList){
                   SitesNamePM = PMSiteList;
                    console.log("Available sites in PM is : "+SitesNamePM);
                   cem.findElement(currentPage, 'siteGroupDropdwn').click();
                });
            },

            dPODSiteList:function () {
                browser.driver.sleep(5000);
                cem.findElement(currentPage, 'leftNavDPOD').click();
                browser.driver.sleep(5000);
                cem.findElement(currentPage, 'siteGroupDropdwn').click();
                browser.sleep(5000);
                return element.all(by.xpath("//*[@class='selected list-bare level style-scope px-context-browser']//span")).getText().then(function(dPODSiteList){
                    SiteNameDpod = dPODSiteList;
                    console.log("Available sites in DPOD is : "+SiteNameDpod);
                    cem.findElement(currentPage, 'siteGroupDropdwn').click();
                });
            },

            validationSites:function (callback) {
                console.log("Available sites in PM is : "+SitesNamePM);
                console.log("Available sites in DPOD is : "+SiteNameDpod);
                assert.equal(JSON.stringify(SitesNamePM),JSON.stringify(SiteNameDpod));
                callback();
            },

            pmSiteValidation:function(){
                browser.driver.sleep(5000);
                console.log("Site name from context browser : " +saveSiteName.toUpperCase());
                TestHelper.isElementPresent(currentPage, 'leftNav');
                browser.sleep(5000);
                cem.findElement(currentPage, 'leftNav').click();
                browser.driver.sleep(5000);
                return element(by.xpath("(//*[@class='context-browser-disabled-false style-scope px-context-browser'])[1]")).getText().then(function(siteNme) {
                    console.log("Site name from POd in turbine is : " + siteNme);
                    assert.equal(saveSiteName.toUpperCase(), siteNme)
                });
            },

            validateUrl:function (callback) {
                var Url = "https://pulsepoint.re.ge.com/PulsePointUI/iidx/pages/indexnew.html#new";

                assert.equal(currentURL,Url);
                callback();
            }
        }
	};

    module.exports = new TaskMgmtPage();

}());
