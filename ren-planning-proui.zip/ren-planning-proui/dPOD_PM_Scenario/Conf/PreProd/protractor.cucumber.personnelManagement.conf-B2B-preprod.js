

exports.config = {

    sauceUser: null,
    sauceKey: null,
    sauceSeleniumAddress: null,
    directConnect: false,
    firefoxPath: null,
    // chromeDriver: '../../../chrome-driver/chromedriver_2.33.exe',
    // chromeDriver: '../../../node_modules/protractor/selenium/chromedriver_2.33',

    // Organize spec files into suites. To run specific suite, --suite=<name of suite>
    suites: {

        personnelMgmt:[
            "../../Features/Preprod-B2B/personnelManagementPopUpValidation-B2B-preprod.feature",
            "../../Features/Preprod-B2B/personalManagementSortForm-B2B-preprod.feature",
        ],

    },

    // Hooks running in the background
    plugins: [{
        // C:/Users/502743572/Desktop/DPOD/ren-planning-proui/node_modules/proui-utils/Compressed_Utils/GeneralHook.js
        path: '../../../node_modules/proui-utils/Compressed_Utils/GeneralHook.js',
        // path: 'hook.js',

    }],

    capabilities: {
        browserName: 'chrome',
        proxy:{
            proxyType:'manual',
            httpProxy: 'sjc1intproxy02.crd.ge.com:8080',
            sslProxy: 'sjc1intproxy02.crd.ge.com:8080',
        },
        count: 1,
        shardTestFiles: false,
        maxInstances: 1,
        'chromeOptions': {
            args: ['--no-sandbox', '--test-type=browser'],
            prefs: {
                'download': {
                    'prompt_for_download': false,
                    'directory_upgrade': true,
                    'default_directory': 'C:/Users/502743572/Desktop/DPOD'

                    // 'download': {
                    //     'directory_upgrade': true,
                    //     'prompt_for_download': false,
                    //     //'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
                    //     //'default_directory': '/DownLoad/'
                    //     'default_directory': 'C:/Users/rmanchik/Documents/Automation/TestData/DownLoad/'
                    // }

                }
            }
        }
    },

	/* params: {
	 env: 'qa'
	 }, */

    maxSessions: -1,
    allScriptsTimeout: 250000,
    getPageTimeout: 1650000,
    beforeLaunch: function () {
    },
    onPrepare: function () {
        var folderName = (new Date()).toString().split(' ').splice(1, 4).join(' ');
        var mkdirp = require('mkdirp');
        var reportsPath = "./Reports/";
        mkdirp(reportsPath, function (err) {
            if (err) {
                console.error(err);
            } else {
            }
        });

        browser.manage().deleteAllCookies();
        browser.manage().timeouts().pageLoadTimeout(50000);
        browser.manage().timeouts().implicitlyWait(50000);
      // browser.driver.manage().window().maximize();
        browser.manage().window().setSize(1400, 900);
        chai = require('chai');
        expect = chai.expect;
        path = require('path');
        Cucumber = require('cucumber');
        fs = require('fs');

        // Initializing necessary utils from ProUI-Utils module
        TestHelper = require('proui-utils').TestHelper;
        TestHelperPO = require('proui-utils').TestHelperPO;
        ElementManager = require('proui-utils').ElementManager;
        Logger = require('proui-utils').Logger;
        cem = new ElementManager('../../../dPOD_PM_Scenario/taskmngmnt-element-repo.json');
        //cem = new ElementManager('../../../planmngmnt-element-repo.json');
        TestHelper.setElementManager(cem);
        RestHelper = require('proui-utils').RestHelper;

        // Initializing page object variables
        taskMgmtPage = require('../../PageObjects/dPODpersonnelMgmt_po.js');
        //planMgmtPage = require('../PageObjects/dPODPlanMgmt_po.js');
        // commonTestData = require('../../../TestData/common-test-data.json').data;
    },

    // A callback function called once tests are finished
    onComplete: function() {},


    // A callback function called once tests are cleaning up
    onCleanUp: function(exitCode) {

    },

    // A callback function after tests are launched
    afterLaunch: function() {

    },

    // Browser parameters for feature files.

    params: {
        login: {
            baseUrl: 'https://apmpreprod.preprod-app.aws-usw02-pr.predix.io/ge-wind-dfsa/plan/#/dashboard',
            //baseUrl: 'https://apmpreprod.apm.aws-usw02-pr.predix.io/gere-qa/plan/#/dashboard',
            //baseUrl: 'https://apmpreprod.apm.aws-usw02-pr.predix.io/ren-wind-dev/plan/#/dashboard',

            "username": "LongB2BSSO@customeremaildomain.com",
            "password": "GE2018Support",

            "username1": "502790247",
            "password1": "t3J0OggH4h",
            "btn": '//*[@value="Log In & Remember Me"]',
            //"Value": "121",

        }
    },

    resultJsonOutputFile: null,

    // If true, protractor will restart the browser between each test.
    // CAUTION: This will cause your tests to slow down drastically.
    restartBrowserBetweenTests: false,

    // Custom framework in this case cucumber
    framework: 'custom',
    frameworkPath: require.resolve('protractor-cucumber-framework'),
    cucumberOpts: {

        // define your step definitions in this file
        require: [
            '../../step_definitions/env.js',
            '../../step_definitions/dPODPersonnelMngmt-spec.js',
            //'../step_definitions/dPODQ3-spec.js',
            //'../step_definitions/dPODPlanMngmt-spec.js',
            '../step_definitions/dPODReportsMngmt-spec.js',
            './../../../node_modules/proui-utils/Compressed_Utils/Reporter.js'
        ],

        //format: 'pretty'
    }
};
