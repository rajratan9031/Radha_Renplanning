/**
 * Created by 212556710 on 10/13/16.
 */
var fs = require("fs");

var protractorConfigPath = "./node_modules/protractor/config.json";
var webdriverPath = "./node_modules/protractor/bin/webdriver-manager";
var packageJsonPath = "./package.json";
var gruntProtractorRunnerPath = "./node_modules/grunt-protractor-runner/node_modules";


fs.readFile(protractorConfigPath, "utf8", function (err, data) {
    if(err) console.log(err);
    data = data.toString();
    data = data.replace(/2.21/g, "2.36");
    data = data.replace(/2.24/g, "2.36");
    data = data.replace(/2.27/g, "2.36");
    data = data.replace(/2.28/g, "2.36");
    // data = data.replace(/2.28/g, "2.30");
    fs.writeFile(protractorConfigPath, data, function(err){
        if(err) console.log(err);
        fs.readFile(webdriverPath, "utf8", function (err, data) {
            if(err) console.log(err);
            data = data.toString();
            data = data.replace(/mac32/g, "mac64");
            fs.writeFile(webdriverPath, data, function(err){
                if(err) console.log(err);
                fs.readFile(packageJsonPath, "utf8", function (err, data) {
                    if(err) console.log(err);
                    data = data.toString();
                    data = data.replace(/(grunt-protractor-runner\"\: \"\*\")/g, 'grunt-protractor-runner": "3.2.0"');
                    fs.writeFile(packageJsonPath, data, function(err) {
                        if(err) console.log(err);
                        var deleteFolderRecursive = function(path) {
                            if( fs.existsSync(path) ) {
                                fs.readdirSync(path).forEach(function(file,index){
                                    var curPath = path + "/" + file;
                                    if(fs.lstatSync(curPath).isDirectory()) { // recurse
                                        deleteFolderRecursive(curPath);
                                    } else { // delete file
                                        fs.unlinkSync(curPath);
                                    }
                                });
                                fs.rmdirSync(path);
                            }
                        };
                        deleteFolderRecursive(gruntProtractorRunnerPath);
                    });
                });

            });
        });
    });


});